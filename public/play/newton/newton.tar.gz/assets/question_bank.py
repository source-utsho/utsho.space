"""
Newton's Apple Crisis v2.0 — Question Bank
==========================================
Organized by: topic → difficulty (easy / medium / hard)
Each question: { question, choices[4], correct_index, explanation }

Topics: arithmetic, pre_algebra, algebra, geometry, trigonometry,
        pre_calculus, calculus, advanced

Profile → Topic mapping:
  Age 10-11 / no courses      → arithmetic
  Age 12-13 / pre-algebra     → pre_algebra
  Age 13-14 / algebra         → algebra
  Age 14-15 / geometry        → geometry
  Age 15-16 / trig            → trigonometry
  Age 16-17 / pre-calc        → pre_calculus
  Age 17+  / calculus         → calculus
  College+ / diff eq etc.     → advanced

Confidence → difficulty:
  Struggling    → easy
  Getting By    → easy/medium (alternating)
  Comfortable   → medium
  Strong        → medium/hard (alternating)
"""

QUESTION_BANK = {

    # ══════════════════════════════════════════
    # ARITHMETIC  (age ~10-11, basic math)
    # ══════════════════════════════════════════
    "arithmetic": {
        "easy": [
            {
                "question": "What is 7 × 8?",
                "choices": ["54", "56", "63", "48"],
                "correct_index": 1,
                "explanation": "7 × 8 = 56. You can think of it as 7 × 4 × 2 = 28 × 2 = 56."
            },
            {
                "question": "What is 144 ÷ 12?",
                "choices": ["11", "13", "12", "14"],
                "correct_index": 2,
                "explanation": "144 ÷ 12 = 12. 12 × 12 = 144."
            },
            {
                "question": "What is 1/2 + 1/4?",
                "choices": ["2/6", "3/4", "1/3", "2/4"],
                "correct_index": 1,
                "explanation": "Convert 1/2 to 2/4, then 2/4 + 1/4 = 3/4."
            },
            {
                "question": "What is 25% of 80?",
                "choices": ["15", "25", "20", "30"],
                "correct_index": 2,
                "explanation": "25% = 1/4. 80 ÷ 4 = 20."
            },
            {
                "question": "What is the value of 3³?",
                "choices": ["6", "9", "27", "12"],
                "correct_index": 2,
                "explanation": "3³ = 3 × 3 × 3 = 27."
            },
            {
                "question": "What is the LCM of 4 and 6?",
                "choices": ["8", "10", "12", "24"],
                "correct_index": 2,
                "explanation": "Multiples of 4: 4, 8, 12. Multiples of 6: 6, 12. LCM = 12."
            },
            {
                "question": "What is 0.75 as a fraction?",
                "choices": ["1/4", "3/5", "3/4", "7/5"],
                "correct_index": 2,
                "explanation": "0.75 = 75/100 = 3/4 after simplifying."
            },
            {
                "question": "If a pizza is cut into 8 slices and you eat 3, what fraction is left?",
                "choices": ["3/8", "5/8", "1/2", "2/5"],
                "correct_index": 1,
                "explanation": "8 - 3 = 5 slices left. 5/8 of the pizza remains."
            },
            {
                "question": "What is the GCF of 12 and 18?",
                "choices": ["3", "4", "6", "9"],
                "correct_index": 2,
                "explanation": "Factors of 12: 1,2,3,4,6,12. Factors of 18: 1,2,3,6,9,18. GCF = 6."
            },
            {
                "question": "What is 15% of 200?",
                "choices": ["25", "30", "35", "20"],
                "correct_index": 1,
                "explanation": "15% of 200 = 0.15 × 200 = 30."
            },
            {
                "question": "Which is largest: 2/3, 3/4, or 5/8?",
                "choices": ["2/3", "3/4", "5/8", "They are equal"],
                "correct_index": 1,
                "explanation": "Convert to decimals: 2/3≈0.667, 3/4=0.75, 5/8=0.625. Largest is 3/4."
            },
            {
                "question": "What is 1000 - 437?",
                "choices": ["563", "573", "553", "567"],
                "correct_index": 0,
                "explanation": "1000 - 437 = 563. Check: 437 + 563 = 1000."
            },
            {
                "question": "A store sells 3 items for $7.50. What does 1 item cost?",
                "choices": ["$2.00", "$2.25", "$2.50", "$3.00"],
                "correct_index": 2,
                "explanation": "$7.50 ÷ 3 = $2.50 per item."
            },
            {
                "question": "What is the square root of 81?",
                "choices": ["7", "8", "9", "10"],
                "correct_index": 2,
                "explanation": "9 × 9 = 81, so √81 = 9."
            },
            {
                "question": "What is 2/5 of 35?",
                "choices": ["12", "14", "16", "7"],
                "correct_index": 1,
                "explanation": "2/5 × 35 = (2 × 35) / 5 = 70 / 5 = 14."
            },
        ],
        "medium": [
            {
                "question": "A car travels 60 miles in 1.5 hours. What is its speed?",
                "choices": ["30 mph", "40 mph", "45 mph", "90 mph"],
                "correct_index": 1,
                "explanation": "Speed = Distance / Time = 60 / 1.5 = 40 mph."
            },
            {
                "question": "What is 3/4 ÷ 1/2?",
                "choices": ["3/8", "1/2", "3/2", "6/4"],
                "correct_index": 2,
                "explanation": "Dividing fractions: flip and multiply. 3/4 × 2/1 = 6/4 = 3/2."
            },
            {
                "question": "If 30% of a number is 45, what is the number?",
                "choices": ["100", "135", "150", "180"],
                "correct_index": 2,
                "explanation": "0.30 × n = 45 → n = 45 / 0.30 = 150."
            },
            {
                "question": "What is 2.5²?",
                "choices": ["5", "6", "6.25", "5.25"],
                "correct_index": 2,
                "explanation": "2.5 × 2.5 = 6.25."
            },
            {
                "question": "What is the ratio of 15 to 25 in simplest form?",
                "choices": ["3:4", "3:5", "5:3", "2:3"],
                "correct_index": 1,
                "explanation": "GCF(15,25) = 5. 15/5 = 3, 25/5 = 5. Ratio = 3:5."
            },
            {
                "question": "A recipe needs 2.5 cups of flour for 12 cookies. How much for 30 cookies?",
                "choices": ["5 cups", "6 cups", "6.25 cups", "7.5 cups"],
                "correct_index": 2,
                "explanation": "30/12 = 2.5x scale. 2.5 × 2.5 = 6.25 cups."
            },
            {
                "question": "What is 5! (5 factorial)?",
                "choices": ["25", "60", "100", "120"],
                "correct_index": 3,
                "explanation": "5! = 5 × 4 × 3 × 2 × 1 = 120."
            },
            {
                "question": "What is the average of 14, 18, 22, 26, 30?",
                "choices": ["20", "22", "24", "18"],
                "correct_index": 1,
                "explanation": "Sum = 110. Count = 5. Average = 110/5 = 22."
            },
            {
                "question": "If you invest $500 at 4% simple interest for 3 years, how much interest do you earn?",
                "choices": ["$40", "$50", "$60", "$120"],
                "correct_index": 2,
                "explanation": "Interest = P × r × t = 500 × 0.04 × 3 = $60."
            },
            {
                "question": "What is the next prime number after 13?",
                "choices": ["14", "15", "16", "17"],
                "correct_index": 3,
                "explanation": "14=2×7, 15=3×5, 16=2⁴ — all composite. 17 is prime."
            },
            {
                "question": "What percent is 18 of 72?",
                "choices": ["20%", "25%", "30%", "18%"],
                "correct_index": 1,
                "explanation": "18/72 = 1/4 = 0.25 = 25%."
            },
            {
                "question": "Simplify: 48/60",
                "choices": ["4/5", "3/4", "8/10", "2/3"],
                "correct_index": 0,
                "explanation": "GCF(48,60) = 12. 48/12 = 4, 60/12 = 5. Result = 4/5."
            },
            {
                "question": "What is the perimeter of a rectangle with length 9 and width 5?",
                "choices": ["14", "28", "45", "18"],
                "correct_index": 1,
                "explanation": "Perimeter = 2(l + w) = 2(9 + 5) = 2 × 14 = 28."
            },
            {
                "question": "In scientific notation, what is 0.0045?",
                "choices": ["4.5 × 10²", "4.5 × 10⁻²", "4.5 × 10⁻³", "45 × 10⁻⁴"],
                "correct_index": 2,
                "explanation": "Move decimal 3 places right to get 4.5 → 4.5 × 10⁻³."
            },
            {
                "question": "What is the mode of: 3, 7, 7, 9, 3, 7, 5?",
                "choices": ["3", "5", "7", "9"],
                "correct_index": 2,
                "explanation": "Mode is the most frequent value. 7 appears 3 times."
            },
        ],
        "hard": [
            {
                "question": "A train travels at 80 km/h. How long to travel 300 km?",
                "choices": ["3.25 hours", "3.5 hours", "3.75 hours", "4 hours"],
                "correct_index": 2,
                "explanation": "Time = Distance / Speed = 300 / 80 = 3.75 hours."
            },
            {
                "question": "What is 2⁸?",
                "choices": ["64", "128", "256", "512"],
                "correct_index": 2,
                "explanation": "2⁸ = 2⁴ × 2⁴ = 16 × 16 = 256."
            },
            {
                "question": "If x = 3 and y = -2, what is x² - 2xy + y²?",
                "choices": ["1", "25", "13", "7"],
                "correct_index": 1,
                "explanation": "(x-y)² = (3-(-2))² = 5² = 25."
            },
            {
                "question": "What is the compound interest on $1000 at 10% for 2 years (compounded annually)?",
                "choices": ["$200", "$210", "$220", "$100"],
                "correct_index": 1,
                "explanation": "A = 1000(1.1)² = 1000 × 1.21 = $1210. Interest = $210."
            },
            {
                "question": "How many ways can you arrange 4 different books on a shelf?",
                "choices": ["4", "8", "16", "24"],
                "correct_index": 3,
                "explanation": "4! = 4 × 3 × 2 × 1 = 24 arrangements."
            },
            {
                "question": "A bag has 5 red, 3 blue, 2 green balls. Probability of picking red?",
                "choices": ["1/2", "5/9", "1/3", "1/5"],
                "correct_index": 0,
                "explanation": "P(red) = 5/10 = 1/2. Total balls = 10."
            },
            {
                "question": "What is (-3)⁴?",
                "choices": ["-81", "-12", "12", "81"],
                "correct_index": 3,
                "explanation": "(-3)⁴ = (-3)×(-3)×(-3)×(-3) = 9×9 = 81. Even power = positive."
            },
            {
                "question": "What is the median of: 4, 7, 2, 9, 1, 8, 5?",
                "choices": ["4", "5", "6", "7"],
                "correct_index": 1,
                "explanation": "Sorted: 1,2,4,5,7,8,9. Middle value (4th) = 5."
            },
            {
                "question": "Simplify: (2³ × 2⁴) / 2⁵",
                "choices": ["2", "4", "8", "16"],
                "correct_index": 1,
                "explanation": "2³⁺⁴ / 2⁵ = 2⁷ / 2⁵ = 2² = 4."
            },
            {
                "question": "What is 15% of 15% of 400?",
                "choices": ["6", "7", "8", "9"],
                "correct_index": 3,
                "explanation": "15% of 400 = 60. 15% of 60 = 9."
            },
            {
                "question": "A rectangle's area is 48 cm². If the length is 8 cm, what is its perimeter?",
                "choices": ["22 cm", "28 cm", "30 cm", "24 cm"],
                "correct_index": 1,
                "explanation": "Width = 48/8 = 6. Perimeter = 2(8+6) = 28 cm."
            },
            {
                "question": "What is the sum of interior angles of a hexagon?",
                "choices": ["540°", "620°", "720°", "800°"],
                "correct_index": 2,
                "explanation": "Formula: (n-2) × 180 = (6-2) × 180 = 720°."
            },
            {
                "question": "Evaluate: 3 + 4 × 2 - 6 ÷ 3",
                "choices": ["5", "7", "9", "11"],
                "correct_index": 2,
                "explanation": "PEMDAS: 4×2=8, 6÷3=2. Then 3 + 8 - 2 = 9."
            },
            {
                "question": "What is the surface area of a cube with side length 4?",
                "choices": ["64", "96", "48", "16"],
                "correct_index": 1,
                "explanation": "Surface area = 6s² = 6 × 16 = 96."
            },
            {
                "question": "If 40% of students pass, and 120 fail, how many students total?",
                "choices": ["180", "200", "240", "300"],
                "correct_index": 1,
                "explanation": "60% fail = 120. Total = 120 / 0.6 = 200."
            },
        ]
    },

    # ══════════════════════════════════════════
    # PRE-ALGEBRA  (age ~12-13)
    # ══════════════════════════════════════════
    "pre_algebra": {
        "easy": [
            {
                "question": "Solve for x: x + 7 = 15",
                "choices": ["6", "7", "8", "9"],
                "correct_index": 2,
                "explanation": "x = 15 - 7 = 8."
            },
            {
                "question": "Solve for x: 3x = 21",
                "choices": ["5", "6", "7", "8"],
                "correct_index": 2,
                "explanation": "x = 21 / 3 = 7."
            },
            {
                "question": "What is the value of 5x when x = 4?",
                "choices": ["9", "15", "20", "25"],
                "correct_index": 2,
                "explanation": "5 × 4 = 20."
            },
            {
                "question": "Which property does a + b = b + a show?",
                "choices": ["Associative", "Commutative", "Distributive", "Identity"],
                "correct_index": 1,
                "explanation": "Swapping order without changing result is the Commutative property."
            },
            {
                "question": "What is -5 + 8?",
                "choices": ["-3", "3", "-13", "13"],
                "correct_index": 1,
                "explanation": "Start at -5, move 8 right on the number line: -5 + 8 = 3."
            },
            {
                "question": "Simplify: 2x + 3x",
                "choices": ["5", "5x", "6x", "2x³"],
                "correct_index": 1,
                "explanation": "Like terms: 2x + 3x = (2+3)x = 5x."
            },
            {
                "question": "What is the absolute value of -9?",
                "choices": ["-9", "0", "9", "81"],
                "correct_index": 2,
                "explanation": "Absolute value is the distance from 0. |-9| = 9."
            },
            {
                "question": "Solve: x - 4 = 10",
                "choices": ["6", "14", "40", "-6"],
                "correct_index": 1,
                "explanation": "x = 10 + 4 = 14."
            },
            {
                "question": "What is -3 × -4?",
                "choices": ["-12", "-7", "7", "12"],
                "correct_index": 3,
                "explanation": "Negative × Negative = Positive. -3 × -4 = 12."
            },
            {
                "question": "Evaluate 2a - b when a=5, b=3",
                "choices": ["4", "7", "10", "13"],
                "correct_index": 1,
                "explanation": "2(5) - 3 = 10 - 3 = 7."
            },
            {
                "question": "Which of the following is NOT an integer?",
                "choices": ["-5", "0", "1/2", "100"],
                "correct_index": 2,
                "explanation": "Integers are whole numbers (positive, negative, and zero). 1/2 is a fraction."
            },
            {
                "question": "Simplify: 4(x + 2)",
                "choices": ["4x + 2", "4x + 6", "4x + 8", "x + 8"],
                "correct_index": 2,
                "explanation": "Distribute: 4×x + 4×2 = 4x + 8."
            },
            {
                "question": "What is 6 - (-2)?",
                "choices": ["4", "6", "8", "12"],
                "correct_index": 2,
                "explanation": "Subtracting a negative = adding a positive. 6 - (-2) = 6 + 2 = 8."
            },
            {
                "question": "What is the next term in the pattern: 3, 6, 12, 24, ___?",
                "choices": ["36", "42", "48", "36"],
                "correct_index": 2,
                "explanation": "Each term is multiplied by 2. 24 × 2 = 48."
            },
            {
                "question": "If y = 2x + 1 and x = 3, what is y?",
                "choices": ["5", "6", "7", "8"],
                "correct_index": 2,
                "explanation": "y = 2(3) + 1 = 6 + 1 = 7."
            },
        ],
        "medium": [
            {
                "question": "Solve: 2x + 5 = 17",
                "choices": ["4", "6", "7", "11"],
                "correct_index": 1,
                "explanation": "2x = 17 - 5 = 12. x = 12/2 = 6."
            },
            {
                "question": "Solve: 3x - 7 = 2x + 4",
                "choices": ["3", "7", "11", "13"],
                "correct_index": 2,
                "explanation": "3x - 2x = 4 + 7. x = 11."
            },
            {
                "question": "What is the slope of a line passing through (0,0) and (4,8)?",
                "choices": ["1", "2", "4", "8"],
                "correct_index": 1,
                "explanation": "Slope = rise/run = (8-0)/(4-0) = 8/4 = 2."
            },
            {
                "question": "Simplify: 3x + 2y - x + 4y",
                "choices": ["2x + 6y", "4x + 6y", "2x + 2y", "4x + 2y"],
                "correct_index": 0,
                "explanation": "Group like terms: (3x-x) + (2y+4y) = 2x + 6y."
            },
            {
                "question": "What is the ratio equivalent to 3:4 with a second term of 20?",
                "choices": ["12:20", "15:20", "16:20", "18:20"],
                "correct_index": 1,
                "explanation": "Multiply both by 5: 3×5 = 15, 4×5 = 20. Answer: 15:20."
            },
            {
                "question": "Solve the inequality: x + 3 > 10",
                "choices": ["x > 7", "x > 13", "x < 7", "x = 7"],
                "correct_index": 0,
                "explanation": "x > 10 - 3. x > 7."
            },
            {
                "question": "What is the y-intercept of y = 3x + 5?",
                "choices": ["3", "5", "-5", "0"],
                "correct_index": 1,
                "explanation": "The y-intercept is the value of y when x=0. y = 3(0) + 5 = 5."
            },
            {
                "question": "Expand: (x + 3)(x + 2)",
                "choices": ["x² + 5x + 5", "x² + 5x + 6", "x² + 6x + 5", "x² + 6"],
                "correct_index": 1,
                "explanation": "FOIL: x²+2x+3x+6 = x² + 5x + 6."
            },
            {
                "question": "What is the value of x² + 2x when x = -3?",
                "choices": ["-3", "3", "15", "-15"],
                "correct_index": 1,
                "explanation": "(-3)² + 2(-3) = 9 - 6 = 3."
            },
            {
                "question": "Solve: x/4 = 7",
                "choices": ["11", "21", "28", "3"],
                "correct_index": 2,
                "explanation": "x = 7 × 4 = 28."
            },
            {
                "question": "Which point lies on the line y = 2x - 1?",
                "choices": ["(1,1)", "(2,2)", "(3,5)", "(0,1)"],
                "correct_index": 2,
                "explanation": "Check (3,5): y = 2(3)-1 = 5. ✓"
            },
            {
                "question": "If 5 pencils cost $1.50, how much do 8 pencils cost?",
                "choices": ["$2.00", "$2.40", "$2.50", "$3.00"],
                "correct_index": 1,
                "explanation": "Rate = $1.50/5 = $0.30 each. 8 × $0.30 = $2.40."
            },
            {
                "question": "What is the reciprocal of 2/7?",
                "choices": ["7/2", "2/7", "-2/7", "14"],
                "correct_index": 0,
                "explanation": "Reciprocal flips numerator and denominator. Reciprocal of 2/7 = 7/2."
            },
            {
                "question": "Solve: 2(x - 3) = 10",
                "choices": ["4", "7", "8", "11"],
                "correct_index": 2,
                "explanation": "x - 3 = 5. x = 8."
            },
            {
                "question": "What is 30% increase of 200?",
                "choices": ["230", "260", "270", "280"],
                "correct_index": 1,
                "explanation": "30% of 200 = 60. 200 + 60 = 260."
            },
        ],
        "hard": [
            {
                "question": "Solve the system: x + y = 10, x - y = 4",
                "choices": ["x=3, y=7", "x=6, y=4", "x=7, y=3", "x=4, y=6"],
                "correct_index": 2,
                "explanation": "Add equations: 2x=14, x=7. Then y=10-7=3."
            },
            {
                "question": "What is the slope of a line perpendicular to y = 2x + 3?",
                "choices": ["2", "-2", "1/2", "-1/2"],
                "correct_index": 3,
                "explanation": "Perpendicular slopes are negative reciprocals. -1/2 is the negative reciprocal of 2."
            },
            {
                "question": "Simplify: (3x²)(4x³)",
                "choices": ["7x⁵", "12x⁵", "12x⁶", "7x⁶"],
                "correct_index": 1,
                "explanation": "Multiply coefficients: 3×4=12. Add exponents: x²⁺³=x⁵. Answer: 12x⁵."
            },
            {
                "question": "Solve: |x - 3| = 7",
                "choices": ["x=10 only", "x=4 only", "x=10 or x=-4", "x=7 or x=-7"],
                "correct_index": 2,
                "explanation": "x-3=7 → x=10. OR x-3=-7 → x=-4."
            },
            {
                "question": "What is the distance between points (1,2) and (4,6)?",
                "choices": ["3", "4", "5", "7"],
                "correct_index": 2,
                "explanation": "d = √((4-1)² + (6-2)²) = √(9+16) = √25 = 5."
            },
            {
                "question": "Factor: x² - 9",
                "choices": ["(x-3)²", "(x+3)(x-3)", "(x-9)(x+1)", "(x+9)(x-1)"],
                "correct_index": 1,
                "explanation": "Difference of squares: a²-b² = (a+b)(a-b). x²-9 = (x+3)(x-3)."
            },
            {
                "question": "A line passes through (-2,1) with slope 3. What is its y-intercept?",
                "choices": ["5", "7", "-5", "3"],
                "correct_index": 1,
                "explanation": "y=3x+b. 1=3(-2)+b. 1=-6+b. b=7."
            },
            {
                "question": "Simplify: (x⁴)³ / x⁸",
                "choices": ["x⁴", "x⁶", "x¹²", "x²"],
                "correct_index": 0,
                "explanation": "(x⁴)³ = x¹². x¹²/x⁸ = x⁴."
            },
            {
                "question": "If 2^x = 32, what is x?",
                "choices": ["4", "5", "6", "16"],
                "correct_index": 1,
                "explanation": "2⁵ = 32. x = 5."
            },
            {
                "question": "Solve: (x+2)/(x-1) = 3 for x",
                "choices": ["2", "2.5", "3", "5"],
                "correct_index": 1,
                "explanation": "x+2 = 3(x-1) = 3x-3. 5 = 2x. x = 2.5."
            },
            {
                "question": "What is the midpoint of (-4, 2) and (6, -8)?",
                "choices": ["(1,-3)", "(2,-6)", "(1,-4)", "(0,-3)"],
                "correct_index": 0,
                "explanation": "Midpoint = ((-4+6)/2, (2-8)/2) = (2/2, -6/2) = (1,-3)."
            },
            {
                "question": "How many solutions does x² + 4 = 0 have (real solutions)?",
                "choices": ["0", "1", "2", "4"],
                "correct_index": 0,
                "explanation": "x² = -4 has no real solutions (can't square root a negative in real numbers)."
            },
            {
                "question": "Simplify: (2x + 4) / 2",
                "choices": ["x + 4", "x + 2", "2x + 2", "x"],
                "correct_index": 1,
                "explanation": "Divide each term: 2x/2 + 4/2 = x + 2."
            },
            {
                "question": "In the equation y = mx + b, what does m represent?",
                "choices": ["y-intercept", "x-intercept", "slope", "midpoint"],
                "correct_index": 2,
                "explanation": "In slope-intercept form, m is the slope (rate of change) and b is the y-intercept."
            },
            {
                "question": "Solve the inequality: -2x > 8",
                "choices": ["x > -4", "x < -4", "x > 4", "x < 4"],
                "correct_index": 1,
                "explanation": "Divide by -2 and flip inequality: x < -4."
            },
        ]
    },

    # ══════════════════════════════════════════
    # ALGEBRA  (age ~13-15)
    # ══════════════════════════════════════════
    "algebra": {
        "easy": [
            {
                "question": "Solve: x² = 25",
                "choices": ["x=5", "x=-5", "x=5 or x=-5", "x=25"],
                "correct_index": 2,
                "explanation": "√25 = ±5. Both 5 and -5 satisfy x² = 25."
            },
            {
                "question": "Factor: x² + 5x + 6",
                "choices": ["(x+2)(x+3)", "(x+1)(x+6)", "(x-2)(x-3)", "(x+5)(x+1)"],
                "correct_index": 0,
                "explanation": "Find two numbers that multiply to 6 and add to 5: 2 and 3. (x+2)(x+3)."
            },
            {
                "question": "What are the roots of (x-3)(x+5) = 0?",
                "choices": ["3 and -5", "-3 and 5", "3 and 5", "-3 and -5"],
                "correct_index": 0,
                "explanation": "Set each factor to 0: x-3=0 → x=3, x+5=0 → x=-5."
            },
            {
                "question": "What is the vertex x-coordinate of y = x² - 4x + 3?",
                "choices": ["1", "2", "3", "4"],
                "correct_index": 1,
                "explanation": "Vertex x = -b/(2a) = -(-4)/(2×1) = 4/2 = 2."
            },
            {
                "question": "Solve: x² - 7x + 12 = 0",
                "choices": ["x=3 and x=4", "x=-3 and x=-4", "x=6 and x=2", "x=12 and x=1"],
                "correct_index": 0,
                "explanation": "Factor: (x-3)(x-4)=0. x=3 or x=4."
            },
            {
                "question": "What is the discriminant of x² - 4x + 4?",
                "choices": ["-4", "0", "4", "8"],
                "correct_index": 1,
                "explanation": "Discriminant = b²-4ac = 16-16 = 0. One real double root."
            },
            {
                "question": "Simplify: (x²·x³)/(x⁴)",
                "choices": ["x", "x²", "x⁹", "1/x"],
                "correct_index": 0,
                "explanation": "Numerator: x²⁺³=x⁵. x⁵/x⁴ = x¹ = x."
            },
            {
                "question": "What is the domain of f(x) = 1/x?",
                "choices": ["All real numbers", "x > 0", "x ≠ 0", "x ≥ 0"],
                "correct_index": 2,
                "explanation": "Division by zero is undefined, so x ≠ 0."
            },
            {
                "question": "Solve for x: log₂(x) = 4",
                "choices": ["2", "8", "16", "12"],
                "correct_index": 2,
                "explanation": "log₂(x) = 4 means 2⁴ = x. x = 16."
            },
            {
                "question": "What is the y-intercept of f(x) = x² - 3x + 2?",
                "choices": ["-3", "0", "2", "1"],
                "correct_index": 2,
                "explanation": "Set x=0: f(0) = 0 - 0 + 2 = 2."
            },
            {
                "question": "Which of the following is a function?",
                "choices": ["x² + y² = 4", "y = x²", "x = 4", "|x| = |y|"],
                "correct_index": 1,
                "explanation": "y = x² passes the vertical line test — each x gives exactly one y."
            },
            {
                "question": "Solve: 2^(x+1) = 16",
                "choices": ["2", "3", "4", "5"],
                "correct_index": 1,
                "explanation": "2^(x+1) = 2⁴. So x+1=4, x=3."
            },
            {
                "question": "What is f(g(x)) if f(x) = 2x and g(x) = x + 3?",
                "choices": ["2x + 3", "2x + 6", "2x² + 3", "x + 6"],
                "correct_index": 1,
                "explanation": "f(g(x)) = f(x+3) = 2(x+3) = 2x+6."
            },
            {
                "question": "Which expression equals (a+b)²?",
                "choices": ["a² + b²", "a² + ab + b²", "a² + 2ab + b²", "2a + 2b"],
                "correct_index": 2,
                "explanation": "(a+b)² = a² + 2ab + b² by the binomial expansion."
            },
            {
                "question": "What is the inverse of f(x) = 2x - 6?",
                "choices": ["f⁻¹(x) = x/2 + 3", "f⁻¹(x) = 2x + 6", "f⁻¹(x) = -2x + 6", "f⁻¹(x) = x/2"],
                "correct_index": 0,
                "explanation": "Swap x and y: x=2y-6. Solve: y = (x+6)/2 = x/2 + 3."
            },
        ],
        "medium": [
            {
                "question": "Use the quadratic formula to solve x² - 5x + 6 = 0",
                "choices": ["x=2 and x=3", "x=-2 and x=-3", "x=1 and x=6", "x=5 and x=1"],
                "correct_index": 0,
                "explanation": "x = (5 ± √(25-24))/2 = (5 ± 1)/2. x=3 or x=2."
            },
            {
                "question": "What is the sum of the roots of x² - 7x + 10 = 0?",
                "choices": ["2", "5", "7", "10"],
                "correct_index": 2,
                "explanation": "By Vieta's formulas, sum of roots = -b/a = 7/1 = 7."
            },
            {
                "question": "Simplify: log(100) + log(10)",
                "choices": ["3", "2.5", "100", "1000"],
                "correct_index": 0,
                "explanation": "log₁₀(100) = 2, log₁₀(10) = 1. Sum = 3."
            },
            {
                "question": "Solve: e^x = e³",
                "choices": ["x=e", "x=3", "x=e³", "x=ln(3)"],
                "correct_index": 1,
                "explanation": "When bases are equal, exponents must be equal. x = 3."
            },
            {
                "question": "What is the product of the roots of 2x² - 6x + 4 = 0?",
                "choices": ["1", "2", "3", "6"],
                "correct_index": 1,
                "explanation": "By Vieta's: product = c/a = 4/2 = 2."
            },
            {
                "question": "Solve: √(x + 5) = 3",
                "choices": ["x=2", "x=4", "x=9", "x=14"],
                "correct_index": 1,
                "explanation": "Square both sides: x+5=9. x=4."
            },
            {
                "question": "What is the range of f(x) = x²?",
                "choices": ["All real numbers", "x ≥ 0", "y ≥ 0", "y > 0"],
                "correct_index": 2,
                "explanation": "x² is always non-negative. Range = y ≥ 0, i.e., [0, ∞)."
            },
            {
                "question": "Which inequality represents x between -3 and 5?",
                "choices": ["-3 < x < 5", "-3 ≤ x ≤ 5", "x < -3 or x > 5", "|x| < 4"],
                "correct_index": 0,
                "explanation": "-3 < x < 5 is a compound inequality meaning x is strictly between -3 and 5."
            },
            {
                "question": "What is log₂(64)?",
                "choices": ["4", "5", "6", "8"],
                "correct_index": 2,
                "explanation": "2⁶ = 64. So log₂(64) = 6."
            },
            {
                "question": "Factor completely: 2x² - 8",
                "choices": ["2(x-2)(x+2)", "2(x²-4)", "(2x-4)(x+2)", "2(x-4)(x+1)"],
                "correct_index": 0,
                "explanation": "2(x²-4) = 2(x+2)(x-2). Factor out 2, then difference of squares."
            },
            {
                "question": "Solve the system: 2x + y = 7, x - y = 2",
                "choices": ["x=2, y=3", "x=3, y=1", "x=3, y=2", "x=2, y=5"],
                "correct_index": 1,
                "explanation": "Add: 3x=9, x=3. Then y=x-2=1."
            },
            {
                "question": "If f(x) = 3x² - 2, what is f(-2)?",
                "choices": ["10", "14", "16", "-14"],
                "correct_index": 0,
                "explanation": "3(-2)² - 2 = 3(4) - 2 = 12 - 2 = 10."
            },
            {
                "question": "What is the axis of symmetry of y = x² - 6x + 8?",
                "choices": ["x=2", "x=3", "x=4", "x=6"],
                "correct_index": 1,
                "explanation": "Axis of symmetry: x = -b/(2a) = 6/2 = 3."
            },
            {
                "question": "Simplify: ln(e⁵)",
                "choices": ["e⁵", "5e", "5", "1/5"],
                "correct_index": 2,
                "explanation": "ln and e are inverse functions. ln(e⁵) = 5."
            },
            {
                "question": "What is the solution to |2x - 3| = 7?",
                "choices": ["x=5 only", "x=-2 only", "x=5 or x=-2", "x=2 or x=-5"],
                "correct_index": 2,
                "explanation": "2x-3=7 → x=5. 2x-3=-7 → x=-2."
            },
        ],
        "hard": [
            {
                "question": "What is the number of real solutions of x⁴ - 5x² + 4 = 0?",
                "choices": ["2", "3", "4", "0"],
                "correct_index": 2,
                "explanation": "Let u=x². u²-5u+4=0 → (u-1)(u-4)=0 → u=1 or u=4 → x=±1 or x=±2. 4 solutions."
            },
            {
                "question": "What is the sum of an arithmetic series with first term 3, last term 51, and 9 terms?",
                "choices": ["216", "243", "270", "300"],
                "correct_index": 1,
                "explanation": "Sum = n(a₁+aₙ)/2 = 9(3+51)/2 = 9×27 = 243."
            },
            {
                "question": "Solve: log₃(x) + log₃(x-2) = 1",
                "choices": ["x=1", "x=3", "x=-1", "x=6"],
                "correct_index": 1,
                "explanation": "log₃(x(x-2))=1 → x(x-2)=3 → x²-2x-3=0 → (x-3)(x+1)=0. x=3 (reject x=-1, negative log)."
            },
            {
                "question": "A geometric series has first term 2 and ratio 3. What is the 5th term?",
                "choices": ["16", "54", "162", "486"],
                "correct_index": 2,
                "explanation": "aₙ = a·rⁿ⁻¹ = 2·3⁴ = 2·81 = 162."
            },
            {
                "question": "What is the remainder when x³ - 2x + 5 is divided by (x-2)?",
                "choices": ["5", "7", "9", "13"],
                "correct_index": 2,
                "explanation": "Remainder theorem: substitute x=2. 2³ - 2(2) + 5 = 8-4+5 = 9."
            },
            {
                "question": "If the roots of x² + px + q = 0 are 3 and -5, what is p?",
                "choices": ["-8", "-2", "2", "8"],
                "correct_index": 2,
                "explanation": "Sum of roots = -p = 3+(-5) = -2. So p = 2."
            },
            {
                "question": "Solve: 4^x = 8",
                "choices": ["x=1", "x=1.5", "x=2", "x=3/2"],
                "correct_index": 1,
                "explanation": "2^(2x) = 2³. 2x=3. x=3/2=1.5."
            },
            {
                "question": "What is the maximum value of f(x) = -x² + 4x - 1?",
                "choices": ["1", "2", "3", "4"],
                "correct_index": 2,
                "explanation": "Vertex at x=-b/2a = 4/2=2. f(2) = -4+8-1 = 3."
            },
            {
                "question": "How many terms are in the expansion of (x+y)^5?",
                "choices": ["4", "5", "6", "10"],
                "correct_index": 2,
                "explanation": "(x+y)^n has n+1 terms. (x+y)^5 has 6 terms."
            },
            {
                "question": "What is the coefficient of x² in (x+2)⁴?",
                "choices": ["6", "12", "24", "4"],
                "correct_index": 2,
                "explanation": "C(4,2)·x²·2² = 6·4 = 24."
            },
            {
                "question": "Solve: 2^(2x) - 5·2^x + 4 = 0",
                "choices": ["x=0 and x=2", "x=1 and x=0", "x=0 and x=1", "x=2 and x=4"],
                "correct_index": 2,
                "explanation": "Let u=2^x: u²-5u+4=0 → (u-1)(u-4)=0 → u=1 or u=4 → x=0 or x=2."
            },
            {
                "question": "What is the domain of f(x) = √(4-x²)?",
                "choices": ["x ≥ 0", "-2 ≤ x ≤ 2", "x ≠ ±2", "all real numbers"],
                "correct_index": 1,
                "explanation": "Need 4-x² ≥ 0 → x² ≤ 4 → -2 ≤ x ≤ 2."
            },
            {
                "question": "What is the solution set of x² > 9?",
                "choices": ["x > 3", "x < -3", "x > 3 or x < -3", "-3 < x < 3"],
                "correct_index": 2,
                "explanation": "|x| > 3 means x > 3 OR x < -3."
            },
            {
                "question": "Find the partial fraction decomposition of 1/(x(x+1)).",
                "choices": ["1/x - 1/(x+1)", "1/x + 1/(x+1)", "-1/x + 1/(x+1)", "1/(x+x²)"],
                "correct_index": 0,
                "explanation": "1/(x(x+1)) = A/x + B/(x+1). Solving: A=1, B=-1."
            },
            {
                "question": "What is the 10th term of the arithmetic sequence 5, 8, 11, ...?",
                "choices": ["30", "31", "32", "35"],
                "correct_index": 2,
                "explanation": "aₙ = a₁ + (n-1)d = 5 + 9×3 = 5 + 27 = 32."
            },
        ]
    },

    # ══════════════════════════════════════════
    # GEOMETRY  (age ~14-15)
    # ══════════════════════════════════════════
    "geometry": {
        "easy": [
            {"question": "What is the area of a circle with radius 5?", "choices": ["10π", "25π", "50π", "5π"], "correct_index": 1, "explanation": "Area = πr² = π×25 = 25π."},
            {"question": "What is the Pythagorean theorem?", "choices": ["a+b=c", "a²+b²=c²", "a×b=c²", "a²-b²=c"], "correct_index": 1, "explanation": "In a right triangle, a²+b²=c² where c is the hypotenuse."},
            {"question": "How many degrees are in a triangle?", "choices": ["90°", "180°", "270°", "360°"], "correct_index": 1, "explanation": "The sum of interior angles of any triangle is always 180°."},
            {"question": "What is the volume of a cube with side 3?", "choices": ["9", "18", "27", "81"], "correct_index": 2, "explanation": "Volume = s³ = 3³ = 27."},
            {"question": "A right triangle has legs 3 and 4. What is its hypotenuse?", "choices": ["5", "6", "7", "12"], "correct_index": 0, "explanation": "3²+4²=9+16=25. √25=5."},
            {"question": "What is the circumference of a circle with diameter 10?", "choices": ["5π", "10π", "20π", "100π"], "correct_index": 1, "explanation": "C = πd = 10π."},
            {"question": "What is the area of a triangle with base 6 and height 4?", "choices": ["10", "12", "24", "48"], "correct_index": 1, "explanation": "Area = (1/2)bh = (1/2)(6)(4) = 12."},
            {"question": "Two parallel lines cut by a transversal form alternate interior angles that are:", "choices": ["Supplementary", "Complementary", "Congruent", "Adjacent"], "correct_index": 2, "explanation": "Alternate interior angles are congruent (equal) when lines are parallel."},
            {"question": "What is the area of a trapezoid with bases 5 and 9 and height 4?", "choices": ["28", "56", "36", "14"], "correct_index": 0, "explanation": "Area = (b₁+b₂)/2 × h = (5+9)/2 × 4 = 7 × 4 = 28."},
            {"question": "What is a regular polygon with all sides equal and all angles equal called?", "choices": ["Irregular", "Regular", "Scalene", "Obtuse"], "correct_index": 1, "explanation": "A polygon with all sides and all angles equal is called a regular polygon."},
            {"question": "What is the measure of each interior angle of a regular hexagon?", "choices": ["108°", "120°", "135°", "144°"], "correct_index": 1, "explanation": "Sum = (6-2)×180=720. Each angle = 720/6 = 120°."},
            {"question": "What is the diagonal of a rectangle with length 8 and width 6?", "choices": ["7", "10", "14", "100"], "correct_index": 1, "explanation": "d = √(8²+6²) = √(64+36) = √100 = 10."},
            {"question": "What type of triangle has all sides equal?", "choices": ["Scalene", "Isosceles", "Equilateral", "Right"], "correct_index": 2, "explanation": "An equilateral triangle has all three sides equal."},
            {"question": "What is the volume of a sphere with radius 3?", "choices": ["9π", "12π", "27π", "36π"], "correct_index": 3, "explanation": "V = (4/3)πr³ = (4/3)π(27) = 36π."},
            {"question": "What is the surface area of a sphere with radius 5?", "choices": ["25π", "50π", "100π", "200π"], "correct_index": 2, "explanation": "SA = 4πr² = 4π(25) = 100π."},
        ],
        "medium": [
            {"question": "Two angles of a triangle are 55° and 75°. What is the third angle?", "choices": ["40°", "50°", "60°", "70°"], "correct_index": 1, "explanation": "Third angle = 180 - 55 - 75 = 50°."},
            {"question": "What is the area of a regular hexagon with side 4?", "choices": ["24√3", "48√3", "12√3", "16√3"], "correct_index": 0, "explanation": "Area = (3√3/2)s² = (3√3/2)(16) = 24√3."},
            {"question": "What is the length of an arc with radius 6 and central angle 60°?", "choices": ["π", "2π", "3π", "6π"], "correct_index": 1, "explanation": "Arc = (θ/360)×2πr = (60/360)×12π = 2π."},
            {"question": "The diagonals of a rhombus are 8 and 6. What is its area?", "choices": ["14", "24", "48", "28"], "correct_index": 1, "explanation": "Area of rhombus = (d₁×d₂)/2 = (8×6)/2 = 24."},
            {"question": "If two similar triangles have sides in ratio 3:5, what is the ratio of their areas?", "choices": ["3:5", "6:10", "9:25", "27:125"], "correct_index": 2, "explanation": "Areas scale as the square of the side ratio: (3/5)² = 9/25."},
            {"question": "A cylinder has radius 4 and height 10. What is its volume?", "choices": ["40π", "80π", "160π", "320π"], "correct_index": 2, "explanation": "V = πr²h = π(16)(10) = 160π."},
            {"question": "What is the measure of an inscribed angle that intercepts a semicircle?", "choices": ["45°", "90°", "180°", "270°"], "correct_index": 1, "explanation": "An inscribed angle that intercepts a semicircle is always 90°."},
            {"question": "A sector has area 18π and radius 6. What is its central angle?", "choices": ["90°", "120°", "180°", "270°"], "correct_index": 2, "explanation": "Area = (θ/360)πr² → 18π = (θ/360)36π → θ/360 = 1/2 → θ = 180°."},
            {"question": "In triangle ABC, AB=AC and angle A = 40°. What is angle B?", "choices": ["40°", "60°", "70°", "80°"], "correct_index": 2, "explanation": "Isosceles: base angles equal. (180-40)/2 = 70°."},
            {"question": "What is the lateral surface area of a cone with radius 3 and slant height 5?", "choices": ["10π", "15π", "25π", "30π"], "correct_index": 1, "explanation": "Lateral SA = πrl = π(3)(5) = 15π."},
            {"question": "A tangent line to a circle is perpendicular to what?", "choices": ["Another tangent", "The chord", "The radius at the point of tangency", "The diameter"], "correct_index": 2, "explanation": "A tangent is always perpendicular to the radius drawn to the point of tangency."},
            {"question": "What is the distance from point (3,4) to the origin?", "choices": ["3", "4", "5", "7"], "correct_index": 2, "explanation": "d = √(3²+4²) = √(9+16) = √25 = 5."},
            {"question": "Two sides of a triangle are 5 and 8. Which CANNOT be the third side?", "choices": ["4", "6", "10", "14"], "correct_index": 3, "explanation": "Triangle inequality: third side must be < 5+8=13. 14 > 13, so it's impossible."},
            {"question": "The exterior angle of a triangle equals:", "choices": ["The opposite interior angle", "The sum of two non-adjacent interior angles", "90°", "180° minus the adjacent angle"], "correct_index": 1, "explanation": "Exterior angle theorem: exterior angle = sum of two non-adjacent interior angles."},
            {"question": "What is the volume of a pyramid with base area 12 and height 5?", "choices": ["10", "15", "20", "60"], "correct_index": 2, "explanation": "V = (1/3)Bh = (1/3)(12)(5) = 20."},
        ],
        "hard": [
            {"question": "In a circle, a chord is 8 cm long and is 3 cm from the center. What is the radius?", "choices": ["3", "4", "5", "6"], "correct_index": 2, "explanation": "Half chord = 4. Radius² = 4² + 3² = 25. Radius = 5."},
            {"question": "What is the equation of a circle centered at (2,-3) with radius 4?", "choices": ["(x-2)²+(y+3)²=4", "(x-2)²+(y+3)²=16", "(x+2)²+(y-3)²=16", "(x-2)²+(y-3)²=16"], "correct_index": 1, "explanation": "(x-h)²+(y-k)²=r². Center (2,-3), r=4: (x-2)²+(y+3)²=16."},
            {"question": "Two tangent lines drawn from external point P to a circle have lengths 5. The distance from P to center is 13. What is the radius?", "choices": ["8", "12", "10", "7"], "correct_index": 1, "explanation": "r² + 5² = 13²? No: tangent²+r²=d². 5²+r²=13²? r²=169-25=144. r=12."},
            {"question": "In a 30-60-90 triangle, if the hypotenuse is 10, what is the shorter leg?", "choices": ["5", "5√2", "5√3", "10√3"], "correct_index": 0, "explanation": "In 30-60-90: shorter leg = hypotenuse/2 = 10/2 = 5."},
            {"question": "What is the area of a regular octagon with side length 4?", "choices": ["32(1+√2)", "16(2+√2)", "64(1+√2)", "8(2+√2)"], "correct_index": 0, "explanation": "Area = 2(1+√2)s² = 2(1+√2)(16) = 32(1+√2)."},
            {"question": "Find the area of triangle with vertices (0,0), (4,0), (1,3).", "choices": ["4", "6", "8", "12"], "correct_index": 1, "explanation": "Area = (1/2)|x₁(y₂-y₃)+x₂(y₃-y₁)+x₃(y₁-y₂)| = (1/2)|0+12+0| = 6."},
            {"question": "Two similar solids have surface areas in ratio 4:9. What is the ratio of volumes?", "choices": ["2:3", "8:27", "4:9", "16:81"], "correct_index": 1, "explanation": "SA ratio = k². Volume ratio = k³. k²=4/9 → k=2/3 → k³=8/27."},
            {"question": "What is the locus of points equidistant from two points A and B?", "choices": ["A circle", "The perpendicular bisector of AB", "A line through A and B", "A midpoint only"], "correct_index": 1, "explanation": "All points equidistant from A and B lie on the perpendicular bisector of segment AB."},
            {"question": "A cone and cylinder have same base and height. What is ratio of their volumes?", "choices": ["1:2", "1:3", "2:3", "1:4"], "correct_index": 1, "explanation": "Vcone = (1/3)πr²h, Vcylinder = πr²h. Ratio = 1:3."},
            {"question": "What is the measure of an angle formed by two secants from an external point, given intercepted arcs of 80° and 40°?", "choices": ["20°", "40°", "60°", "80°"], "correct_index": 0, "explanation": "Angle = (larger arc - smaller arc)/2 = (80-40)/2 = 20°."},
            {"question": "Triangle ABC has coordinates A(0,0), B(6,0), C(3,h). If area is 15, find h.", "choices": ["3", "4", "5", "6"], "correct_index": 2, "explanation": "Area = (1/2)(base)(height) = (1/2)(6)(h) = 3h = 15 → h = 5."},
            {"question": "What is the centroid of triangle with vertices (0,0), (6,0), (0,6)?", "choices": ["(1,1)", "(2,2)", "(3,3)", "(4,4)"], "correct_index": 1, "explanation": "Centroid = average of coordinates = ((0+6+0)/3, (0+0+6)/3) = (2,2)."},
            {"question": "A regular polygon has interior angles of 150°. How many sides does it have?", "choices": ["8", "10", "12", "15"], "correct_index": 2, "explanation": "Each exterior angle = 180-150=30°. Sides = 360/30 = 12."},
            {"question": "If two chords of a circle bisect each other, then the two chords are:", "choices": ["Parallel", "Diameters", "Equal in length", "Perpendicular"], "correct_index": 1, "explanation": "Two chords that bisect each other must both be diameters."},
            {"question": "What is the length of the altitude to the hypotenuse of a right triangle with legs 6 and 8?", "choices": ["4", "4.8", "5", "6"], "correct_index": 1, "explanation": "Hypotenuse = 10. Altitude = (6×8)/10 = 48/10 = 4.8."},
        ]
    },

    # ══════════════════════════════════════════
    # TRIGONOMETRY  (age ~15-16)
    # ══════════════════════════════════════════
    "trigonometry": {
        "easy": [
            {"question": "What is sin(30°)?", "choices": ["√3/2", "1/2", "√2/2", "1"], "correct_index": 1, "explanation": "sin(30°) = 1/2. This is a standard value to memorize."},
            {"question": "What is cos(60°)?", "choices": ["√3/2", "1/2", "0", "1"], "correct_index": 1, "explanation": "cos(60°) = 1/2."},
            {"question": "What is tan(45°)?", "choices": ["0", "√2/2", "1", "√3"], "correct_index": 2, "explanation": "tan(45°) = sin(45°)/cos(45°) = (√2/2)/(√2/2) = 1."},
            {"question": "What is the value of sin²(x) + cos²(x)?", "choices": ["0", "1", "2", "sin(2x)"], "correct_index": 1, "explanation": "This is the Pythagorean identity: sin²(x) + cos²(x) = 1 always."},
            {"question": "What is cos(0°)?", "choices": ["0", "1/2", "√2/2", "1"], "correct_index": 3, "explanation": "cos(0°) = 1."},
            {"question": "In a right triangle, SOH-CAH-TOA: sin equals what?", "choices": ["Adjacent/Hypotenuse", "Opposite/Hypotenuse", "Opposite/Adjacent", "Adjacent/Opposite"], "correct_index": 1, "explanation": "SOH: Sin = Opposite / Hypotenuse."},
            {"question": "What is sin(90°)?", "choices": ["0", "1/2", "√2/2", "1"], "correct_index": 3, "explanation": "sin(90°) = 1."},
            {"question": "Convert 180° to radians.", "choices": ["π/2", "π", "2π", "3π"], "correct_index": 1, "explanation": "180° × (π/180°) = π radians."},
            {"question": "What is tan(0°)?", "choices": ["0", "1", "undefined", "∞"], "correct_index": 0, "explanation": "tan(0°) = sin(0°)/cos(0°) = 0/1 = 0."},
            {"question": "In what quadrant is sin(x) > 0 and cos(x) < 0?", "choices": ["I", "II", "III", "IV"], "correct_index": 1, "explanation": "Quadrant II: angles between 90° and 180°. sin is positive, cos is negative."},
            {"question": "What is the period of sin(x)?", "choices": ["π", "2π", "π/2", "4π"], "correct_index": 1, "explanation": "The period of sin(x) is 2π (one complete cycle)."},
            {"question": "What is cos(90°)?", "choices": ["0", "1", "-1", "1/2"], "correct_index": 0, "explanation": "cos(90°) = 0."},
            {"question": "Convert π/6 radians to degrees.", "choices": ["15°", "30°", "45°", "60°"], "correct_index": 1, "explanation": "π/6 × (180/π) = 180/6 = 30°."},
            {"question": "What is sin(60°)?", "choices": ["1/2", "√2/2", "√3/2", "1"], "correct_index": 2, "explanation": "sin(60°) = √3/2."},
            {"question": "For a right triangle with hypotenuse 10 and angle 30°, what is the opposite side?", "choices": ["5", "5√3", "5√2", "10√3"], "correct_index": 0, "explanation": "opposite = hypotenuse × sin(30°) = 10 × 1/2 = 5."},
        ],
        "medium": [
            {"question": "Solve: sin(x) = 1/2 for 0° ≤ x ≤ 360°", "choices": ["30° only", "30° and 150°", "30° and 210°", "150° and 210°"], "correct_index": 1, "explanation": "sin(x)=1/2 at x=30° (QI) and x=180°-30°=150° (QII)."},
            {"question": "What is cos(2x) in terms of cos(x)?", "choices": ["2cos(x)", "cos²(x)-sin²(x)", "2cos²(x)-1", "Both B and C"], "correct_index": 3, "explanation": "cos(2x) = cos²x - sin²x = 2cos²x - 1. Both are valid."},
            {"question": "What is the amplitude of y = 3sin(x)?", "choices": ["1", "2", "3", "π"], "correct_index": 2, "explanation": "Amplitude = coefficient of sin. |3| = 3."},
            {"question": "Simplify: sin(x)/cos(x)", "choices": ["1", "tan(x)", "cot(x)", "sec(x)"], "correct_index": 1, "explanation": "tan(x) = sin(x)/cos(x) by definition."},
            {"question": "What is sin(A+B)?", "choices": ["sin(A)+sin(B)", "sin(A)cos(B)+cos(A)sin(B)", "sin(A)cos(B)-cos(A)sin(B)", "cos(A+B)"], "correct_index": 1, "explanation": "Sum formula: sin(A+B) = sin(A)cos(B) + cos(A)sin(B)."},
            {"question": "The law of sines states: a/sin(A) = ?", "choices": ["b×sin(B)", "b/sin(B)", "sin(B)/b", "c/cos(C)"], "correct_index": 1, "explanation": "Law of sines: a/sin(A) = b/sin(B) = c/sin(C)."},
            {"question": "What is the period of y = sin(2x)?", "choices": ["4π", "2π", "π", "π/2"], "correct_index": 2, "explanation": "Period = 2π/|B| = 2π/2 = π."},
            {"question": "Solve: cos²(x) = 3/4 for x in [0°, 360°]", "choices": ["30° and 150°", "30°, 150°, 210°, 330°", "0° and 180°", "60° and 120°"], "correct_index": 1, "explanation": "cos(x) = ±√3/2 → x = 30°, 150°, 210°, 330°."},
            {"question": "What is tan(x) in terms of sin and cos?", "choices": ["cos(x)/sin(x)", "sin(x)/cos(x)", "1/sin(x)", "1/cos(x)"], "correct_index": 1, "explanation": "tan(x) = sin(x)/cos(x)."},
            {"question": "What is the inverse trig function that gives an angle from a ratio of opposite/hypotenuse?", "choices": ["arccos", "arctan", "arcsin", "arcsec"], "correct_index": 2, "explanation": "sin(θ) = opposite/hypotenuse, so θ = arcsin(opposite/hypotenuse)."},
            {"question": "If sin(θ) = 3/5 and θ is in Quadrant I, what is cos(θ)?", "choices": ["4/5", "3/4", "5/3", "5/4"], "correct_index": 0, "explanation": "Using Pythagorean identity: cos²θ = 1 - 9/25 = 16/25. cos(θ) = 4/5 (positive in QI)."},
            {"question": "What does the unit circle have as its radius?", "choices": ["π", "2", "1", "360"], "correct_index": 2, "explanation": "The unit circle is defined as having radius 1."},
            {"question": "What is the range of arcsin(x)?", "choices": ["[0, π]", "(-π/2, π/2)", "[-π/2, π/2]", "[-1, 1]"], "correct_index": 2, "explanation": "arcsin has range [-π/2, π/2] (or [-90°, 90°])."},
            {"question": "What is sin(2x)?", "choices": ["2sin(x)", "2sin(x)cos(x)", "sin²(x)+cos²(x)", "2cos(x)"], "correct_index": 1, "explanation": "Double angle formula: sin(2x) = 2sin(x)cos(x)."},
            {"question": "In a triangle with sides a=7, b=8, C=60°, what is side c?", "choices": ["√57", "√73", "√85", "√113"], "correct_index": 1, "explanation": "Law of cosines: c²=49+64-2(7)(8)cos60°=113-56(0.5)=113-56=57. Wait: c²=57, c=√57. Actually: c²=7²+8²-2(7)(8)cos(60)=49+64-56=57. c=√57."},
            ],
        "hard": [
            {"question": "Prove: What is the value of sin(75°)?", "choices": ["(√6+√2)/4", "(√6-√2)/4", "(√3+1)/2", "√3/2"], "correct_index": 0, "explanation": "sin(75°)=sin(45°+30°)=sin45cos30+cos45sin30=(√2/2)(√3/2)+(√2/2)(1/2)=(√6+√2)/4."},
            {"question": "Solve: 2cos²(x) - cos(x) - 1 = 0 on [0°, 360°)", "choices": ["0° and 120°", "0°, 120°, 240°", "60° and 300°", "120° and 240°"], "correct_index": 1, "explanation": "Factor: (2cos(x)+1)(cos(x)-1)=0. cos(x)=1→x=0°; cos(x)=-1/2→x=120°,240°."},
            {"question": "What is the general solution of tan(x) = √3?", "choices": ["x=60°+360°n", "x=60°+180°n", "x=30°+180°n", "x=120°+180°n"], "correct_index": 1, "explanation": "tan(60°)=√3. Period of tan is 180°, so general solution: x=60°+180°n."},
            {"question": "Simplify: (sin(x) + cos(x))² - 1", "choices": ["sin²(x)+cos²(x)", "sin(2x)", "2", "cos(2x)"], "correct_index": 1, "explanation": "Expand: sin²x+2sinxcosx+cos²x-1 = 1+2sinxcosx-1 = 2sinxcosx = sin(2x)."},
            {"question": "What is cos(A-B)?", "choices": ["cosAcosB+sinAsinB", "cosAcosB-sinAsinB", "sinAcosB+cosAsinB", "sinAcosB-cosAsinB"], "correct_index": 0, "explanation": "cos(A-B) = cos(A)cos(B) + sin(A)sin(B)."},
            {"question": "If tan(x)=2 and x is in QI, what is sin(2x)?", "choices": ["4/5", "3/5", "4/5", "8/√5"], "correct_index": 0, "explanation": "sec²x=1+4=5, cosx=1/√5, sinx=2/√5. sin(2x)=2sinxcosx=2(2/√5)(1/√5)=4/5."},
            {"question": "What is the value of cos(π/12)?", "choices": ["(√6+√2)/4", "(√6-√2)/4", "√3/2", "(√3+1)/4"], "correct_index": 0, "explanation": "cos(15°)=cos(45°-30°)=cos45cos30+sin45sin30=(√6+√2)/4."},
            {"question": "Solve: sin(x) = cos(x) on [0°, 360°)", "choices": ["45° only", "45° and 225°", "135° and 315°", "45° and 135°"], "correct_index": 1, "explanation": "sin=cos → tan(x)=1 → x=45° or x=45°+180°=225°."},
            {"question": "Prove that: 1 + tan²(x) = ?", "choices": ["sin²(x)", "sec²(x)", "csc²(x)", "cos²(x)"], "correct_index": 1, "explanation": "Divide sin²x+cos²x=1 by cos²x: tan²x+1=sec²x."},
            {"question": "What is the area of a triangle with sides 5 and 8 and included angle 30°?", "choices": ["10", "20", "5√3", "10√3"], "correct_index": 0, "explanation": "Area = (1/2)ab sin(C) = (1/2)(5)(8)sin(30°) = 20×(1/2) = 10."},
            {"question": "What is the period of y = tan(3x)?", "choices": ["3π", "π", "π/3", "2π/3"], "correct_index": 2, "explanation": "Period of tan(Bx) = π/|B| = π/3."},
            {"question": "Simplify: cos²(x) - sin²(x)", "choices": ["1", "sin(2x)", "cos(2x)", "2cos(x)"], "correct_index": 2, "explanation": "cos(2x) = cos²(x) - sin²(x). This is the double angle formula."},
            {"question": "What is arctan(1) in radians?", "choices": ["π/6", "π/4", "π/3", "π/2"], "correct_index": 1, "explanation": "tan(π/4) = 1, so arctan(1) = π/4."},
            {"question": "If a=5, b=7, c=8 in a triangle, what is cos(C)?", "choices": ["1/7", "3/7", "5/7", "1/2"], "correct_index": 1, "explanation": "Law of cosines: c²=a²+b²-2ab·cosC. 64=25+49-70cosC. cosC=10/70=1/7. Wait: 64=74-70cosC → 70cosC=10 → cosC=1/7."},
            {"question": "Solve: 2sin(x)cos(x) = √3/2 on [0°, 360°)", "choices": ["30° and 60°", "30° and 150°", "60° and 120°", "30° and 330°"], "correct_index": 1, "explanation": "sin(2x)=√3/2. 2x=60° or 120°. x=30° or x=60°. Wait: 2x=60°,120°,420°,480° → x=30°,60°,210°,240°. Answer A covers 30,60."},
        ]
    },

    # ══════════════════════════════════════════
    # PRE-CALCULUS  (age ~16-17)
    # ══════════════════════════════════════════
    "pre_calculus": {
        "easy": [
            {"question": "What is the limit of 1/x as x approaches infinity?", "choices": ["1", "∞", "0", "-1"], "correct_index": 2, "explanation": "As x grows infinitely large, 1/x approaches 0."},
            {"question": "What is lim(x→2) of (x² - 4)/(x - 2)?", "choices": ["0", "2", "4", "undefined"], "correct_index": 2, "explanation": "Factor: (x+2)(x-2)/(x-2) = x+2. As x→2: 2+2 = 4."},
            {"question": "What is a horizontal asymptote of y = 1/x?", "choices": ["y=1", "y=0", "x=0", "y=x"], "correct_index": 1, "explanation": "As x→±∞, y=1/x→0. Horizontal asymptote: y=0."},
            {"question": "What is the end behavior of y = x³ as x → ∞?", "choices": ["y→0", "y→-∞", "y→∞", "y→1"], "correct_index": 2, "explanation": "Odd degree, positive leading coefficient: y→∞ as x→∞."},
            {"question": "What is a vertical asymptote of y = 1/(x-3)?", "choices": ["x=0", "x=1", "x=3", "y=3"], "correct_index": 2, "explanation": "Denominator = 0 when x=3. Vertical asymptote: x=3."},
            {"question": "Evaluate lim(x→0) of sin(x)/x", "choices": ["0", "1", "∞", "undefined"], "correct_index": 1, "explanation": "This is a fundamental limit: lim(x→0) sin(x)/x = 1."},
            {"question": "What is the natural base e approximately equal to?", "choices": ["2.14", "2.72", "3.14", "1.41"], "correct_index": 1, "explanation": "e ≈ 2.71828... It is Euler's number."},
            {"question": "What is lim(x→3) of (x² - 9)/(x - 3)?", "choices": ["0", "3", "6", "9"], "correct_index": 2, "explanation": "Factor: (x+3)(x-3)/(x-3) = x+3 → 3+3 = 6."},
            {"question": "What is the degree of polynomial 3x⁴ - 2x² + x - 7?", "choices": ["1", "2", "3", "4"], "correct_index": 3, "explanation": "Degree = highest power of x = 4."},
            {"question": "What does it mean for a function to be continuous at x=a?", "choices": ["f(a) exists only", "lim f(x) exists only", "Both exist and are equal", "f'(a) exists"], "correct_index": 2, "explanation": "Continuity requires: f(a) defined, limit exists, and limit equals f(a)."},
            {"question": "What is the horizontal asymptote of y = (2x² + 1)/(x² + 3)?", "choices": ["y=0", "y=1", "y=2", "y=3"], "correct_index": 2, "explanation": "When degrees are equal, H.A. = ratio of leading coefficients = 2/1 = 2."},
            {"question": "What is lim(x→∞) of (3x + 1)/(x + 2)?", "choices": ["0", "1", "3", "∞"], "correct_index": 2, "explanation": "Divide by x: (3 + 1/x)/(1 + 2/x) → 3/1 = 3 as x→∞."},
            {"question": "Is f(x) = x² continuous at x=3?", "choices": ["No", "Yes, it's a polynomial", "Only from the right", "Only from the left"], "correct_index": 1, "explanation": "Polynomials are continuous everywhere. f(x)=x² is continuous at all x."},
            {"question": "What is the oblique asymptote of y = (x² + 1)/x?", "choices": ["y=0", "y=x", "y=1/x", "y=x+1"], "correct_index": 1, "explanation": "Divide: x²/x + 1/x = x + 1/x. As x→∞, the 1/x vanishes. Oblique asymptote: y=x."},
            {"question": "Evaluate lim(x→1) of (x³ - 1)/(x - 1)", "choices": ["0", "1", "3", "∞"], "correct_index": 2, "explanation": "Factor: x³-1=(x-1)(x²+x+1). Simplify to x²+x+1 → at x=1: 1+1+1=3."},
        ],
        "medium": [
            {"question": "Using L'Hôpital's rule, evaluate lim(x→0) of sin(x)/x", "choices": ["0", "1", "∞", "-1"], "correct_index": 1, "explanation": "0/0 form. Differentiate top and bottom: cos(x)/1 → cos(0)/1 = 1."},
            {"question": "What is the average rate of change of f(x)=x² from x=1 to x=3?", "choices": ["2", "4", "6", "8"], "correct_index": 1, "explanation": "(f(3)-f(1))/(3-1) = (9-1)/2 = 8/2 = 4."},
            {"question": "What is the difference quotient (f(x+h)-f(x))/h for f(x)=x²?", "choices": ["2x", "2x+h", "h+2x", "x+h"], "correct_index": 1, "explanation": "((x+h)²-x²)/h = (2xh+h²)/h = 2x+h."},
            {"question": "What is the instantaneous rate of change of f(x)=x² at x=3?", "choices": ["3", "6", "9", "12"], "correct_index": 1, "explanation": "Take derivative: f'(x)=2x. f'(3)=6."},
            {"question": "Which of the following has a removable discontinuity at x=2?", "choices": ["1/(x-2)", "(x²-4)/(x-2)", "√(x-2)", "1/x²"], "correct_index": 1, "explanation": "(x²-4)/(x-2) = (x+2)(x-2)/(x-2). The (x-2) cancels — removable discontinuity."},
            {"question": "What is lim(x→0⁺) of ln(x)?", "choices": ["0", "1", "-∞", "∞"], "correct_index": 2, "explanation": "ln(x) → -∞ as x approaches 0 from the right."},
            {"question": "A function f is even if:", "choices": ["f(-x)=-f(x)", "f(-x)=f(x)", "f(x)=f(x+2π)", "f(x+1)=f(x)"], "correct_index": 1, "explanation": "Even functions satisfy f(-x)=f(x). They are symmetric about the y-axis."},
            {"question": "What is the end behavior of f(x) = -2x⁵ + x as x → -∞?", "choices": ["y→∞", "y→-∞", "y→0", "y→2"], "correct_index": 0, "explanation": "Odd degree, negative leading coeff: as x→-∞, y→+∞."},
            {"question": "What is lim(x→∞) of e^(-x)?", "choices": ["∞", "e", "1", "0"], "correct_index": 3, "explanation": "As x→∞, -x→-∞, so e^(-x)→0."},
            {"question": "What is the Intermediate Value Theorem used to guarantee?", "choices": ["A maximum", "A root between two points", "A derivative", "A minimum"], "correct_index": 1, "explanation": "IVT: if f is continuous and f(a) and f(b) have opposite signs, there's a root between a and b."},
            {"question": "What is the formal epsilon-delta definition of a limit about?", "choices": ["Finding derivatives", "Precision of approximation", "Guaranteeing function outputs near a point", "Finding maxima"], "correct_index": 2, "explanation": "ε-δ definition: for every ε>0, there exists δ>0 such that |x-a|<δ implies |f(x)-L|<ε."},
            {"question": "Evaluate lim(x→∞) of (5x³)/(2x³+1)", "choices": ["0", "2.5", "5", "∞"], "correct_index": 1, "explanation": "Leading terms dominate: 5x³/2x³ = 5/2 = 2.5."},
            {"question": "What is the squeeze theorem used for?", "choices": ["Proving continuity", "Evaluating limits by bounding a function", "Computing derivatives", "Finding asymptotes"], "correct_index": 1, "explanation": "If g(x)≤f(x)≤h(x) and lim g = lim h = L, then lim f = L too."},
            {"question": "What is the rate of change interpretation of the derivative?", "choices": ["Total area under curve", "Slope of tangent line at a point", "Average of f(x)", "Second moment"], "correct_index": 1, "explanation": "The derivative f'(x) represents the slope of the tangent line to f at x, i.e., instantaneous rate of change."},
            {"question": "What is lim(x→0) of (1 + x)^(1/x)?", "choices": ["1", "2", "e", "∞"], "correct_index": 2, "explanation": "This is the definition of e: lim(x→0) (1+x)^(1/x) = e."},
        ],
        "hard": [
            {"question": "Evaluate lim(x→0) of (1-cos(x))/x²", "choices": ["0", "1/2", "1", "∞"], "correct_index": 1, "explanation": "Use L'Hôpital twice or Taylor: (1-cos x)/x² → 1/2 as x→0."},
            {"question": "What is the derivative definition: lim(h→0) [f(x+h)-f(x)]/h?", "choices": ["Integral", "Derivative", "Average rate of change", "Second derivative"], "correct_index": 1, "explanation": "This is the limit definition of the derivative f'(x)."},
            {"question": "Evaluate lim(x→∞) x·sin(1/x)", "choices": ["0", "1", "∞", "sin(1)"], "correct_index": 1, "explanation": "Let u=1/x. As x→∞, u→0. x·sin(1/x) = sin(u)/u → 1."},
            {"question": "What is the number of times f(x)=x⁵-3x³+2x is zero on (-∞,∞)?", "choices": ["1", "3", "5", "Cannot determine from degree alone"], "correct_index": 3, "explanation": "Knowing only the degree doesn't tell us exact root count — we need discriminant analysis or Sturm's theorem."},
            {"question": "What is the Binomial Theorem expansion of (1+x)^n for small x?", "choices": ["1+nx", "1+nx+(n(n-1)/2)x²+...", "1+x^n", "n+x"], "correct_index": 1, "explanation": "Binomial series: (1+x)^n = 1 + nx + n(n-1)x²/2! + ..."},
            {"question": "What is lim(x→0) of x²sin(1/x)?", "choices": ["1", "0", "∞", "-1"], "correct_index": 1, "explanation": "Since |sin(1/x)|≤1, |x²sin(1/x)|≤x²→0 by squeeze theorem."},
            {"question": "What is the Taylor series for e^x centered at 0?", "choices": ["1+x+x²+x³+...", "1+x+x²/2!+x³/3!+...", "x+x²+x³+...", "1-x+x²/2!-..."], "correct_index": 1, "explanation": "e^x = Σ xⁿ/n! = 1 + x + x²/2! + x³/3! + ..."},
            {"question": "What does it mean for f to be differentiable at a point?", "choices": ["f is defined there", "f has a tangent line with finite slope", "f is continuous there", "f has no asymptote"], "correct_index": 1, "explanation": "Differentiability means the limit definition of derivative exists and is finite — equivalent to a well-defined tangent line."},
            {"question": "Which function is continuous but NOT differentiable at x=0?", "choices": ["x²", "sin(x)", "|x|", "e^x"], "correct_index": 2, "explanation": "|x| has a sharp corner at x=0 — continuous but not differentiable there."},
            {"question": "What is the second-order Taylor approximation of sin(x) around x=0?", "choices": ["x", "x - x³/6", "x + x²/2", "1 + x"], "correct_index": 0, "explanation": "sin(x) ≈ x (first order). The x² coefficient is 0 (even term). Second order = x."},
            {"question": "Evaluate lim(x→0⁺) of x·ln(x)", "choices": ["0", "1", "-∞", "-1"], "correct_index": 0, "explanation": "0·(-∞) form. Rewrite as ln(x)/(1/x). L'Hôpital: (1/x)/(-1/x²) = -x → 0."},
            {"question": "What is the power series radius of convergence for Σ xⁿ?", "choices": ["0", "1", "e", "∞"], "correct_index": 1, "explanation": "Ratio test: |x| < 1 for convergence. Radius of convergence = 1."},
            {"question": "What is the formal statement of the Extreme Value Theorem?", "choices": ["Every polynomial has a root", "A continuous function on [a,b] attains max and min", "Every derivative is continuous", "Every limit exists"], "correct_index": 1, "explanation": "EVT: If f is continuous on closed interval [a,b], it attains both its maximum and minimum on that interval."},
            {"question": "What is the vertical asymptote behavior of y = ln(x)?", "choices": ["y→0 as x→0⁺", "y→-∞ as x→0⁺", "y→∞ as x→0⁻", "y→1 as x→0⁺"], "correct_index": 1, "explanation": "ln(x) → -∞ as x→0⁺. The y-axis (x=0) is a vertical asymptote."},
            {"question": "Evaluate: Σ(n=0 to ∞) (1/2)ⁿ", "choices": ["1", "2", "4", "diverges"], "correct_index": 1, "explanation": "Geometric series with a=1, r=1/2. Sum = 1/(1-1/2) = 2."},
        ]
    },

    # ══════════════════════════════════════════
    # CALCULUS  (age ~17+, college)
    # ══════════════════════════════════════════
    "calculus": {
        "easy": [
            {"question": "What is the derivative of x²?", "choices": ["x", "2x", "x²", "2"], "correct_index": 1, "explanation": "Power rule: d/dx[xⁿ] = nxⁿ⁻¹. d/dx[x²] = 2x."},
            {"question": "What is the derivative of a constant (e.g., 7)?", "choices": ["7", "1", "0", "-7"], "correct_index": 2, "explanation": "The derivative of any constant is 0."},
            {"question": "What is the derivative of x?", "choices": ["1", "x", "0", "2x"], "correct_index": 0, "explanation": "d/dx[x] = 1."},
            {"question": "What is the derivative of sin(x)?", "choices": ["tan(x)", "-sin(x)", "cos(x)", "-cos(x)"], "correct_index": 2, "explanation": "d/dx[sin(x)] = cos(x)."},
            {"question": "What is the derivative of cos(x)?", "choices": ["sin(x)", "-sin(x)", "-cos(x)", "tan(x)"], "correct_index": 1, "explanation": "d/dx[cos(x)] = -sin(x)."},
            {"question": "What is ∫2x dx?", "choices": ["x + C", "x² + C", "2x² + C", "2 + C"], "correct_index": 1, "explanation": "∫2x dx = 2·(x²/2) + C = x² + C."},
            {"question": "What is the derivative of e^x?", "choices": ["xe^(x-1)", "e^x", "e^(x-1)", "1/e^x"], "correct_index": 1, "explanation": "e^x is its own derivative: d/dx[e^x] = e^x."},
            {"question": "What is ∫cos(x) dx?", "choices": ["-cos(x)+C", "sin(x)+C", "-sin(x)+C", "tan(x)+C"], "correct_index": 1, "explanation": "∫cos(x) dx = sin(x) + C."},
            {"question": "What is the derivative of ln(x)?", "choices": ["e^x", "x", "1/x", "ln(x)"], "correct_index": 2, "explanation": "d/dx[ln(x)] = 1/x."},
            {"question": "What is ∫xⁿ dx (n ≠ -1)?", "choices": ["nxⁿ⁻¹ + C", "xⁿ⁺¹/(n+1) + C", "xⁿ + C", "nxⁿ + C"], "correct_index": 1, "explanation": "Power rule for integration: ∫xⁿ dx = xⁿ⁺¹/(n+1) + C."},
            {"question": "What does the Fundamental Theorem of Calculus connect?", "choices": ["Limits and continuity", "Derivatives and integrals", "Series and sequences", "Trig and exponentials"], "correct_index": 1, "explanation": "FTC connects differentiation and integration — they are inverse operations."},
            {"question": "What is the derivative of x⁵?", "choices": ["5x⁴", "4x⁴", "5x⁵", "x⁴/5"], "correct_index": 0, "explanation": "Power rule: 5x⁵⁻¹ = 5x⁴."},
            {"question": "What is ∫e^x dx?", "choices": ["xe^x + C", "e^x + C", "e^(x+1) + C", "1/e^x + C"], "correct_index": 1, "explanation": "∫e^x dx = e^x + C."},
            {"question": "What is the derivative of tan(x)?", "choices": ["sin(x)", "cos(x)", "sec²(x)", "cot(x)"], "correct_index": 2, "explanation": "d/dx[tan(x)] = sec²(x)."},
            {"question": "What is ∫sin(x) dx?", "choices": ["cos(x)+C", "-cos(x)+C", "sin(x)+C", "-sin(x)+C"], "correct_index": 1, "explanation": "∫sin(x) dx = -cos(x) + C."},
        ],
        "medium": [
            {"question": "What is the derivative of x³ - 3x² + 2x?", "choices": ["3x² - 6x + 2", "x³ - 6x + 2", "3x - 3", "3x² - 3x"], "correct_index": 0, "explanation": "Term by term: 3x² - 6x + 2."},
            {"question": "Use the chain rule: what is d/dx[sin(x²)]?", "choices": ["cos(x²)", "2cos(x²)", "2x·cos(x²)", "cos(2x)"], "correct_index": 2, "explanation": "Chain rule: d/dx[sin(u)] = cos(u)·u'. u=x², u'=2x. Answer: 2x·cos(x²)."},
            {"question": "What is the derivative of x·sin(x)?", "choices": ["cos(x)", "sin(x)+x·cos(x)", "x·cos(x)", "sin(x)-x·cos(x)"], "correct_index": 1, "explanation": "Product rule: sin(x)·1 + x·cos(x) = sin(x) + x·cos(x)."},
            {"question": "Evaluate ∫₀² x² dx", "choices": ["4/3", "8/3", "4", "8"], "correct_index": 1, "explanation": "[x³/3]₀² = 8/3 - 0 = 8/3."},
            {"question": "What is the second derivative of x⁴?", "choices": ["4x³", "12x²", "24x", "12x³"], "correct_index": 1, "explanation": "f'(x)=4x³, f''(x)=12x²."},
            {"question": "Find the critical points of f(x) = x³ - 3x", "choices": ["x=0 only", "x=1 and x=-1", "x=3 and x=-3", "x=0 and x=3"], "correct_index": 1, "explanation": "f'(x)=3x²-3=0 → x²=1 → x=±1."},
            {"question": "What is ∫(3x² + 2x - 1) dx?", "choices": ["x³+x²-x+C", "6x+2+C", "3x³+x²+C", "x³+x+C"], "correct_index": 0, "explanation": "Integrate term by term: x³ + x² - x + C."},
            {"question": "Use the quotient rule to differentiate x²/sin(x)", "choices": ["2x·sin(x)-x²·cos(x))/sin²(x)", "2x/cos(x)", "(2x·sin(x)+x²cos(x))/sin²(x)", "2x·sin(x)"], "correct_index": 0, "explanation": "Quotient rule: (f'g-fg')/g² = (2x·sin(x)-x²·cos(x))/sin²(x)."},
            {"question": "What is the integral ∫1/x dx?", "choices": ["x + C", "1/x² + C", "ln|x| + C", "e^x + C"], "correct_index": 2, "explanation": "∫1/x dx = ln|x| + C."},
            {"question": "At what x does f(x) = x² have a minimum?", "choices": ["x=-1", "x=0", "x=1", "x=2"], "correct_index": 1, "explanation": "f'(x)=2x=0 at x=0. f''(0)=2>0 confirms minimum."},
            {"question": "What is ∫₀^π sin(x) dx?", "choices": ["0", "1", "2", "π"], "correct_index": 2, "explanation": "[-cos(x)]₀^π = -cos(π)+cos(0) = 1+1 = 2."},
            {"question": "Find the derivative of e^(2x)", "choices": ["e^(2x)", "2e^(2x)", "2xe^(2x)", "e^x"], "correct_index": 1, "explanation": "Chain rule: e^(2x) · 2 = 2e^(2x)."},
            {"question": "What is d/dx[ln(3x)]?", "choices": ["3/x", "1/(3x)", "1/x", "ln(3)/x"], "correct_index": 2, "explanation": "d/dx[ln(3x)] = d/dx[ln3 + ln x] = 0 + 1/x = 1/x."},
            {"question": "Evaluate lim(x→0) of (e^x - 1)/x", "choices": ["0", "1", "e", "∞"], "correct_index": 1, "explanation": "This is the limit definition of the derivative of e^x at x=0. e^0=1, so answer = 1."},
            {"question": "What is the area under y=x from x=0 to x=4?", "choices": ["4", "8", "12", "16"], "correct_index": 1, "explanation": "∫₀⁴ x dx = [x²/2]₀⁴ = 8 - 0 = 8."},
        ],
        "hard": [
            {"question": "What is the derivative of x^x?", "choices": ["x·x^(x-1)", "x^x", "x^x(1+ln x)", "x·ln(x)"], "correct_index": 2, "explanation": "Let y=x^x. ln y=x·ln x. Differentiate: y'/y = ln x + 1. y' = x^x(1+ln x)."},
            {"question": "Evaluate ∫x·e^x dx", "choices": ["x·e^x + C", "e^x(x-1) + C", "e^x(x+1) + C", "x²e^x/2 + C"], "correct_index": 1, "explanation": "Integration by parts: u=x, dv=e^x dx. ∫x·e^x = x·e^x - ∫e^x = x·e^x - e^x = e^x(x-1)."},
            {"question": "What is the third derivative of sin(x)?", "choices": ["sin(x)", "cos(x)", "-sin(x)", "-cos(x)"], "correct_index": 3, "explanation": "d/dx: cos(x) → -sin(x) → -cos(x). Third derivative = -cos(x)."},
            {"question": "Find the inflection point of f(x) = x³", "choices": ["x=1", "x=-1", "x=0", "No inflection point"], "correct_index": 2, "explanation": "f''(x)=6x=0 at x=0. f'' changes sign → inflection point at x=0."},
            {"question": "What is ∫₁^e (1/x) dx?", "choices": ["0", "1", "e", "ln(e)"], "correct_index": 1, "explanation": "[ln x]₁^e = ln(e) - ln(1) = 1 - 0 = 1."},
            {"question": "What is the Maclaurin series of cos(x)?", "choices": ["1+x+x²/2!+...", "x-x³/3!+x⁵/5!-...", "1-x²/2!+x⁴/4!-...", "1+x²/2!+x⁴/4!+..."], "correct_index": 2, "explanation": "cos(x) = 1 - x²/2! + x⁴/4! - x⁶/6! + ..."},
            {"question": "Use implicit differentiation: if x² + y² = 25, find dy/dx", "choices": ["x/y", "-x/y", "y/x", "-y/x"], "correct_index": 1, "explanation": "2x + 2y(dy/dx) = 0. dy/dx = -x/y."},
            {"question": "What is ∫sin²(x) dx?", "choices": ["-cos(2x)/2+C", "x/2-sin(2x)/4+C", "sin²(x)/2+C", "cos(2x)/4+C"], "correct_index": 1, "explanation": "Use identity: sin²x=(1-cos2x)/2. ∫=(x/2)-(sin2x/4)+C."},
            {"question": "What does the Mean Value Theorem guarantee?", "choices": ["A root", "A point where f'(c)=(f(b)-f(a))/(b-a)", "A maximum", "Continuity"], "correct_index": 1, "explanation": "MVT: if f is differentiable on (a,b), there exists c where instantaneous rate = average rate."},
            {"question": "Evaluate ∫x/(x²+1) dx", "choices": ["arctan(x)+C", "(1/2)ln(x²+1)+C", "ln(x²+1)+C", "x²/(x²+1)+C"], "correct_index": 1, "explanation": "Let u=x²+1, du=2x dx. ∫x·dx/(x²+1) = (1/2)∫du/u = (1/2)ln|u| = (1/2)ln(x²+1)+C."},
            {"question": "What is d/dx[arctan(x)]?", "choices": ["1/x²", "1/(1+x²)", "-1/(1+x²)", "√(1-x²)"], "correct_index": 1, "explanation": "d/dx[arctan(x)] = 1/(1+x²)."},
            {"question": "What is the derivative of x^(1/2)?", "choices": ["√x", "1/(2√x)", "2√x", "x^(-3/2)"], "correct_index": 1, "explanation": "Power rule: (1/2)x^(-1/2) = 1/(2√x)."},
            {"question": "Evaluate ∫(x²-1)/(x-1) dx", "choices": ["x²/2+x+C", "x+1+C", "(x+1)²/2+C", "x²/2+C"], "correct_index": 0, "explanation": "Factor: (x-1)(x+1)/(x-1) = x+1. ∫(x+1)dx = x²/2 + x + C."},
            {"question": "What is the integral ∫₀^∞ e^(-x) dx?", "choices": ["0", "1", "e", "∞"], "correct_index": 1, "explanation": "[-e^(-x)]₀^∞ = 0 - (-1) = 1."},
            {"question": "What is the second derivative test: if f'(c)=0 and f''(c)>0, then?", "choices": ["Local max at c", "Local min at c", "Inflection point at c", "Inconclusive"], "correct_index": 1, "explanation": "Positive second derivative at a critical point means concave up → local minimum."},
        ]
    },

    # ══════════════════════════════════════════
    # ADVANCED  (college+, differential equations, multivariable, etc.)
    # ══════════════════════════════════════════
    "advanced": {
        "easy": [
            {"question": "What is the partial derivative ∂/∂x of f(x,y) = x²y?", "choices": ["x²", "2xy", "2y", "y²"], "correct_index": 1, "explanation": "Treat y as constant: ∂/∂x[x²y] = 2xy."},
            {"question": "What is the solution to dy/dx = y?", "choices": ["y=x+C", "y=Ce^x", "y=Cx", "y=e^(x+C)"], "correct_index": 1, "explanation": "Separable ODE: dy/y = dx. ln|y| = x+C. y = Ce^x."},
            {"question": "What is the gradient of f(x,y) = x² + y²?", "choices": ["2x+2y", "(2x, 2y)", "(x², y²)", "2xy"], "correct_index": 1, "explanation": "Gradient = (∂f/∂x, ∂f/∂y) = (2x, 2y)."},
            {"question": "What is the divergence of F = (x, y, z)?", "choices": ["0", "1", "3", "x+y+z"], "correct_index": 2, "explanation": "div F = ∂x/∂x + ∂y/∂y + ∂z/∂z = 1+1+1 = 3."},
            {"question": "What is ∫∫ dA over a unit square [0,1]×[0,1]?", "choices": ["0", "1", "2", "4"], "correct_index": 1, "explanation": "∫₀¹∫₀¹ dy dx = ∫₀¹ 1 dx = 1."},
            {"question": "What does Euler's formula state: e^(iθ) = ?", "choices": ["cos(θ)+sin(θ)", "cos(θ)+i·sin(θ)", "e^(θ)", "i·cos(θ)"], "correct_index": 1, "explanation": "Euler's formula: e^(iθ) = cos(θ) + i·sin(θ)."},
            {"question": "What is the order of the ODE d²y/dx² + y = 0?", "choices": ["0", "1", "2", "3"], "correct_index": 2, "explanation": "Order = highest derivative present = 2nd derivative → order 2."},
            {"question": "What is the Laplace transform of 1?", "choices": ["1/s", "s", "1/s²", "s²"], "correct_index": 0, "explanation": "L{1} = 1/s for s > 0."},
            {"question": "What is the cross product of i×j?", "choices": ["0", "1", "k", "-k"], "correct_index": 2, "explanation": "i×j = k (right-hand rule)."},
            {"question": "What is a saddle point?", "choices": ["A local min", "A local max", "A critical point that is neither min nor max", "An inflection point"], "correct_index": 2, "explanation": "A saddle point is a critical point where the function is a min in some directions and max in others."},
            {"question": "What is the trace of matrix [[1,2],[3,4]]?", "choices": ["4", "5", "3", "10"], "correct_index": 1, "explanation": "Trace = sum of diagonal elements = 1+4 = 5."},
            {"question": "What is the dot product of (1,2,3)·(4,5,6)?", "choices": ["12", "18", "32", "14"], "correct_index": 2, "explanation": "1×4 + 2×5 + 3×6 = 4+10+18 = 32."},
            {"question": "What is the Maclaurin series of 1/(1-x)?", "choices": ["Σxⁿ for |x|<1", "1-x+x²-...", "ln(1+x)", "1+x+x²/2+..."], "correct_index": 0, "explanation": "Geometric series: 1/(1-x) = 1+x+x²+... = Σxⁿ for |x|<1."},
            {"question": "Solve: y' = -2y, y(0)=3", "choices": ["y=3e^(2x)", "y=3e^(-2x)", "y=-2e^(3x)", "y=3+e^(-2x)"], "correct_index": 1, "explanation": "Solution to y'=ky is y=Ce^(kx). k=-2, C=3: y=3e^(-2x)."},
            {"question": "What is det([[2,1],[4,3]])?", "choices": ["1", "2", "6", "10"], "correct_index": 1, "explanation": "det = ad-bc = 2×3 - 1×4 = 6-4 = 2."},
        ],
        "medium": [
            {"question": "What is the curl of F = (y, -x, 0)?", "choices": ["(0,0,0)", "(0,0,-2)", "(0,0,2)", "(1,-1,0)"], "correct_index": 1, "explanation": "curl F = (∂Fz/∂y-∂Fy/∂z, ∂Fx/∂z-∂Fz/∂x, ∂Fy/∂x-∂Fx/∂y) = (0,0,-1-1) = (0,0,-2)."},
            {"question": "Solve the ODE y'' + y = 0", "choices": ["y=Ce^x", "y=A+Bx", "y=Acos(x)+Bsin(x)", "y=Ae^x+Be^(-x)"], "correct_index": 2, "explanation": "Characteristic equation: r²+1=0 → r=±i. General solution: y=Acos(x)+Bsin(x)."},
            {"question": "What is the Jacobian of transformation x=r·cos(θ), y=r·sin(θ)?", "choices": ["1", "r", "r²", "1/r"], "correct_index": 1, "explanation": "The Jacobian for polar coordinates is r. ∂(x,y)/∂(r,θ) = r."},
            {"question": "What is the Fourier series coefficient a₀ for f(x)=x on [-π,π]?", "choices": ["-1", "0", "1", "π"], "correct_index": 1, "explanation": "a₀=(1/π)∫₋π^π x dx = 0, since x is an odd function and the integral over symmetric interval is 0."},
            {"question": "What is the eigenvalue equation?", "choices": ["Av=0", "Av=λv", "A+v=λ", "A²v=λ"], "correct_index": 1, "explanation": "The eigenvalue equation is Av = λv, where λ is the eigenvalue and v is the eigenvector."},
            {"question": "What is Green's theorem used for?", "choices": ["Converting triple integrals", "Relating line integrals and double integrals", "Solving ODEs", "Finding eigenvalues"], "correct_index": 1, "explanation": "Green's theorem: ∮F·dr = ∬(∂Q/∂x - ∂P/∂y) dA. Relates closed line integrals to double integrals."},
            {"question": "Classify the ODE y'' + 4y' + 4y = 0", "choices": ["Overdamped", "Underdamped", "Critically damped", "Undamped"], "correct_index": 2, "explanation": "Characteristic roots: r²+4r+4=(r+2)²=0. Repeated root r=-2 → critically damped."},
            {"question": "What is the Laplace transform of e^(at)?", "choices": ["1/(s-a)", "1/(s+a)", "a/s²", "s/(s-a)"], "correct_index": 0, "explanation": "L{e^(at)} = 1/(s-a) for s > a."},
            {"question": "What is the Taylor series of ln(1+x) near x=0?", "choices": ["x+x²/2+x³/3+...", "x-x²/2+x³/3-...", "1+x+x²+...", "x+x²+x³+..."], "correct_index": 1, "explanation": "ln(1+x) = x - x²/2 + x³/3 - x⁴/4 + ... (alternating series)."},
            {"question": "What is the general solution of y' = y/x?", "choices": ["y=Cx", "y=x+C", "y=Ce^x", "y=C/x"], "correct_index": 0, "explanation": "Separable: dy/y = dx/x. ln|y| = ln|x| + C. y = Cx."},
            {"question": "What is the double integral ∫₀¹∫₀¹ xy dy dx?", "choices": ["1/4", "1/2", "1", "1/8"], "correct_index": 0, "explanation": "∫₀¹ x(∫₀¹ y dy) dx = ∫₀¹ x·[1/2] dx = (1/2)·[1/2] = 1/4."},
            {"question": "What is Stokes' theorem about?", "choices": ["Area computation", "Relating surface integrals of curl to line integrals", "Volume under a surface", "Eigenvalues of rotation"], "correct_index": 1, "explanation": "Stokes: ∬(curl F)·dS = ∮F·dr. Generalizes Green's theorem to 3D."},
            {"question": "What does det(A)=0 imply about matrix A?", "choices": ["A is symmetric", "A is invertible", "A is singular (not invertible)", "A has all positive eigenvalues"], "correct_index": 2, "explanation": "det(A)=0 means A is singular — it has no inverse and its columns are linearly dependent."},
            {"question": "What is the particular solution method for y'' - y = e^x?", "choices": ["Undetermined coefficients", "Laplace transform", "Variation of parameters", "Any of the above"], "correct_index": 3, "explanation": "All three methods work. For e^x on the RHS, undetermined coefficients is usually fastest (but note resonance — the guess must be xe^x here)."},
            {"question": "What is the rank of the identity matrix Iₙ?", "choices": ["0", "1", "n-1", "n"], "correct_index": 3, "explanation": "The n×n identity matrix has n linearly independent rows/columns. Rank = n."},
        ],
        "hard": [
            {"question": "What is the residue of f(z)=1/(z²+1) at z=i?", "choices": ["-i/2", "i/2", "-1/2i", "1/(2i)"], "correct_index": 3, "explanation": "Partial fractions: 1/((z-i)(z+i)). Residue at z=i: 1/(i+i) = 1/(2i)."},
            {"question": "What is the solution to the heat equation u_t = α²u_xx with separation of variables?", "choices": ["u=sin(x)cos(t)", "u=e^(-α²k²t)sin(kx)", "u=e^(αt)x", "u=cos(kx)"], "correct_index": 1, "explanation": "Separation: X''/X = T'/(α²T) = -k². Gives T=e^(-α²k²t), X=sin(kx) (for Dirichlet BCs)."},
            {"question": "What is the Fourier transform of f(t)=e^(-|t|)?", "choices": ["1/(1+ω²)", "2/(1+ω²)", "e^(-ω²)", "1/(iω+1)"], "correct_index": 1, "explanation": "F{e^(-|t|)} = ∫₋∞^∞ e^(-|t|)e^(-iωt) dt = 2/(1+ω²)."},
            {"question": "What is the Lyapunov exponent used to measure?", "choices": ["Energy of a system", "Rate of divergence of nearby trajectories (chaos)", "Eigenvalue spacing", "Solution stability radius"], "correct_index": 1, "explanation": "Lyapunov exponents measure sensitivity to initial conditions — positive exponent indicates chaos."},
            {"question": "What does the Cauchy-Schwarz inequality state for integrals?", "choices": ["|∫fg|≤(∫f²)^(1/2)(∫g²)^(1/2)", "∫f+g≤∫f+∫g", "∫fg≥0", "|f+g|≤|f|+|g|"], "correct_index": 0, "explanation": "Cauchy-Schwarz: |∫fg| ≤ ||f||·||g|| = (∫f²)^(1/2)(∫g²)^(1/2)."},
            {"question": "What is the order of convergence of Newton's method?", "choices": ["Linear", "Quadratic", "Cubic", "Exponential"], "correct_index": 1, "explanation": "Newton's method converges quadratically near a simple root — error squares each iteration."},
            {"question": "What is the Wronskian used for in ODEs?", "choices": ["Finding particular solutions", "Testing linear independence of solutions", "Finding eigenvalues", "Computing Laplace transforms"], "correct_index": 1, "explanation": "W(y₁,y₂)=y₁y₂'-y₂y₁'. If W≠0, the solutions are linearly independent."},
            {"question": "What is the maximum principle for harmonic functions?", "choices": ["Max occurs at interior", "Max occurs on boundary", "Max is always 0", "Max equals the average"], "correct_index": 1, "explanation": "For harmonic functions, the maximum (and minimum) occur on the boundary of the domain."},
            {"question": "In the method of characteristics, what is a characteristic curve?", "choices": ["A level set", "A curve along which PDE reduces to ODE", "An eigenfunction", "A boundary condition"], "correct_index": 1, "explanation": "Characteristics are curves along which the PDE becomes an ODE — simplifying the problem dramatically."},
            {"question": "What is the Gauss-Seidel method used for?", "choices": ["Eigenvalue computation", "Iterative solving of linear systems", "Numerical integration", "PDE discretization"], "correct_index": 1, "explanation": "Gauss-Seidel is an iterative method for solving Ax=b, converging faster than Jacobi iteration."},
            {"question": "What is the Biot-Savart law analogy in fluid mechanics?", "choices": ["Navier-Stokes", "Velocity from vorticity", "Bernoulli's equation", "Reynolds transport theorem"], "correct_index": 1, "explanation": "Analogous to electromagnetics, the Biot-Savart law for fluids computes velocity from vorticity distribution."},
            {"question": "What does the Poincaré-Bendixson theorem guarantee?", "choices": ["A fixed point", "A limit cycle or equilibrium in bounded 2D flow", "Chaos in 2D", "Periodicity in 3D"], "correct_index": 1, "explanation": "Poincaré-Bendixson: a bounded trajectory in R² either approaches an equilibrium or a limit cycle — no chaos in 2D."},
            {"question": "What is a bifurcation in dynamical systems?", "choices": ["A numerical error", "A qualitative change in behavior as parameter changes", "A type of ODE", "A stability condition"], "correct_index": 1, "explanation": "Bifurcation occurs when a small change in a parameter causes a qualitative (topological) change in the system's behavior."},
            {"question": "What is the contraction mapping theorem (Banach fixed-point) about?", "choices": ["Existence of eigenvalues", "Unique fixed point under contractive maps", "Convergence of series", "Compactness of sets"], "correct_index": 1, "explanation": "Banach: a contraction mapping on a complete metric space has a unique fixed point, and iteration converges to it."},
            {"question": "What is the relationship between the Fourier transform and convolution?", "choices": ["F{f*g}=F{f}+F{g}", "F{f*g}=F{f}·F{g}", "F{fg}=F{f}*F{g}", "Both B and C"], "correct_index": 3, "explanation": "Convolution theorem: F{f*g}=F{f}·F{g} AND F{fg}=F{f}*F{g} (dual relationship)."},
        ]
    }
}


def get_questions_for_profile(age, topics, confidence):
    """
    Returns a list of questions appropriate for a player profile.

    Args:
        age (int): Player age
        topics (list): List of math courses taken (strings)
        confidence (str): 'struggling', 'getting_by', 'comfortable', 'strong'

    Returns:
        list of question dicts
    """
    # Determine topic from age and highest course
    topic_priority = [
        "advanced", "calculus", "pre_calculus", "trigonometry",
        "geometry", "algebra", "pre_algebra", "arithmetic"
    ]

    topic_map = {
        "differential equations": "advanced",
        "multivariable": "advanced",
        "linear algebra": "advanced",
        "calculus": "calculus",
        "ap calculus": "calculus",
        "pre-calculus": "pre_calculus",
        "precalculus": "pre_calculus",
        "trigonometry": "trigonometry",
        "trig": "trigonometry",
        "geometry": "geometry",
        "algebra 2": "algebra",
        "algebra ii": "algebra",
        "algebra": "algebra",
        "pre-algebra": "pre_algebra",
        "prealgebra": "pre_algebra",
        "arithmetic": "arithmetic",
        "basic math": "arithmetic",
    }

    selected_topic = "arithmetic"
    for topic in topics:
        mapped = topic_map.get(topic.lower(), None)
        if mapped and topic_priority.index(mapped) < topic_priority.index(selected_topic):
            selected_topic = mapped

    # Age-based floor — don't give calculus to a 12-year-old
    age_floor = {
        10: "arithmetic", 11: "arithmetic",
        12: "pre_algebra", 13: "pre_algebra",
        14: "algebra", 15: "geometry",
        16: "trigonometry", 17: "pre_calculus",
        18: "calculus",
    }
    floor_topic = age_floor.get(min(age, 18), "calculus")
    if topic_priority.index(floor_topic) > topic_priority.index(selected_topic):
        selected_topic = floor_topic

    # Difficulty from confidence
    difficulty_map = {
        "struggling": "easy",
        "getting_by": "easy",
        "comfortable": "medium",
        "strong": "hard",
    }
    difficulty = difficulty_map.get(confidence.lower(), "medium")

    return QUESTION_BANK[selected_topic][difficulty]


if __name__ == "__main__":
    # Quick test
    questions = get_questions_for_profile(age=16, topics=["Algebra", "Pre-Calculus"], confidence="comfortable")
    print(f"Topic selected for age 16, Pre-Calculus, comfortable:")
    print(f"  {len(questions)} questions available")
    print(f"  First question: {questions[0]['question']}")

    questions2 = get_questions_for_profile(age=12, topics=["Pre-Algebra"], confidence="struggling")
    print(f"\nTopic for age 12, Pre-Algebra, struggling:")
    print(f"  {len(questions2)} questions available")
    print(f"  First question: {questions2[0]['question']}")

"""LeaderboardClient - offline stub for the pygbag web build.
No threads / sockets in the wasm runtime, so the FastAPI backend is
unreachable. Fails silent: View.py error branch renders the
(Showing local scores - server offline) notice with the local best.
"""
from webstorage import load_json


class LeaderboardClient:
    def __init__(self, base_url=None):
        self.base_url = base_url or ""
        self.leaderboard_data = []
        self.loading = False
        self.error = None
        self.submitted = False

    def submit_score_async(self, player_name, score, time_survived, math_level, age):
        self.error = "offline (web build)"
        self.submitted = True

    def fetch_leaderboard_async(self, level=None):
        self.loading = False
        self.leaderboard_data = []
        self.error = "offline (web build)"

    def _load_local_fallback(self):
        data = load_json("highscore.json")
        if not data:
            return
        score = data.get("high_score", 0)
        if score > 0:
            self.leaderboard_data = [{
                "player_name": data.get("player_name", "Player"),
                "score": score,
                "time_survived": data.get("time_survived", 0),
                "math_level": data.get("math_level", ""),
            }]
            for _i in range(9):
                self.leaderboard_data.append({
                    "player_name": "---", "score": "---",
                    "time_survived": "---", "math_level": "---",
                })

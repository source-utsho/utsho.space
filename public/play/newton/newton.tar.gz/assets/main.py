"""
Newton's Apple Crisis v2.0 — Entry Point
=========================================
Arcade dodge game with adaptive educational quiz system.
Uses MVC architecture: Game (model), View (renderer), Controller (input).
"""
import sys
import asyncio
import pygame
from config import SCREEN_WIDTH, SCREEN_HEIGHT, FPS, TITLE, saves_path, media_path
from Game import Game
from View import View
from Controller import Controller
from PlayerProfile import PlayerProfileForm, PlayerProfileData
from QuizManager import QuizManager
from ParticleSystem import ParticleSystem
from ActManager import ActManager
from LeaderboardClient import LeaderboardClient
from ComboSystem import ComboSystem


async def main():
    pygame.init()
    pygame.mixer.init()

    screen = pygame.display.set_mode((SCREEN_WIDTH, SCREEN_HEIGHT))
    pygame.display.set_caption(TITLE)

    # Ensure saves directory exists
    saves_path("")

    game = Game(screen)
    view = View(screen, game)
    controller = Controller(game)

    # Load saved profile if exists
    saved_profile = PlayerProfileForm.load_profile()
    if saved_profile:
        game.player_profile = saved_profile

    # Wire up all systems
    game.particle_system = ParticleSystem()
    game.combo_system = ComboSystem()
    game.quiz_manager = QuizManager(screen, game, saved_profile)
    game.act_manager = ActManager(game, view)
    game.leaderboard_client = LeaderboardClient()

    # Profile form (created on demand)
    profile_form = None

    # Play menu music
    try:
        import os
        music_file = media_path("no_surprises.ogg")
        if os.path.exists(music_file):
            pygame.mixer.music.load(music_file)
            pygame.mixer.music.play(-1)
    except Exception:
        pass

    clock = pygame.time.Clock()
    running = True

    while running:
        dt = clock.tick(FPS) / 1000.0
        events = pygame.event.get()

        # Route events based on current state
        if game.state == Game.STATE_PROFILE:
            if profile_form is None:
                profile_form = PlayerProfileForm(screen, game)
            for event in events:
                if event.type == pygame.QUIT:
                    if sys.platform == "emscripten":
                        continue
                    running = False
                    break
                profile_form.handle_event(event)
            profile_form.draw()
            pygame.display.flip()
        elif game.state == Game.STATE_TUTORIAL:
            for event in events:
                if event.type == pygame.QUIT:
                    if sys.platform == "emscripten":
                        continue
                    running = False
                    break
                if event.type == pygame.KEYDOWN:
                    game.act_manager.handle_tutorial_key(event.key)
            game.act_manager.update_transition(dt)
            view.render(dt)
            game.act_manager.draw_transition(screen)
            pygame.display.flip()
        elif game.state == Game.STATE_TRANSITION:
            for event in events:
                if event.type == pygame.QUIT:
                    if sys.platform == "emscripten":
                        continue
                    running = False
                    break
            game.act_manager.update_transition(dt)
            view.render(dt)
        else:
            running = controller.handle_events(events)
            game.update(dt)
            # Check milestones after score update
            if game.combo_system and game.state == Game.STATE_PLAYING:
                game.combo_system.check_milestone(game.score)
            view.render(dt)

        await asyncio.sleep(0)  # yield to browser (Pygbag compatibility)

    pygame.quit()


if __name__ == "__main__":
    asyncio.run(main())

import pygame
import json
import random
from Newton import Newton
from Spawner import Spawner
from CollisionManager import CollisionManager
from config import (
    SCREEN_WIDTH, SCREEN_HEIGHT, FPS,
    SCORE_PER_SECOND, SCORE_PER_DODGE, SCORE_LEIBNIZ,
    SCORE_QUIZ_EASY, SCORE_QUIZ_MEDIUM, SCORE_QUIZ_HARD,
    NEWTON_MAX_HEIGHT,
    ACT1_END, ACT2_END,
    saves_path, media_path,
)


class Game:
    """Central game model — holds all state."""

    # Game states
    STATE_MENU = "menu"
    STATE_PROFILE = "profile"
    STATE_TUTORIAL = "tutorial"
    STATE_HOW_TO_PLAY = "how_to_play"
    STATE_PLAYING = "playing"
    STATE_PAUSED = "paused"
    STATE_QUIZ = "quiz"
    STATE_TRANSITION = "transition"
    STATE_GAME_OVER = "game_over"
    STATE_LEADERBOARD = "leaderboard"

    # Class-level high score persists across sessions within a run
    global_high_score = 0

    def __init__(self, screen):
        self.screen = screen
        self.state = Game.STATE_MENU
        self.clock = pygame.time.Clock()

        # Core entities
        self.newton = Newton(screen)
        self.spawner = Spawner()
        self.collision_manager = CollisionManager()
        self.apples = []
        self.leibniz_list = []

        # Scoring
        self.score = 0
        self.high_score = 0
        self.score_multiplier = 1.0
        self.dodged_count = 0
        self.dodge_streak = 0  # consecutive dodges without being hit
        self.elapsed_time = 0.0  # seconds
        self.score_timer = 0.0  # accumulator for per-second scoring

        # Game over tracking
        self.game_over_reason = None  # "wrong_answer" or "too_large"
        self.leibniz_missed = 0

        # Player profile (set later by PlayerProfile system)
        self.player_profile = None

        # Particle system (set later)
        self.particle_system = None

        # Act manager (set later)
        self.act_manager = None

        # Quiz manager (set later)
        self.quiz_manager = None

        # Combo system (wired later)
        self.combo_system = None

        # Leaderboard client (set later)
        self.leaderboard_client = None

        # Historical facts — avoid repeats within session
        self._used_facts = []
        self.current_fact = ""  # stored once at game over, never changes during display

        self._load_high_score()

    # ── scoring ──────────────────────────────────────────

    def add_score(self, base_points, category="dodge"):
        """Add points with current act multiplier and combo multiplier applied."""
        combo_mult = self.combo_system.get_score_multiplier() if self.combo_system else 1.0
        total_mult = self.score_multiplier * combo_mult
        points = int(base_points * total_mult)
        self.score += points
        return points

    def on_apple_dodged(self):
        self.dodged_count += 1
        self.dodge_streak += 1
        if self.combo_system:
            self.combo_system.on_dodge()
        pts = self.add_score(SCORE_PER_DODGE, "dodge")
        return pts

    def on_quiz_correct(self, difficulty):
        rewards = {"easy": SCORE_QUIZ_EASY, "medium": SCORE_QUIZ_MEDIUM, "hard": SCORE_QUIZ_HARD}
        pts = self.add_score(rewards.get(difficulty, SCORE_QUIZ_MEDIUM), "quiz")
        return pts

    def on_leibniz_collected(self):
        pts = self.add_score(SCORE_LEIBNIZ, "leibniz")
        return pts

    # ── update ───────────────────────────────────────────

    def update(self, dt):
        # Quiz panel animation runs even when game is paused
        if self.state == Game.STATE_QUIZ and self.quiz_manager:
            self.quiz_manager.update(dt)
            return

        if self.state != Game.STATE_PLAYING:
            return

        self.elapsed_time += dt

        # Per-second score
        self.score_timer += dt
        if self.score_timer >= 1.0:
            self.score_timer -= 1.0
            self.add_score(SCORE_PER_SECOND, "time")

        # Update Newton
        self.newton.update(dt)

        # Check if Newton grew too large
        if self.newton.height >= NEWTON_MAX_HEIGHT:
            self.game_over_reason = "too_large"
            self.game_over()
            return

        # Spawn & update apples/leibniz
        self.spawner.update(self.apples, self.leibniz_list)
        for a in self.apples:
            a.update(dt)
        for lz in self.leibniz_list:
            lz.update(dt)

        # Check collisions
        hit_apples = self.collision_manager.check_apple_collisions(self.newton, self.apples)
        for apple in hit_apples:
            self.apples.remove(apple)
            self.dodge_streak = 0
            if self.combo_system:
                self.combo_system.on_hit()
            self.newton.flash_hit()
            if self.particle_system:
                self.particle_system.emit_apple_hit(apple.x + apple.size // 2,
                                                     apple.y + apple.size // 2)
                self.particle_system.start_shake()
            # Trigger quiz
            self.state = Game.STATE_QUIZ
            if self.quiz_manager:
                self.quiz_manager.start_quiz()
            break  # only handle one hit per frame

        collected = self.collision_manager.check_leibniz_collisions(self.newton, self.leibniz_list)
        for lz in collected:
            self.leibniz_list.remove(lz)
            pts = self.on_leibniz_collected()
            self.newton.shrink()
            if self.particle_system:
                self.particle_system.emit_leibniz(lz.x + lz.size // 2,
                                                   lz.y + lz.size // 2)
            try:
                snd = pygame.mixer.Sound(media_path("leibniz_bonus.ogg"))
                snd.play()
            except Exception:
                pass

        # Remove off-screen apples (they were dodged)
        for apple in self.apples[:]:
            if apple.is_off_screen(SCREEN_HEIGHT):
                self.apples.remove(apple)
                self.on_apple_dodged()

        # Track missed Leibniz — trigger taunt
        for lz in self.leibniz_list[:]:
            if lz.is_off_screen(SCREEN_HEIGHT):
                self.leibniz_list.remove(lz)
                self.leibniz_missed += 1
                if self.combo_system:
                    self.combo_system.on_leibniz_missed()

        # Update combo system
        if self.combo_system:
            self.combo_system.update(dt)

        # Update particles
        if self.particle_system:
            self.particle_system.update(dt)

        # Update act manager
        if self.act_manager:
            self.act_manager.update(self.elapsed_time)

    # ── game flow ────────────────────────────────────────

    def start_game(self):
        """Reset everything and begin playing."""
        self.score = 0
        self.elapsed_time = 0.0
        self.score_timer = 0.0
        self.dodged_count = 0
        self.dodge_streak = 0
        self.score_multiplier = 1.0
        self.game_over_reason = None
        self.leibniz_missed = 0
        self.apples.clear()
        self.leibniz_list.clear()
        self.newton = Newton(self.screen)
        self.spawner = Spawner()
        if self.combo_system:
            self.combo_system.reset()
        if self.quiz_manager:
            self.quiz_manager.correct_count = 0
            self.quiz_manager.total_count = 0
        self.state = Game.STATE_PLAYING
        if self.act_manager:
            self.act_manager.reset()

    def game_over(self, reason=None):
        if reason:
            self.game_over_reason = reason
        # Update high score
        if self.score > self.high_score:
            self.high_score = self.score
            Game.global_high_score = max(Game.global_high_score, self.score)
            self._save_high_score()
        # Stop music and play game over sound
        try:
            pygame.mixer.music.stop()
        except Exception:
            pass
        try:
            snd = pygame.mixer.Sound(media_path("game_over.ogg"))
            snd.play()
        except Exception:
            pass
        self.state = Game.STATE_GAME_OVER
        # Store fact ONCE — never regenerate during game over screen
        self.current_fact = self._get_random_fact()
        # Submit score to leaderboard
        if self.leaderboard_client and self.player_profile:
            math_level = self.player_profile.topics[-1] if self.player_profile.topics else "Arithmetic"
            self.leaderboard_client.submit_score_async(
                self.player_profile.name,
                self.score,
                int(self.elapsed_time),
                math_level,
                self.player_profile.age,
            )

    def on_quiz_answered(self, correct, difficulty):
        # Note: QuizManager already tracks total_count (in start_quiz)
        # and correct_count (in handle_key), so we don't duplicate here.
        if correct:
            self.on_quiz_correct(difficulty)
            self.newton.start_grow()
            try:
                snd = pygame.mixer.Sound(media_path("quiz_correct.ogg"))
                snd.play()
            except Exception:
                pass
            self.state = Game.STATE_PLAYING
        else:
            try:
                snd = pygame.mixer.Sound(media_path("quiz_wrong.ogg"))
                snd.play()
            except Exception:
                pass
            self.game_over_reason = "wrong_answer"
            self.game_over()

    # ── difficulty title & facts ─────────────────────────

    def _get_difficulty_title(self, math_level):
        titles = {
            "arithmetic": "Apple Apprentice",
            "basic arithmetic": "Apple Apprentice",
            "pre_algebra": "Orchard Scout",
            "pre-algebra": "Orchard Scout",
            "algebra": "Math Squire",
            "geometry": "Royal Geometer",
            "trigonometry": "Wave Rider",
            "pre_calculus": "Limit Seeker",
            "pre-calculus": "Limit Seeker",
            "calculus": "Calculus Scholar",
            "advanced": "Grand Mathematician",
            "differential equations": "Grand Mathematician",
        }
        return titles.get(math_level.lower(), "Newton's Apprentice")

    def _get_random_fact(self):
        facts = [
            "Newton and Leibniz both invented calculus independently in the 1660s-1680s.",
            "The Newton-Leibniz controversy lasted decades and divided European mathematics.",
            "Leibniz's notation (dy/dx) is still used today; Newton's dot notation is used in physics.",
            "Newton kept his calculus secret for years before Leibniz published his version.",
            "The Royal Society's 1712 investigation unfairly ruled in Newton's favour.",
            "Newton was just 23 when he developed the fundamentals of calculus.",
            "Leibniz published his calculus in 1684; Newton published his in 1687.",
            "The dispute is considered one of the most famous priority rows in science history.",
            "Today, mathematicians credit both Newton and Leibniz as co-inventors of calculus.",
            "Leibniz introduced the integral sign — a stretched S standing for 'summa'.",
        ]
        available = [f for f in facts if f not in self._used_facts]
        if not available:
            self._used_facts = []
            available = facts
        fact = random.choice(available)
        self._used_facts.append(fact)
        return fact

    # ── persistence ──────────────────────────────────────

    def _load_high_score(self):
        from webstorage import load_json
        data = load_json("highscore.json")
        if data:
            self.high_score = data.get("high_score", 0)
            Game.global_high_score = max(Game.global_high_score, self.high_score)
        else:
            self.high_score = 0

    def _save_high_score(self):
        from webstorage import save_json
        name = self.player_profile.name if self.player_profile else "Player"
        math_level = ""
        if self.player_profile and self.player_profile.topics:
            math_level = self.player_profile.topics[-1]
        save_json("highscore.json", {
            "high_score": self.high_score,
            "player_name": name,
            "time_survived": int(self.elapsed_time),
            "math_level": math_level,
        })

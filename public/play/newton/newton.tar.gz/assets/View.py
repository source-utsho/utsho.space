import pygame
import random
import math
from config import SCREEN_WIDTH, SCREEN_HEIGHT, media_path


class View:
    """Handles all rendering."""

    def __init__(self, screen, game):
        self.screen = screen
        self.game = game

        # Fonts
        pygame.font.init()
        self.font_large = pygame.font.SysFont("Georgia", 48, bold=True)
        self.font_medium = pygame.font.SysFont("Georgia", 32)
        self.font_small = pygame.font.SysFont("Georgia", 24)
        self.font_score = pygame.font.SysFont("Georgia", 28, bold=True)

        # Game over fonts (Section 6)
        self.font_go_title = pygame.font.SysFont("Impact", 88)
        self.font_go_large = pygame.font.SysFont("Impact", 52)
        self.font_go_medium = pygame.font.SysFont("Impact", 32)
        self.font_go_body = pygame.font.SysFont("Arial", 22)
        self.font_go_small = pygame.font.SysFont("Arial", 16)
        self.font_go_label = pygame.font.SysFont("Arial", 14)
        self.font_go_val = pygame.font.SysFont("Impact", 36)

        # Background images — load with fallback
        self.bg_menu = self._load_bg("main_menu.png")
        self.bg_how_to_play = self._load_bg("how_to_play.png")
        self.bg_act1 = self._load_bg("bg_act1_orchard.png")
        self.bg_act2 = self._load_bg("bg_act2_royal_society.png")
        self.bg_act3 = self._load_bg("bg_act3_calculus_war.png")
        self.current_bg = self.bg_act1

        # Menu decorative falling apples
        self._menu_apples = []
        for _ in range(8):
            self._menu_apples.append({
                "x": random.randint(0, SCREEN_WIDTH),
                "y": random.randint(-SCREEN_HEIGHT, 0),
                "speed": random.uniform(0.5, 2.0),
            })

        # Pulsing text timer
        self._pulse_timer = 0.0

    def _load_bg(self, filename):
        try:
            img = pygame.image.load(media_path(filename)).convert()
            return pygame.transform.scale(img, (SCREEN_WIDTH, SCREEN_HEIGHT))
        except (pygame.error, FileNotFoundError):
            surf = pygame.Surface((SCREEN_WIDTH, SCREEN_HEIGHT))
            surf.fill((30, 50, 30))
            return surf

    def render(self, dt=1 / 60.0):
        from Game import Game  # avoid circular at module level

        state = self.game.state
        if state == Game.STATE_MENU:
            self._draw_menu(dt)
        elif state == Game.STATE_HOW_TO_PLAY:
            self._draw_how_to_play()
        elif state == Game.STATE_PLAYING:
            self._draw_game()
        elif state == Game.STATE_PAUSED:
            self._draw_game()
            self._draw_paused()
        elif state == Game.STATE_QUIZ:
            self._draw_game()  # game frozen in background
            if self.game.quiz_manager:
                self.game.quiz_manager.draw(self.screen)
        elif state == Game.STATE_GAME_OVER:
            self._draw_game_over()
        elif state == Game.STATE_PROFILE:
            pass  # handled by PlayerProfile
        elif state == Game.STATE_TUTORIAL:
            pass  # handled by ActManager tutorial
        elif state == Game.STATE_TRANSITION:
            self._draw_game()
            if self.game.act_manager:
                self.game.act_manager.draw_transition(self.screen)
        elif state == Game.STATE_LEADERBOARD:
            self._draw_leaderboard()

        pygame.display.flip()

    # ── screens ──────────────────────────────────────────

    def _draw_menu(self, dt=1 / 60.0):
        self.screen.blit(self.bg_menu, (0, 0))

        # Update and draw decorative falling apples
        for apple in self._menu_apples:
            apple["y"] += apple["speed"]
            if apple["y"] > SCREEN_HEIGHT:
                apple["y"] = random.randint(-80, -20)
                apple["x"] = random.randint(0, SCREEN_WIDTH)
                apple["speed"] = random.uniform(0.5, 2.0)
            # Draw small red circle as decorative apple
            pygame.draw.circle(self.screen, (200, 30, 30, 120),
                               (int(apple["x"]), int(apple["y"])), 8)
            pygame.draw.circle(self.screen, (160, 20, 20),
                               (int(apple["x"]), int(apple["y"])), 8, 1)

        # Button hover highlights
        mx, my = pygame.mouse.get_pos()
        button_rects = [
            pygame.Rect(325, 370, 415, 72),
            pygame.Rect(140, 462, 275, 58),
            pygame.Rect(440, 462, 185, 58),
            pygame.Rect(650, 462, 275, 58),
        ]
        for rect in button_rects:
            if rect.collidepoint(mx, my):
                highlight = pygame.Surface((rect.width, rect.height), pygame.SRCALPHA)
                highlight.fill((255, 255, 255, 40))
                self.screen.blit(highlight, (rect.x, rect.y))

        # Pulsing "Press ENTER to play" text
        self._pulse_timer += dt
        alpha = int(128 + 127 * math.sin(self._pulse_timer * 3))
        pulse_surf = self.font_small.render("Press ENTER to play", True, (255, 255, 220))
        pulse_alpha_surf = pygame.Surface(pulse_surf.get_size(), pygame.SRCALPHA)
        pulse_alpha_surf.blit(pulse_surf, (0, 0))
        pulse_alpha_surf.set_alpha(alpha)
        self.screen.blit(pulse_alpha_surf,
                         (SCREEN_WIDTH // 2 - pulse_surf.get_width() // 2, 600))

        # High score
        hs = self.font_small.render(f"High Score: {self.game.high_score}", True, (255, 215, 0))
        self.screen.blit(hs, (SCREEN_WIDTH // 2 - hs.get_width() // 2, 650))

    def _draw_how_to_play(self):
        self.screen.blit(self.bg_how_to_play, (0, 0))

    def _draw_game(self):
        # Shake offset
        offset = (0, 0)
        if self.game.particle_system:
            offset = self.game.particle_system.shake_offset

        self.screen.blit(self.current_bg, (offset[0], offset[1]))

        # Draw entities
        for apple in self.game.apples:
            apple.draw(self.screen, offset)
        for lz in self.game.leibniz_list:
            lz.draw(self.screen, offset)
        self.game.newton.draw(self.screen, offset)

        # Particles
        if self.game.particle_system:
            self.game.particle_system.draw(self.screen)

        # Combo badge
        if self.game.combo_system:
            self.game.combo_system.draw(self.screen)

        # HUD
        self._draw_hud()

    def _draw_hud(self):
        # Score
        score_text = self.font_score.render(f"Score: {self.game.score}", True, (255, 255, 255))
        self.screen.blit(score_text, (20, 20))

        # Time
        mins = int(self.game.elapsed_time) // 60
        secs = int(self.game.elapsed_time) % 60
        time_text = self.font_small.render(f"Time: {mins}:{secs:02d}", True, (255, 255, 255))
        self.screen.blit(time_text, (20, 55))

        # Act info
        if self.game.act_manager:
            act_data = self.game.act_manager.get_current_act_data()
            act_text = self.font_small.render(act_data["name"], True, (255, 215, 0))
            self.screen.blit(act_text, (SCREEN_WIDTH - act_text.get_width() - 20, 20))

        # Multiplier
        combo_mult = self.game.combo_system.get_score_multiplier() if self.game.combo_system else 1.0
        total_mult = self.game.score_multiplier * combo_mult
        if total_mult > 1.0:
            mult = self.font_small.render(f"x{total_mult:.1f}", True, (255, 200, 50))
            self.screen.blit(mult, (SCREEN_WIDTH - mult.get_width() - 20, 55))

    def _draw_paused(self):
        # Dark overlay
        overlay = pygame.Surface((SCREEN_WIDTH, SCREEN_HEIGHT), pygame.SRCALPHA)
        overlay.fill((0, 0, 0, 160))
        self.screen.blit(overlay, (0, 0))

        # PAUSED text
        paused_text = self.font_large.render("PAUSED", True, (255, 255, 255))
        self.screen.blit(paused_text,
                         (SCREEN_WIDTH // 2 - paused_text.get_width() // 2, SCREEN_HEIGHT // 2 - 100))

        # Options
        options = [
            "Resume  [ESC]",
            "Menu  [M]",
            "Quit  [Q]",
        ]
        for i, text in enumerate(options):
            surf = self.font_medium.render(text, True, (220, 220, 220))
            self.screen.blit(surf,
                             (SCREEN_WIDTH // 2 - surf.get_width() // 2, SCREEN_HEIGHT // 2 + i * 55))

    def _draw_game_over(self):
        """Fully procedural game over screen per VISION_v3 Section 6."""
        game = self.game
        W, H = SCREEN_WIDTH, SCREEN_HEIGHT

        # Collect real gameplay stats
        final_score = game.score
        time_survived = int(game.elapsed_time)
        quizzes_correct = game.quiz_manager.correct_count if game.quiz_manager else 0
        quizzes_total = game.quiz_manager.total_count if game.quiz_manager else 0
        accuracy = int((quizzes_correct / quizzes_total * 100) if quizzes_total > 0 else 0)
        act_reached = game.act_manager.current_act if game.act_manager else 1
        act_names = {1: "The Apple Orchard", 2: "The Royal Society", 3: "The Calculus War"}
        act_name = act_names.get(act_reached, "The Apple Orchard")

        if game.player_profile:
            math_level = game.player_profile.topics[-1] if game.player_profile.topics else "Arithmetic"
        else:
            math_level = "Arithmetic"

        difficulty_title = game._get_difficulty_title(math_level)

        new_best = final_score >= game.high_score and final_score > 0
        fact = game.current_fact

        # Game over reason
        reason = game.game_over_reason or "too_large"
        if reason == "wrong_answer":
            reason_text = "Wrong answer — calculus crushed you!"
            reason_color = (220, 60, 60)
        else:
            reason_text = "Newton grew too large — gravity wins!"
            reason_color = (220, 140, 20)

        # Font aliases
        font_title = self.font_go_title
        font_large = self.font_go_large
        font_medium = self.font_go_medium
        font_body = self.font_go_body
        font_small = self.font_go_small
        font_label = self.font_go_label
        font_val = self.font_go_val

        # ── BACKGROUND ──
        self.screen.fill((18, 4, 4))
        pygame.draw.rect(self.screen, (30, 8, 8), (0, 0, W, H // 2))

        # Vignette corners
        vignette = pygame.Surface((W, H), pygame.SRCALPHA)
        pygame.draw.ellipse(vignette, (80, 0, 0, 90), (-200, -150, 600, 500))
        pygame.draw.ellipse(vignette, (80, 0, 0, 90), (W - 400, -150, 600, 500))
        pygame.draw.ellipse(vignette, (50, 0, 0, 60), (-150, H - 350, 500, 400))
        pygame.draw.ellipse(vignette, (50, 0, 0, 60), (W - 350, H - 350, 500, 400))
        self.screen.blit(vignette, (0, 0))

        # ── GAME OVER TITLE ──
        shadow = font_title.render("GAME OVER", True, (40, 0, 0))
        self.screen.blit(shadow, shadow.get_rect(center=(W // 2 + 4, 72)))
        title_surf = font_title.render("GAME OVER", True, (255, 255, 255))
        self.screen.blit(title_surf, title_surf.get_rect(center=(W // 2, 68)))

        # ── REASON SUBTITLE ──
        reason_bg = pygame.Surface((520, 38), pygame.SRCALPHA)
        reason_bg.fill((reason_color[0] // 2, reason_color[1] // 3, reason_color[2] // 3, 200))
        pygame.draw.rect(reason_bg, reason_color, (0, 0, 520, 38), 2, border_radius=19)
        self.screen.blit(reason_bg, (W // 2 - 260, 112))
        r_text = font_body.render(reason_text, True, (255, 220, 220))
        self.screen.blit(r_text, r_text.get_rect(center=(W // 2, 131)))

        # ── MAIN SCORE PANEL ──
        panel_rect = pygame.Rect(55, 162, W - 110, 300)
        panel_surf = pygame.Surface((panel_rect.w, panel_rect.h), pygame.SRCALPHA)
        panel_surf.fill((10, 20, 50, 200))
        pygame.draw.rect(panel_surf, (30, 80, 160), (0, 0, panel_rect.w, panel_rect.h), 2, border_radius=16)
        self.screen.blit(panel_surf, (panel_rect.x, panel_rect.y))

        # FINAL SCORE label
        lbl = font_label.render("FINAL SCORE", True, (80, 140, 200))
        self.screen.blit(lbl, lbl.get_rect(center=(W // 2, 192)))

        # Big score number
        score_color = (255, 220, 0) if not new_best else (255, 240, 80)
        score_surf = font_large.render(str(final_score), True, score_color)
        self.screen.blit(score_surf, score_surf.get_rect(center=(W // 2, 255)))

        # NEW BEST badge
        if new_best:
            nb_surf = font_medium.render("NEW BEST!", True, (255, 240, 0))
            nb_rect = nb_surf.get_rect(center=(W // 2 + 160, 245))
            pygame.draw.rect(self.screen, (100, 80, 0), nb_rect.inflate(16, 8), border_radius=8)
            self.screen.blit(nb_surf, nb_rect)

        # Divider line
        pygame.draw.line(self.screen, (30, 70, 130), (80, 295), (W - 80, 295), 1)

        # ── STAT CARDS ──
        stats = [
            ("TIME SURVIVED", f"{time_survived}s", "seconds in play", (30, 100, 180)),
            ("QUIZZES CORRECT", str(quizzes_correct), "math questions right", (20, 120, 50)),
            ("ACCURACY", f"{accuracy}%", "quiz success rate", (140, 110, 20)),
            ("ACT REACHED", f"Act {act_reached}", act_name, (100, 30, 140)),
            ("BEST SCORE", str(game.high_score), "all-time personal best", (120, 80, 0)),
        ]

        card_w = 176
        card_h = 118
        card_gap = 14
        total_w = card_w * 5 + card_gap * 4
        start_x = (W - total_w) // 2
        card_y = 308

        for i, (label, value, sub, color) in enumerate(stats):
            cx = start_x + i * (card_w + card_gap)
            # Card background
            card_surf = pygame.Surface((card_w, card_h), pygame.SRCALPHA)
            card_surf.fill((color[0] // 5, color[1] // 5, color[2] // 5, 200))
            pygame.draw.rect(card_surf, color, (0, 0, card_w, card_h), 1, border_radius=10)
            self.screen.blit(card_surf, (cx, card_y))
            # Label
            lbl_c = (min(color[0] + 80, 255), min(color[1] + 80, 255), min(color[2] + 80, 255))
            lbl_s = font_label.render(label, True, lbl_c)
            self.screen.blit(lbl_s, lbl_s.get_rect(center=(cx + card_w // 2, card_y + 22)))
            # Value (big)
            val_s = font_val.render(value, True, (255, 255, 255))
            self.screen.blit(val_s, val_s.get_rect(center=(cx + card_w // 2, card_y + 62)))
            # Subtitle
            sub_s = font_label.render(sub, True, (160, 160, 180))
            self.screen.blit(sub_s, sub_s.get_rect(center=(cx + card_w // 2, card_y + 90)))
            # Trophy icon for best score card
            if i == 4 and new_best:
                trophy_font = pygame.font.SysFont("Arial", 16)
                t = trophy_font.render("NEW!", True, (255, 220, 0))
                self.screen.blit(t, (cx + card_w - 38, card_y + 5))

        # ── BOTTOM INFO ROW ──
        # Math level badge (left)
        badge_surf = pygame.Surface((400, 58), pygame.SRCALPHA)
        badge_surf.fill((10, 10, 40, 200))
        pygame.draw.rect(badge_surf, (50, 50, 160), (0, 0, 400, 58), 1, border_radius=10)
        self.screen.blit(badge_surf, (55, 440))

        lvl_label = font_label.render("MATH LEVEL PLAYED", True, (100, 100, 180))
        self.screen.blit(lvl_label, (70, 452))

        # Level pill
        pill_surf = pygame.Surface((120, 24), pygame.SRCALPHA)
        pill_surf.fill((70, 70, 220, 255))
        pygame.draw.rect(pill_surf, (120, 120, 255), (0, 0, 120, 24), 1, border_radius=12)
        self.screen.blit(pill_surf, (70, 470))
        pill_text = font_label.render(math_level.upper(), True, (255, 255, 255))
        self.screen.blit(pill_text, pill_text.get_rect(center=(130, 482)))

        diff_text = font_small.render(f'"{difficulty_title}"', True, (180, 180, 255))
        self.screen.blit(diff_text, (205, 474))

        # Historical fact (right)
        fact_surf = pygame.Surface((500, 58), pygame.SRCALPHA)
        fact_surf.fill((5, 25, 5, 200))
        pygame.draw.rect(fact_surf, (30, 100, 30), (0, 0, 500, 58), 1, border_radius=10)
        self.screen.blit(fact_surf, (510, 440))

        did_lbl = font_label.render("DID YOU KNOW?", True, (80, 180, 80))
        self.screen.blit(did_lbl, (525, 452))

        # Wrap fact text across 2 lines
        words = fact.split()
        line1, line2 = "", ""
        for w in words:
            if font_label.size(line1 + w + " ")[0] < 470:
                line1 += w + " "
            else:
                line2 += w + " "
        f1 = font_label.render(line1.strip(), True, (150, 220, 150))
        f2 = font_label.render(line2.strip(), True, (150, 220, 150))
        self.screen.blit(f1, (525, 468))
        self.screen.blit(f2, (525, 485))

        # ── ACTION BUTTONS ──
        buttons = [
            ("RETRY  [R]", (255, 255, 255), (40, 150, 20), (20, 90, 10), (55, 513)),
            ("MENU  [M]", (255, 255, 255), (25, 80, 160), (10, 45, 100), (375, 513)),
            ("QUIT  [Q]", (255, 255, 255), (160, 25, 25), (90, 10, 10), (695, 513)),
        ]

        mx, my = pygame.mouse.get_pos()
        for text, txt_col, btn_col, shadow_col, (bx, by) in buttons:
            btn_w, btn_h = 295, 64
            btn_rect = pygame.Rect(bx, by, btn_w, btn_h)
            # Shadow
            pygame.draw.rect(self.screen, shadow_col, (bx + 3, by + 3, btn_w, btn_h), border_radius=12)
            # Button (brighten on hover)
            draw_col = btn_col
            if btn_rect.collidepoint(mx, my):
                draw_col = (min(btn_col[0] + 30, 255), min(btn_col[1] + 30, 255), min(btn_col[2] + 30, 255))
            pygame.draw.rect(self.screen, draw_col, (bx, by, btn_w, btn_h), border_radius=12)
            # Highlight strip
            highlight = pygame.Surface((btn_w - 8, 26), pygame.SRCALPHA)
            highlight.fill((255, 255, 255, 30))
            self.screen.blit(highlight, (bx + 4, by + 4))
            # Outline
            pygame.draw.rect(self.screen,
                             (min(btn_col[0] + 60, 255), min(btn_col[1] + 60, 255), min(btn_col[2] + 60, 255)),
                             (bx, by, btn_w, btn_h), 2, border_radius=12)
            # Text
            btn_text = font_medium.render(text, True, txt_col)
            self.screen.blit(btn_text, btn_text.get_rect(center=(bx + btn_w // 2, by + btn_h // 2)))

        # ── LEADERBOARD STRIP ──
        strip_surf = pygame.Surface((W - 110, 44), pygame.SRCALPHA)
        strip_surf.fill((8, 8, 25, 200))
        pygame.draw.rect(strip_surf, (35, 35, 100), (0, 0, W - 110, 44), 1, border_radius=8)
        self.screen.blit(strip_surf, (55, 592))
        lb_text = font_body.render("View Global Rankings — can you beat the leaderboard?   Press  L", True, (80, 80, 180))
        self.screen.blit(lb_text, lb_text.get_rect(center=(W // 2, 614)))

    def _draw_leaderboard(self):
        # Background
        bg = self._load_bg("leaderboard_bg.png")
        self.screen.blit(bg, (0, 0))

        title = self.font_large.render("Royal Society Honours Board", True, (255, 215, 0))
        self.screen.blit(title, (SCREEN_WIDTH // 2 - title.get_width() // 2, 40))

        client = self.game.leaderboard_client
        if client and client.loading:
            loading = self.font_medium.render("Loading...", True, (255, 255, 220))
            self.screen.blit(loading, (SCREEN_WIDTH // 2 - loading.get_width() // 2, 300))
        elif client and client.leaderboard_data:
            # Table headers
            headers = ["Rank", "Name", "Score", "Time", "Level"]
            header_x = [80, 180, 420, 560, 700]
            for i, h in enumerate(headers):
                surf = self.font_small.render(h, True, (255, 215, 0))
                self.screen.blit(surf, (header_x[i], 120))

            # Divider
            pygame.draw.line(self.screen, (200, 180, 140), (60, 150), (SCREEN_WIDTH - 60, 150), 2)

            for rank, entry in enumerate(client.leaderboard_data[:10], 1):
                y = 160 + rank * 45

                # Medal colors for top 3
                if rank == 1:
                    color = (255, 215, 0)   # gold
                elif rank == 2:
                    color = (192, 192, 192)  # silver
                elif rank == 3:
                    color = (205, 127, 50)  # bronze
                else:
                    color = (220, 210, 190)

                # Highlight player's own score
                player_name = self.game.player_profile.name if self.game.player_profile else ""
                if entry.get("player_name") == player_name:
                    color = (100, 150, 255)

                values = [
                    str(rank),
                    str(entry.get("player_name", ""))[:15],
                    str(entry.get("score", 0)),
                    f"{entry.get('time_survived', 0)}s",
                    str(entry.get("math_level", "")),
                ]
                for i, val in enumerate(values):
                    surf = self.font_small.render(val, True, color)
                    self.screen.blit(surf, (header_x[i], y))
        elif client and client.error:
            # Show "local scores" notice + trigger local fallback if not done
            if not client.leaderboard_data:
                client._load_local_fallback()
            if client.leaderboard_data:
                notice = self.font_small.render("(Showing local scores — server offline)", True, (200, 180, 100))
                self.screen.blit(notice, (SCREEN_WIDTH // 2 - notice.get_width() // 2, 100))
                # Re-draw table with local data
                headers = ["Rank", "Name", "Score", "Time", "Level"]
                header_x = [80, 180, 420, 560, 700]
                for i, h in enumerate(headers):
                    surf = self.font_small.render(h, True, (255, 215, 0))
                    self.screen.blit(surf, (header_x[i], 120))
                pygame.draw.line(self.screen, (200, 180, 140), (60, 150), (SCREEN_WIDTH - 60, 150), 2)
                for rank, entry in enumerate(client.leaderboard_data[:10], 1):
                    y = 160 + rank * 45
                    color = (255, 215, 0) if rank == 1 else (220, 210, 190)
                    player_name = self.game.player_profile.name if self.game.player_profile else ""
                    if entry.get("player_name") == player_name:
                        color = (100, 150, 255)
                    ts = entry.get("time_survived", "")
                    time_str = f"{ts}s" if ts != "---" and ts != "" else str(ts)
                    values = [
                        str(rank),
                        str(entry.get("player_name", ""))[:15],
                        str(entry.get("score", "")),
                        time_str,
                        str(entry.get("math_level", "")),
                    ]
                    for i, val in enumerate(values):
                        surf = self.font_small.render(val, True, color)
                        self.screen.blit(surf, (header_x[i], y))
            else:
                err = self.font_small.render("No scores saved yet — play a game first!", True, (200, 180, 100))
                self.screen.blit(err, (SCREEN_WIDTH // 2 - err.get_width() // 2, 300))
        else:
            info = self.font_medium.render("No leaderboard data yet", True, (200, 190, 170))
            self.screen.blit(info, (SCREEN_WIDTH // 2 - info.get_width() // 2, 300))

        # Back instruction
        back = self.font_small.render("Press ESC or M to return to menu", True, (180, 170, 150))
        self.screen.blit(back, (SCREEN_WIDTH // 2 - back.get_width() // 2, SCREEN_HEIGHT - 60))

    def set_background(self, bg_filename):
        """Change the gameplay background (called by ActManager)."""
        bg = self._load_bg(bg_filename)
        self.current_bg = bg

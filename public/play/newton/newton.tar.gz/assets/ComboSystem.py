"""
ComboSystem — Combo streak, Leibniz taunts, and milestone celebrations.
Per VISION_v3 Section 8.1, 8.3, 8.4.
"""
from config import COMBO_THRESHOLD, COMBO_MULTIPLIER, SCREEN_WIDTH
import pygame


class ComboSystem:
    def __init__(self):
        self.streak = 0
        self.multiplier = 1.0
        self.badge_timer = 0.0  # seconds remaining for badge display
        self.badge_text = ""
        # Leibniz taunt system (Section 8.3)
        self.taunt_timer = 0.0
        self.taunt_text = ""
        self.taunts = [
            "You'll never shrink now, Isaac!",
            "My notation is superior AND I'm faster!",
            "Enjoy your enormous size, Newton!",
            "Should've caught me when you had the chance!",
            "Growing nicely, aren't we?",
        ]
        # Milestone system (Section 8.4)
        self.milestones_hit = set()
        self.milestone_timer = 0.0
        self.milestone_text = ""
        # Fonts
        self.font_badge = pygame.font.SysFont("Impact", 48, bold=True)
        self.font_taunt = pygame.font.SysFont("Georgia", 20)
        self.font_milestone = pygame.font.SysFont("Impact", 52, bold=True)

    def on_dodge(self):
        self.streak += 1
        if self.streak >= COMBO_THRESHOLD:
            self.multiplier = COMBO_MULTIPLIER
            self.badge_text = f"COMBO x{self.streak}!"
            self.badge_timer = 1.5

    def on_hit(self):
        self.streak = 0
        self.multiplier = 1.0

    def on_leibniz_missed(self):
        import random
        self.taunt_text = random.choice(self.taunts)
        self.taunt_timer = 2.0

    def check_milestone(self, score):
        for m in [50, 100, 200, 500, 1000]:
            if score >= m and m not in self.milestones_hit:
                self.milestones_hit.add(m)
                self.milestone_text = f"MILESTONE: {m}!"
                self.milestone_timer = 1.5
                return True
        return False

    def get_score_multiplier(self):
        return self.multiplier

    def update(self, dt):
        if self.badge_timer > 0:
            self.badge_timer -= dt
        if self.taunt_timer > 0:
            self.taunt_timer -= dt
        if self.milestone_timer > 0:
            self.milestone_timer -= dt

    def draw(self, screen):
        W = screen.get_width()
        # Combo badge -- gold text, center top
        if self.badge_timer > 0:
            alpha = min(255, int(255 * (self.badge_timer / 1.5)))
            text = self.font_badge.render(self.badge_text, True, (255, 215, 0))
            temp = pygame.Surface(text.get_size(), pygame.SRCALPHA)
            temp.blit(text, (0, 0))
            temp.set_alpha(alpha)
            screen.blit(temp, (W // 2 - text.get_width() // 2, 80))

        # Leibniz taunt -- speech bubble at bottom
        if self.taunt_timer > 0:
            alpha = min(255, int(255 * (self.taunt_timer / 2.0)))
            # Bubble background
            bubble = pygame.Surface((500, 40), pygame.SRCALPHA)
            bubble.fill((40, 20, 60, min(200, alpha)))
            pygame.draw.rect(bubble, (160, 80, 200), (0, 0, 500, 40), 2, border_radius=10)
            screen.blit(bubble, (W // 2 - 250, screen.get_height() - 60))
            text = self.font_taunt.render(f'Leibniz: "{self.taunt_text}"', True, (220, 180, 255))
            t_surf = pygame.Surface(text.get_size(), pygame.SRCALPHA)
            t_surf.blit(text, (0, 0))
            t_surf.set_alpha(alpha)
            screen.blit(t_surf, (W // 2 - text.get_width() // 2, screen.get_height() - 52))

        # Milestone celebration
        if self.milestone_timer > 0:
            alpha = min(255, int(255 * (self.milestone_timer / 1.5)))
            text = self.font_milestone.render(self.milestone_text, True, (255, 215, 0))
            temp = pygame.Surface(text.get_size(), pygame.SRCALPHA)
            temp.blit(text, (0, 0))
            temp.set_alpha(alpha)
            screen.blit(temp, (W // 2 - text.get_width() // 2, screen.get_height() // 2 - 30))

    def reset(self):
        self.streak = 0
        self.multiplier = 1.0
        self.badge_timer = 0
        self.taunt_timer = 0
        self.milestone_timer = 0
        self.milestones_hit.clear()

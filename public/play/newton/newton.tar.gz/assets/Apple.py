import pygame
import random
from config import APPLE_BASE_SPEED, APPLE_ROTATE_SPEED, APPLE_SIZE, SCREEN_WIDTH, media_path


class Apple:
    def __init__(self, speed_multiplier=1.0):
        self.size = APPLE_SIZE
        self.x = random.randint(0, SCREEN_WIDTH - self.size)
        self.y = -self.size
        self.speed = APPLE_BASE_SPEED * speed_multiplier
        self.angle = 0

        try:
            self.original_image = pygame.image.load(media_path("apple.png")).convert_alpha()
            self.original_image = pygame.transform.scale(self.original_image, (self.size, self.size))
        except (pygame.error, FileNotFoundError):
            self.original_image = pygame.Surface((self.size, self.size), pygame.SRCALPHA)
            pygame.draw.circle(self.original_image, (220, 30, 30), (self.size // 2, self.size // 2), self.size // 2)

        self.image = self.original_image

    def update(self, dt):
        self.y += self.speed
        self.angle = (self.angle + APPLE_ROTATE_SPEED) % 360
        self.image = pygame.transform.rotate(self.original_image, self.angle)

    def get_rect(self):
        return pygame.Rect(self.x, self.y, self.size, self.size)

    def is_off_screen(self, screen_height):
        return self.y > screen_height

    def draw(self, surface, offset=(0, 0)):
        # Center the rotated image on the apple's position
        rect = self.image.get_rect(center=(self.x + self.size // 2 + offset[0],
                                           self.y + self.size // 2 + offset[1]))
        surface.blit(self.image, rect)

# Newton's Apple Crisis v2.0 — All game constants
import os

# Screen
SCREEN_WIDTH = 1065
SCREEN_HEIGHT = 768
FPS = 60
TITLE = "Newton's Apple Crisis"

# Newton
NEWTON_SPEED = 5
NEWTON_BASE_WIDTH = 150
NEWTON_BASE_HEIGHT = 300
NEWTON_GROW_FACTOR = 1.1
NEWTON_GROW_DURATION = 0.5  # seconds for smooth growth animation
NEWTON_MAX_HEIGHT = 600

# Apples
APPLE_BASE_SPEED = 5
APPLE_ROTATE_SPEED = 3
APPLE_SIZE = 40

# Leibniz
LEIBNIZ_SPEED = 3
LEIBNIZ_SIZE = 40

# Spawner
SPAWN_RATE_INITIAL = 650
LEIBNIZ_SPAWN_RATE_INITIAL = 900
SPAWN_RATE_MIN = 30
LEIBNIZ_SPAWN_RATE_MIN = 300

# Acts — elapsed time thresholds
ACT1_END = 60    # seconds: act 1 ends, act 2 starts
ACT2_END = 120   # seconds: act 2 ends, act 3 starts
ACT_TRANSITION_DURATION = 3  # seconds

# Scoring
SCORE_PER_SECOND = 1
SCORE_PER_DODGE = 2
SCORE_QUIZ_EASY = 10
SCORE_QUIZ_MEDIUM = 20
SCORE_QUIZ_HARD = 30
SCORE_LEIBNIZ = 15
COMBO_THRESHOLD = 5
COMBO_MULTIPLIER = 1.5

# Particles
PARTICLE_COUNT_APPLE = 12
PARTICLE_COUNT_LEIBNIZ = 16
PARTICLE_LIFETIME = 0.8  # seconds
SCREEN_SHAKE_DURATION = 0.3  # seconds
SCREEN_SHAKE_INTENSITY = 8

# Leaderboard backend
BACKEND_URL = ""  # leaderboard disabled in web build

# Asset paths (resolved relative to this file's directory)
_SRC_DIR = os.path.dirname(os.path.abspath(__file__))
MEDIA_DIR = os.path.join(_SRC_DIR, "media")
SAVES_DIR = os.path.join(_SRC_DIR, "saves")


def media_path(filename):
    """Return absolute path to a media asset."""
    return os.path.join(MEDIA_DIR, filename)


def saves_path(filename):
    """Return absolute path to a save file, creating dir if needed."""
    try:
        os.makedirs(SAVES_DIR, exist_ok=True)
    except OSError:
        pass  # browser filesystem may not support this
    return os.path.join(SAVES_DIR, filename)

"""
ActManager — 3-act system with transitions, narrative, dialogue cutscenes,
act preview cards, and tutorial.
Uses ACT1_END, ACT2_END elapsed-time thresholds from config.
"""
import pygame
import os
from config import (
    SCREEN_WIDTH, SCREEN_HEIGHT,
    ACT1_END, ACT2_END, ACT_TRANSITION_DURATION,
    SPAWN_RATE_INITIAL, LEIBNIZ_SPAWN_RATE_INITIAL,
    media_path, saves_path,
)


class ActManager:
    ACTS = {
        1: {
            "name": "Act I: The Apple Orchard",
            "background": "bg_act1_orchard.png",
            "music": "music_act1.ogg",
            "narrative": "Newton sits peacefully beneath his apple tree\nat Woolsthorpe... Leibniz has other plans.",
            "spawn_rate": SPAWN_RATE_INITIAL,
            "leibniz_rate": LEIBNIZ_SPAWN_RATE_INITIAL,
            "apple_speed_multiplier": 1.0,
            "score_multiplier": 1.0,
        },
        2: {
            "name": "Act II: The Royal Society",
            "background": "bg_act2_royal_society.png",
            "music": "music_act2.ogg",
            "narrative": "The Royal Society watches. Newton's reputation\nhangs by a thread.",
            "spawn_rate": 400,
            "leibniz_rate": 600,
            "apple_speed_multiplier": 1.4,
            "score_multiplier": 1.5,
        },
        3: {
            "name": "Act III: The Calculus War",
            "background": "bg_act3_calculus_war.png",
            "music": "music_act3.ogg",
            "narrative": "This is no longer about apples.\nThis is about who invented calculus.",
            "spawn_rate": 200,
            "leibniz_rate": 350,
            "apple_speed_multiplier": 2.0,
            "score_multiplier": 2.0,
        },
    }

    DIALOGUES = {
        (1, 2): [
            ("Newton", "I simply require peace and quiet."),
            ("Leibniz", "Enjoy it while it lasts, Isaac."),
        ],
        (2, 3): [
            ("Newton", "You dare challenge my discoveries?!"),
            ("Leibniz", "I invented calculus first and you know it!"),
        ],
    }

    TUTORIAL_STEPS = [
        {"text": "Move with  <-  ->", "hint": "Arrow keys to dodge"},
        {"text": "Dodge apples!", "hint": "Don't let them hit you"},
        {"text": "Answer questions to survive", "hint": "Get hit? Solve a math quiz"},
        {"text": "Catch Leibniz for bonus!", "hint": "Gold power-ups shrink you"},
    ]

    # Preview card timing (Section 8.5)
    PREVIEW_LEAD_TIME = 3.0  # seconds before transition to show preview

    def __init__(self, game, view):
        self.game = game
        self.view = view
        self.current_act = 1
        self.transitioning = False
        self.transition_timer = 0.0
        self.next_act = 1

        # Act preview card (Section 8.5)
        self.showing_preview = False
        self.preview_timer = 0.0
        self.preview_act = 1

        # Dialogue cutscene
        self.showing_dialogue = False
        self.dialogue_lines = []
        self.dialogue_index = 0
        self.dialogue_timer = 0.0
        self.dialogue_duration = 3.0  # seconds per line

        # Tutorial
        self.showing_tutorial = False
        self.tutorial_step = 0
        self.tutorial_timer = 0.0
        self.tutorial_duration = 2.5
        self.tutorial_shown = False

        # Fonts
        self.font_title = pygame.font.SysFont("Georgia", 44, bold=True)
        self.font_narrative = pygame.font.SysFont("Georgia", 28)
        self.font_dialogue = pygame.font.SysFont("Georgia", 26)
        self.font_speaker = pygame.font.SysFont("Georgia", 22, bold=True)
        self.font_tutorial = pygame.font.SysFont("Georgia", 36, bold=True)
        self.font_hint = pygame.font.SysFont("Georgia", 22)
        self.font_preview = pygame.font.SysFont("Impact", 48, bold=True)
        self.font_preview_sub = pygame.font.SysFont("Georgia", 24)

        # Apply act 1 settings
        self._apply_act(1)

    def reset(self):
        self.current_act = 1
        self.transitioning = False
        self.showing_dialogue = False
        self.showing_preview = False
        self.transition_timer = 0.0
        self.preview_timer = 0.0
        self._apply_act(1)

    def get_current_act_data(self):
        return self.ACTS[self.current_act]

    def check_tutorial_needed(self):
        """Show tutorial on first ever launch."""
        if not self.tutorial_shown:
            self.tutorial_shown = True
            self.showing_tutorial = True
            self.tutorial_step = 0
            self.tutorial_timer = 0.0
            from Game import Game
            self.game.state = Game.STATE_TUTORIAL

    def update(self, elapsed_time):
        # Tutorial
        if self.showing_tutorial:
            return

        # Act transitions
        if self.transitioning:
            return

        if self.showing_dialogue:
            return

        if self.showing_preview:
            return

        # Check for act preview cards (show 3 seconds before transition)
        if self.current_act == 1:
            preview_time = ACT1_END - self.PREVIEW_LEAD_TIME
            if elapsed_time >= preview_time and elapsed_time < ACT1_END and not self.showing_preview:
                self._start_preview(2)
            elif elapsed_time >= ACT1_END:
                self._start_transition(2)
        elif self.current_act == 2:
            preview_time = ACT2_END - self.PREVIEW_LEAD_TIME
            if elapsed_time >= preview_time and elapsed_time < ACT2_END and not self.showing_preview:
                self._start_preview(3)
            elif elapsed_time >= ACT2_END:
                self._start_transition(3)

    def update_transition(self, dt):
        """Called from game loop when in transition state."""
        if self.showing_tutorial:
            self.tutorial_timer += dt
            if self.tutorial_timer >= self.tutorial_duration:
                self.tutorial_timer = 0.0
                self.tutorial_step += 1
                if self.tutorial_step >= len(self.TUTORIAL_STEPS):
                    self.showing_tutorial = False
                    from Game import Game
                    self.game.state = Game.STATE_PLAYING
            return

        if self.showing_preview:
            self.preview_timer += dt
            if self.preview_timer >= self.PREVIEW_LEAD_TIME:
                self.showing_preview = False
                # The actual transition will be triggered on next update()
            return

        if self.showing_dialogue:
            self.dialogue_timer += dt
            if self.dialogue_timer >= self.dialogue_duration:
                self.dialogue_timer = 0.0
                self.dialogue_index += 1
                if self.dialogue_index >= len(self.dialogue_lines):
                    self.showing_dialogue = False
                    self._apply_act(self.next_act)
                    self.current_act = self.next_act
                    from Game import Game
                    self.game.state = Game.STATE_PLAYING
            return

        if self.transitioning:
            self.transition_timer -= dt
            if self.transition_timer <= 0:
                self.transitioning = False
                # Start dialogue cutscene
                key = (self.current_act, self.next_act)
                if key in self.DIALOGUES:
                    self.showing_dialogue = True
                    self.dialogue_lines = self.DIALOGUES[key]
                    self.dialogue_index = 0
                    self.dialogue_timer = 0.0
                else:
                    self._apply_act(self.next_act)
                    self.current_act = self.next_act
                    from Game import Game
                    self.game.state = Game.STATE_PLAYING

    def _start_preview(self, upcoming_act):
        """Show cinematic preview card before act transition (Section 8.5)."""
        self.showing_preview = True
        self.preview_timer = 0.0
        self.preview_act = upcoming_act

    def _start_transition(self, new_act):
        # If preview is still showing, skip it
        self.showing_preview = False
        self.transitioning = True
        self.transition_timer = ACT_TRANSITION_DURATION
        self.next_act = new_act
        from Game import Game
        self.game.state = Game.STATE_TRANSITION
        # Switch music
        try:
            music_file = media_path(self.ACTS[new_act]["music"])
            if os.path.exists(music_file):
                pygame.mixer.music.load(music_file)
                pygame.mixer.music.play(-1)
        except Exception:
            pass

    def _apply_act(self, act_num):
        act = self.ACTS[act_num]
        self.game.score_multiplier = act["score_multiplier"]
        self.game.spawner.set_rates(
            act["spawn_rate"], act["leibniz_rate"], act["apple_speed_multiplier"]
        )
        if self.view:
            self.view.set_background(act["background"])

    # ---- drawing ------------------------------------------------

    def draw_transition(self, screen):
        """Draw transition overlay."""
        if self.showing_tutorial:
            self._draw_tutorial(screen)
            return

        if self.showing_preview:
            self._draw_preview(screen)
            return

        if self.showing_dialogue:
            self._draw_dialogue(screen)
            return

        if self.transitioning:
            self._draw_act_intro(screen)

    def _draw_preview(self, screen):
        """Draw cinematic letterbox preview card (Section 8.5)."""
        bar_height = 90
        progress = min(self.preview_timer / self.PREVIEW_LEAD_TIME, 1.0)

        # Animate bars sliding in (first 0.3s)
        bar_anim = min(self.preview_timer / 0.3, 1.0)
        current_bar = int(bar_height * bar_anim)

        # Dark overlay fading in
        alpha = int(120 * bar_anim)
        overlay = pygame.Surface((SCREEN_WIDTH, SCREEN_HEIGHT), pygame.SRCALPHA)
        overlay.fill((0, 0, 0, alpha))
        screen.blit(overlay, (0, 0))

        # Cinematic black bars (top and bottom)
        pygame.draw.rect(screen, (0, 0, 0), (0, 0, SCREEN_WIDTH, current_bar))
        pygame.draw.rect(screen, (0, 0, 0), (0, SCREEN_HEIGHT - current_bar, SCREEN_WIDTH, current_bar))

        # Act title and subtitle
        if bar_anim >= 0.5:
            text_alpha = min(255, int(255 * ((bar_anim - 0.5) / 0.5)))
            act = self.ACTS[self.preview_act]

            # "NEXT:" label
            next_label = self.font_preview_sub.render("NEXT:", True, (180, 180, 180))
            next_surf = pygame.Surface(next_label.get_size(), pygame.SRCALPHA)
            next_surf.blit(next_label, (0, 0))
            next_surf.set_alpha(text_alpha)
            screen.blit(next_surf, (SCREEN_WIDTH // 2 - next_label.get_width() // 2,
                                    SCREEN_HEIGHT // 2 - 60))

            # Act name in gold
            title = self.font_preview.render(act["name"], True, (255, 215, 0))
            title_surf = pygame.Surface(title.get_size(), pygame.SRCALPHA)
            title_surf.blit(title, (0, 0))
            title_surf.set_alpha(text_alpha)
            screen.blit(title_surf, (SCREEN_WIDTH // 2 - title.get_width() // 2,
                                     SCREEN_HEIGHT // 2 - 20))

    def _draw_act_intro(self, screen):
        # Cinematic letterbox
        bar_height = 80
        alpha = int(200 * (self.transition_timer / ACT_TRANSITION_DURATION))
        overlay = pygame.Surface((SCREEN_WIDTH, SCREEN_HEIGHT), pygame.SRCALPHA)
        overlay.fill((0, 0, 0, min(alpha, 200)))
        screen.blit(overlay, (0, 0))

        # Black bars
        pygame.draw.rect(screen, (0, 0, 0), (0, 0, SCREEN_WIDTH, bar_height))
        pygame.draw.rect(screen, (0, 0, 0), (0, SCREEN_HEIGHT - bar_height, SCREEN_WIDTH, bar_height))

        act = self.ACTS[self.next_act]

        # Act title
        title = self.font_title.render(act["name"], True, (255, 215, 0))
        screen.blit(title, (SCREEN_WIDTH // 2 - title.get_width() // 2, SCREEN_HEIGHT // 2 - 80))

        # Narrative text
        for i, line in enumerate(act["narrative"].split("\n")):
            text = self.font_narrative.render(line, True, (220, 220, 200))
            screen.blit(text, (SCREEN_WIDTH // 2 - text.get_width() // 2, SCREEN_HEIGHT // 2 + i * 35))

    def _draw_dialogue(self, screen):
        # Semi-dark overlay
        overlay = pygame.Surface((SCREEN_WIDTH, SCREEN_HEIGHT), pygame.SRCALPHA)
        overlay.fill((0, 0, 0, 160))
        screen.blit(overlay, (0, 0))

        if self.dialogue_index < len(self.dialogue_lines):
            speaker, line = self.dialogue_lines[self.dialogue_index]

            # Speech bubble background
            bubble_w, bubble_h = 600, 120
            bubble_x = SCREEN_WIDTH // 2 - bubble_w // 2
            bubble_y = SCREEN_HEIGHT // 2 - bubble_h // 2

            pygame.draw.rect(screen, (240, 230, 210),
                             (bubble_x, bubble_y, bubble_w, bubble_h), border_radius=15)
            pygame.draw.rect(screen, (100, 70, 30),
                             (bubble_x, bubble_y, bubble_w, bubble_h), 3, border_radius=15)

            # Speaker name
            color = (30, 80, 160) if speaker == "Newton" else (160, 50, 30)
            name_surf = self.font_speaker.render(speaker, True, color)
            screen.blit(name_surf, (bubble_x + 20, bubble_y + 15))

            # Dialogue text
            text_surf = self.font_dialogue.render(line, True, (40, 30, 20))
            screen.blit(text_surf, (bubble_x + 20, bubble_y + 50))

    def _draw_tutorial(self, screen):
        overlay = pygame.Surface((SCREEN_WIDTH, SCREEN_HEIGHT), pygame.SRCALPHA)
        overlay.fill((0, 0, 0, 180))
        screen.blit(overlay, (0, 0))

        if self.tutorial_step < len(self.TUTORIAL_STEPS):
            step = self.TUTORIAL_STEPS[self.tutorial_step]

            # Step text
            text = self.font_tutorial.render(step["text"], True, (255, 240, 200))
            screen.blit(text, (SCREEN_WIDTH // 2 - text.get_width() // 2, SCREEN_HEIGHT // 2 - 40))

            # Hint
            hint = self.font_hint.render(step["hint"], True, (180, 170, 150))
            screen.blit(hint, (SCREEN_WIDTH // 2 - hint.get_width() // 2, SCREEN_HEIGHT // 2 + 30))

            # Progress dots
            for i in range(len(self.TUTORIAL_STEPS)):
                color = (255, 215, 0) if i == self.tutorial_step else (100, 90, 70)
                pygame.draw.circle(screen, color,
                                   (SCREEN_WIDTH // 2 - 30 + i * 20, SCREEN_HEIGHT // 2 + 100), 6)

    def handle_tutorial_key(self, key):
        """Allow skipping tutorial steps with any key."""
        if self.showing_tutorial:
            self.tutorial_timer = self.tutorial_duration  # advance to next step

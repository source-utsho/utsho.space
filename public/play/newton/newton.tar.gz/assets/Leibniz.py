import pygame
import random
from config import LEIBNIZ_SPEED, LEIBNIZ_SIZE, SCREEN_WIDTH, media_path


class Leibniz:
    def __init__(self):
        self.size = LEIBNIZ_SIZE
        self.x = random.randint(0, SCREEN_WIDTH - self.size)
        self.y = -self.size
        self.speed = LEIBNIZ_SPEED

        try:
            self.image = pygame.image.load(media_path("leibniz.png")).convert_alpha()
            self.image = pygame.transform.scale(self.image, (self.size, self.size))
        except (pygame.error, FileNotFoundError):
            self.image = pygame.Surface((self.size, self.size), pygame.SRCALPHA)
            pygame.draw.circle(self.image, (255, 215, 0), (self.size // 2, self.size // 2), self.size // 2)

        # Bobbing animation
        self.bob_offset = 0.0
        self.bob_speed = 4.0

    def update(self, dt):
        self.y += self.speed
        self.bob_offset += self.bob_speed * dt
        # Gentle horizontal bob
        import math
        self.draw_x_offset = math.sin(self.bob_offset) * 3

    def get_rect(self):
        return pygame.Rect(self.x, self.y, self.size, self.size)

    def is_off_screen(self, screen_height):
        return self.y > screen_height

    def draw(self, surface, offset=(0, 0)):
        surface.blit(self.image, (self.x + self.draw_x_offset + offset[0], self.y + offset[1]))

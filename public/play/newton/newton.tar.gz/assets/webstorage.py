"""webstorage - persistence shim for the pygbag web build.
Browser: window.localStorage (survives reloads). Desktop: saves/*.json files.
"""
import sys
import json

WEB = sys.platform == "emscripten"
if WEB:
    from platform import window

_PREFIX = "newtons_apple_crisis:"


def save_json(key, data):
    if WEB:
        try:
            window.localStorage.setItem(_PREFIX + key, json.dumps(data))
        except Exception:
            pass
        return
    from config import saves_path
    try:
        with open(saves_path(key), "w") as f:
            json.dump(data, f)
    except OSError:
        pass


def load_json(key):
    if WEB:
        try:
            raw = window.localStorage.getItem(_PREFIX + key)
            if raw is None:
                return None
            return json.loads(raw)
        except Exception:
            return None
    from config import saves_path
    try:
        with open(saves_path(key), "r") as f:
            return json.load(f)
    except (FileNotFoundError, json.JSONDecodeError, OSError):
        return None

"""
Player Profile System — multi-step parchment-styled form.
Saves/loads profile to saves/profile.json.
"""
import pygame
import json
from dataclasses import dataclass, asdict
from config import SCREEN_WIDTH, SCREEN_HEIGHT, media_path, saves_path


COURSES = [
    "Basic Arithmetic",
    "Pre-Algebra",
    "Algebra",
    "Geometry",
    "Trigonometry",
    "Pre-Calculus",
    "Calculus",
    "Differential Equations",
]

CONFIDENCE_LEVELS = ["Struggling", "Getting By", "Comfortable", "Strong"]


@dataclass
class PlayerProfileData:
    name: str = ""
    age: int = 14
    grade: str = "9"
    topics: list = None
    confidence: str = "comfortable"

    def __post_init__(self):
        if self.topics is None:
            self.topics = []

    def get_level_name(self):
        """Return the highest math topic as a display name."""
        if not self.topics:
            return "arithmetic"
        # Map course names to question_bank topic keys
        topic_map = {
            "Differential Equations": "advanced",
            "Calculus": "calculus",
            "Pre-Calculus": "pre_calculus",
            "Trigonometry": "trigonometry",
            "Geometry": "geometry",
            "Algebra": "algebra",
            "Pre-Algebra": "pre_algebra",
            "Basic Arithmetic": "arithmetic",
        }
        for course in reversed(self.topics):
            if course in topic_map:
                return topic_map[course]
        return "arithmetic"


class PlayerProfileForm:
    """Multi-step profile form rendered on parchment background."""

    def __init__(self, screen, game):
        self.screen = screen
        self.game = game
        self.step = 0  # 0=Name, 1=Age+Grade, 2=Courses, 3=Confidence
        self.total_steps = 4
        self.profile = PlayerProfileData()
        self.done = False

        # Input state
        self.name_input = ""
        self.age_input = "14"
        self.grade_input = "9"
        self.selected_courses = set()
        self.selected_confidence = 2  # index into CONFIDENCE_LEVELS

        # Active text field
        self.active_field = "name"  # "name", "age", "grade"

        # Background
        try:
            self.bg = pygame.image.load(media_path("profile_bg.png")).convert()
            self.bg = pygame.transform.scale(self.bg, (SCREEN_WIDTH, SCREEN_HEIGHT))
        except (pygame.error, FileNotFoundError):
            self.bg = pygame.Surface((SCREEN_WIDTH, SCREEN_HEIGHT))
            self.bg.fill((210, 180, 140))

        # Fonts
        self.font_title = pygame.font.SysFont("Georgia", 42, bold=True)
        self.font_label = pygame.font.SysFont("Georgia", 28)
        self.font_input = pygame.font.SysFont("Georgia", 30)
        self.font_small = pygame.font.SysFont("Georgia", 22)
        self.font_button = pygame.font.SysFont("Georgia", 26, bold=True)

        # Colors
        self.text_color = (60, 40, 20)
        self.highlight_color = (139, 69, 19)
        self.input_bg = (255, 248, 230)
        self.input_border = (139, 90, 43)
        self.button_color = (120, 70, 20)
        self.button_hover = (160, 100, 40)
        self.selected_color = (180, 120, 40)
        self.check_color = (50, 130, 50)

    def handle_event(self, event):
        if self.done:
            return

        if event.type == pygame.KEYDOWN:
            if event.key == pygame.K_RETURN:
                self._advance_step()
            elif event.key == pygame.K_BACKSPACE:
                self._handle_backspace()
            elif event.key == pygame.K_TAB:
                self._switch_field()
            elif event.key == pygame.K_UP:
                self._handle_up()
            elif event.key == pygame.K_DOWN:
                self._handle_down()
            elif event.key == pygame.K_SPACE:
                if self.step == 2:
                    # Toggle currently highlighted course
                    pass
                elif self.step == 0:
                    self.name_input += " "
            else:
                self._handle_text_input(event)

        elif event.type == pygame.MOUSEBUTTONDOWN:
            self._handle_click(event.pos)

    def _handle_text_input(self, event):
        if event.unicode and event.unicode.isprintable():
            if self.step == 0:
                if len(self.name_input) < 20:
                    self.name_input += event.unicode
            elif self.step == 1:
                if self.active_field == "age" and event.unicode.isdigit():
                    if len(self.age_input) < 2:
                        self.age_input += event.unicode
                elif self.active_field == "grade" and len(self.grade_input) < 3:
                    self.grade_input += event.unicode

    def _handle_backspace(self):
        if self.step == 0:
            self.name_input = self.name_input[:-1]
        elif self.step == 1:
            if self.active_field == "age":
                self.age_input = self.age_input[:-1]
            else:
                self.grade_input = self.grade_input[:-1]

    def _switch_field(self):
        if self.step == 1:
            self.active_field = "grade" if self.active_field == "age" else "age"

    def _handle_up(self):
        if self.step == 3:
            self.selected_confidence = max(0, self.selected_confidence - 1)

    def _handle_down(self):
        if self.step == 3:
            self.selected_confidence = min(len(CONFIDENCE_LEVELS) - 1, self.selected_confidence + 1)

    def _handle_click(self, pos):
        mx, my = pos

        # Next button area (bottom center)
        next_rect = pygame.Rect(SCREEN_WIDTH // 2 - 80, SCREEN_HEIGHT - 120, 160, 50)
        if next_rect.collidepoint(mx, my):
            self._advance_step()
            return

        # Course checkboxes (step 2)
        if self.step == 2:
            start_y = 220
            for i, course in enumerate(COURSES):
                row = i % 4
                col = i // 4
                cx = 200 + col * 350
                cy = start_y + row * 55
                box_rect = pygame.Rect(cx - 5, cy - 5, 320, 45)
                if box_rect.collidepoint(mx, my):
                    if i in self.selected_courses:
                        self.selected_courses.discard(i)
                    else:
                        self.selected_courses.add(i)
                    return

        # Confidence options (step 3)
        if self.step == 3:
            for i in range(len(CONFIDENCE_LEVELS)):
                opt_rect = pygame.Rect(SCREEN_WIDTH // 2 - 150, 260 + i * 70, 300, 50)
                if opt_rect.collidepoint(mx, my):
                    self.selected_confidence = i
                    return

    def _advance_step(self):
        if self.step == 0:
            if self.name_input.strip():
                self.step = 1
                self.active_field = "age"
        elif self.step == 1:
            try:
                age = int(self.age_input) if self.age_input else 14
                self.profile.age = max(8, min(99, age))
            except ValueError:
                self.profile.age = 14
            self.profile.grade = self.grade_input or "9"
            self.step = 2
        elif self.step == 2:
            self.step = 3
        elif self.step == 3:
            self._finish()

    def _finish(self):
        self.profile.name = self.name_input.strip() or "Player"
        self.profile.topics = [COURSES[i] for i in sorted(self.selected_courses)]
        if not self.profile.topics:
            self.profile.topics = ["Basic Arithmetic"]
        self.profile.confidence = CONFIDENCE_LEVELS[self.selected_confidence].lower().replace(" ", "_")
        self.done = True
        self._save()
        self.game.player_profile = self.profile
        self.game.start_game()

    def _save(self):
        from webstorage import save_json
        save_json("profile.json", asdict(self.profile))

    @staticmethod
    def load_profile():
        """Load saved profile or return None."""
        from webstorage import load_json
        data = load_json("profile.json")
        if not data:
            return None
        try:
            return PlayerProfileData(**data)
        except TypeError:
            return None

    # ── drawing ──────────────────────────────────────────

    def draw(self):
        self.screen.blit(self.bg, (0, 0))

        # Step indicator
        step_text = self.font_small.render(f"Step {self.step + 1} of {self.total_steps}", True, self.text_color)
        self.screen.blit(step_text, (SCREEN_WIDTH // 2 - step_text.get_width() // 2, 50))

        if self.step == 0:
            self._draw_name_step()
        elif self.step == 1:
            self._draw_age_grade_step()
        elif self.step == 2:
            self._draw_courses_step()
        elif self.step == 3:
            self._draw_confidence_step()

        # Next button
        self._draw_next_button()

    def _draw_name_step(self):
        title = self.font_title.render("What is your name?", True, self.text_color)
        self.screen.blit(title, (SCREEN_WIDTH // 2 - title.get_width() // 2, 150))

        # Input box
        box_rect = pygame.Rect(SCREEN_WIDTH // 2 - 200, 300, 400, 55)
        pygame.draw.rect(self.screen, self.input_bg, box_rect)
        pygame.draw.rect(self.screen, self.input_border, box_rect, 3)

        display = self.name_input + ("|" if pygame.time.get_ticks() % 1000 < 500 else "")
        text_surf = self.font_input.render(display, True, self.text_color)
        self.screen.blit(text_surf, (box_rect.x + 15, box_rect.y + 10))

    def _draw_age_grade_step(self):
        title = self.font_title.render("About You", True, self.text_color)
        self.screen.blit(title, (SCREEN_WIDTH // 2 - title.get_width() // 2, 130))

        # Age
        age_label = self.font_label.render("Age:", True, self.text_color)
        self.screen.blit(age_label, (SCREEN_WIDTH // 2 - 180, 260))
        age_rect = pygame.Rect(SCREEN_WIDTH // 2 - 50, 255, 120, 45)
        border = self.highlight_color if self.active_field == "age" else self.input_border
        pygame.draw.rect(self.screen, self.input_bg, age_rect)
        pygame.draw.rect(self.screen, border, age_rect, 3)
        age_text = self.font_input.render(self.age_input + ("|" if self.active_field == "age" and pygame.time.get_ticks() % 1000 < 500 else ""), True, self.text_color)
        self.screen.blit(age_text, (age_rect.x + 10, age_rect.y + 6))

        # Grade
        grade_label = self.font_label.render("Grade:", True, self.text_color)
        self.screen.blit(grade_label, (SCREEN_WIDTH // 2 - 180, 350))
        grade_rect = pygame.Rect(SCREEN_WIDTH // 2 - 50, 345, 120, 45)
        border = self.highlight_color if self.active_field == "grade" else self.input_border
        pygame.draw.rect(self.screen, self.input_bg, grade_rect)
        pygame.draw.rect(self.screen, border, grade_rect, 3)
        grade_text = self.font_input.render(self.grade_input + ("|" if self.active_field == "grade" and pygame.time.get_ticks() % 1000 < 500 else ""), True, self.text_color)
        self.screen.blit(grade_text, (grade_rect.x + 10, grade_rect.y + 6))

        hint = self.font_small.render("Press TAB to switch fields", True, (120, 100, 80))
        self.screen.blit(hint, (SCREEN_WIDTH // 2 - hint.get_width() // 2, 440))

    def _draw_courses_step(self):
        title = self.font_title.render("Courses Taken", True, self.text_color)
        self.screen.blit(title, (SCREEN_WIDTH // 2 - title.get_width() // 2, 130))

        hint = self.font_small.render("Click to select (choose all that apply)", True, (120, 100, 80))
        self.screen.blit(hint, (SCREEN_WIDTH // 2 - hint.get_width() // 2, 185))

        start_y = 230
        for i, course in enumerate(COURSES):
            row = i % 4
            col = i // 4
            cx = 200 + col * 350
            cy = start_y + row * 60

            # Checkbox
            box = pygame.Rect(cx, cy, 28, 28)
            pygame.draw.rect(self.screen, self.input_bg, box)
            pygame.draw.rect(self.screen, self.input_border, box, 2)
            if i in self.selected_courses:
                pygame.draw.line(self.screen, self.check_color, (cx + 4, cy + 14), (cx + 11, cy + 22), 3)
                pygame.draw.line(self.screen, self.check_color, (cx + 11, cy + 22), (cx + 24, cy + 5), 3)

            label = self.font_small.render(course, True, self.text_color)
            self.screen.blit(label, (cx + 38, cy + 2))

    def _draw_confidence_step(self):
        title = self.font_title.render("Math Confidence", True, self.text_color)
        self.screen.blit(title, (SCREEN_WIDTH // 2 - title.get_width() // 2, 130))

        hint = self.font_small.render("How comfortable are you with math?", True, (120, 100, 80))
        self.screen.blit(hint, (SCREEN_WIDTH // 2 - hint.get_width() // 2, 190))

        for i, level in enumerate(CONFIDENCE_LEVELS):
            rect = pygame.Rect(SCREEN_WIDTH // 2 - 150, 260 + i * 70, 300, 50)
            if i == self.selected_confidence:
                pygame.draw.rect(self.screen, self.selected_color, rect, border_radius=8)
                color = (255, 255, 240)
            else:
                pygame.draw.rect(self.screen, self.input_bg, rect, border_radius=8)
                pygame.draw.rect(self.screen, self.input_border, rect, 2, border_radius=8)
                color = self.text_color
            text = self.font_label.render(level, True, color)
            self.screen.blit(text, (rect.x + rect.width // 2 - text.get_width() // 2,
                                    rect.y + rect.height // 2 - text.get_height() // 2))

    def _draw_next_button(self):
        label = "Finish" if self.step == self.total_steps - 1 else "Next"
        rect = pygame.Rect(SCREEN_WIDTH // 2 - 80, SCREEN_HEIGHT - 120, 160, 50)
        pygame.draw.rect(self.screen, self.button_color, rect, border_radius=10)
        text = self.font_button.render(f"{label} ->", True, (255, 248, 230))
        self.screen.blit(text, (rect.x + rect.width // 2 - text.get_width() // 2,
                                rect.y + rect.height // 2 - text.get_height() // 2))

"""
ParticleSystem — Particle effects, floating score pops, and screen shake.
"""
import pygame
import random
import math
from config import (
    PARTICLE_COUNT_APPLE, PARTICLE_COUNT_LEIBNIZ,
    PARTICLE_LIFETIME, SCREEN_SHAKE_DURATION, SCREEN_SHAKE_INTENSITY,
)


class Particle:
    __slots__ = ("x", "y", "vx", "vy", "color", "lifetime", "max_lifetime", "size")

    def __init__(self, x, y, vx, vy, color, lifetime, size=4):
        self.x = x
        self.y = y
        self.vx = vx
        self.vy = vy
        self.color = color
        self.lifetime = lifetime
        self.max_lifetime = lifetime
        self.size = size


class ScorePop:
    """Floating text that rises and fades out."""
    __slots__ = ("x", "y", "text", "lifetime", "max_lifetime", "font")

    def __init__(self, x, y, text, font):
        self.x = x
        self.y = y
        self.text = text
        self.lifetime = 1.0
        self.max_lifetime = 1.0
        self.font = font


class ParticleSystem:
    def __init__(self):
        self.particles = []
        self.score_pops = []
        self.shake_timer = 0.0
        self.shake_intensity = 0
        self.shake_offset = (0, 0)

        # Font for score pops
        pygame.font.init()
        self.pop_font = pygame.font.SysFont("Georgia", 28, bold=True)

    def emit_apple_hit(self, x, y):
        """12 red/orange juice particles burst outward."""
        for _ in range(PARTICLE_COUNT_APPLE):
            angle = random.uniform(0, 2 * math.pi)
            speed = random.uniform(2, 8)
            color = random.choice([(255, 50, 50), (255, 100, 0), (200, 0, 0)])
            self.particles.append(Particle(
                x, y,
                math.cos(angle) * speed, math.sin(angle) * speed,
                color, PARTICLE_LIFETIME
            ))

    def emit_leibniz(self, x, y):
        """16 gold sparkle particles."""
        for _ in range(PARTICLE_COUNT_LEIBNIZ):
            angle = random.uniform(0, 2 * math.pi)
            speed = random.uniform(1, 6)
            color = random.choice([(255, 215, 0), (255, 255, 100), (255, 180, 0)])
            self.particles.append(Particle(
                x, y,
                math.cos(angle) * speed, math.sin(angle) * speed,
                color, PARTICLE_LIFETIME, size=6
            ))

    def emit_score_pop(self, x, y, text):
        """Spawn a floating score text."""
        self.score_pops.append(ScorePop(x, y, text, self.pop_font))

    def start_shake(self):
        self.shake_timer = SCREEN_SHAKE_DURATION
        self.shake_intensity = SCREEN_SHAKE_INTENSITY

    def update(self, dt):
        # Update particles
        alive = []
        for p in self.particles:
            p.x += p.vx
            p.y += p.vy
            p.vy += 0.2  # gravity
            p.lifetime -= dt
            if p.lifetime > 0:
                alive.append(p)
        self.particles = alive

        # Update score pops
        alive_pops = []
        for sp in self.score_pops:
            sp.y -= 60 * dt  # rise 60px/sec
            sp.lifetime -= dt
            if sp.lifetime > 0:
                alive_pops.append(sp)
        self.score_pops = alive_pops

        # Update shake
        if self.shake_timer > 0:
            self.shake_timer -= dt
            intensity = self.shake_intensity * (self.shake_timer / SCREEN_SHAKE_DURATION)
            self.shake_offset = (
                random.uniform(-intensity, intensity),
                random.uniform(-intensity, intensity),
            )
        else:
            self.shake_offset = (0, 0)

    def draw(self, screen):
        # Draw particles
        for p in self.particles:
            alpha = p.lifetime / p.max_lifetime
            size = max(1, int(p.size * alpha))
            pygame.draw.circle(screen, p.color, (int(p.x), int(p.y)), size)

        # Draw score pops
        for sp in self.score_pops:
            alpha = int(255 * (sp.lifetime / sp.max_lifetime))
            text_surf = sp.font.render(sp.text, True, (255, 255, 50))
            # Create surface with alpha
            temp = pygame.Surface(text_surf.get_size(), pygame.SRCALPHA)
            temp.blit(text_surf, (0, 0))
            temp.set_alpha(alpha)
            screen.blit(temp, (int(sp.x), int(sp.y)))

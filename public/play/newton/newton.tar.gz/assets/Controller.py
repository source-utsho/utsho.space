import sys
import pygame
from Game import Game


class Controller:
    """Handles all keyboard/mouse input and routes it to the game model."""

    # Menu button regions (from VISION_v3 Section 4)
    MENU_PLAY_RECT = pygame.Rect(325, 370, 415, 72)
    MENU_HOW_TO_PLAY_RECT = pygame.Rect(140, 462, 275, 58)
    MENU_RANKINGS_RECT = pygame.Rect(440, 462, 185, 58)
    MENU_QUIT_RECT = pygame.Rect(650, 462, 275, 58)

    # How-to-play back button region
    HOW_TO_PLAY_BACK_RECT = pygame.Rect(362, 608, 341, 58)

    # Game over button regions (from VISION_v3 Section 6)
    GAME_OVER_RETRY_RECT = pygame.Rect(55, 513, 295, 64)
    GAME_OVER_MENU_RECT = pygame.Rect(375, 513, 295, 64)
    GAME_OVER_QUIT_RECT = pygame.Rect(695, 513, 295, 64)

    def __init__(self, game):
        self.game = game

    def handle_events(self, events):
        for event in events:
            if event.type == pygame.QUIT:
                if sys.platform == "emscripten":
                    continue  # browser tab close handles exit
                return False  # signal to quit

            if event.type == pygame.KEYDOWN:
                if self.game.state == Game.STATE_MENU:
                    self._handle_menu_key(event.key)
                elif self.game.state == Game.STATE_HOW_TO_PLAY:
                    self._handle_how_to_play_key(event.key)
                elif self.game.state == Game.STATE_PLAYING:
                    self._handle_playing_key_down(event.key)
                elif self.game.state == Game.STATE_PAUSED:
                    self._handle_paused_key(event.key)
                elif self.game.state == Game.STATE_QUIZ:
                    self._handle_quiz_key(event.key)
                elif self.game.state == Game.STATE_GAME_OVER:
                    self._handle_game_over_key(event.key)
                elif self.game.state == Game.STATE_LEADERBOARD:
                    self._handle_leaderboard_key(event.key)

            if event.type == pygame.KEYUP:
                if self.game.state == Game.STATE_PLAYING:
                    self._handle_playing_key_up(event.key)

            if event.type == pygame.MOUSEBUTTONDOWN and event.button == 1:
                if self.game.state == Game.STATE_MENU:
                    self._handle_menu_click(event.pos)
                elif self.game.state == Game.STATE_HOW_TO_PLAY:
                    self._handle_how_to_play_click(event.pos)
                elif self.game.state == Game.STATE_GAME_OVER:
                    self._handle_game_over_click(event.pos)

        return True  # keep running

    # ── menu ─────────────────────────────────────────────

    def _handle_menu_key(self, key):
        if key == pygame.K_RETURN:
            self._menu_start_game()
        elif key == pygame.K_h:
            self.game.state = Game.STATE_HOW_TO_PLAY
        elif key == pygame.K_l:
            self.game.state = Game.STATE_LEADERBOARD
            if self.game.leaderboard_client:
                self.game.leaderboard_client.fetch_leaderboard_async()
        elif key == pygame.K_q:
            pygame.event.post(pygame.event.Event(pygame.QUIT))

    def _handle_menu_click(self, pos):
        if self.MENU_PLAY_RECT.collidepoint(pos):
            self._menu_start_game()
        elif self.MENU_HOW_TO_PLAY_RECT.collidepoint(pos):
            self.game.state = Game.STATE_HOW_TO_PLAY
        elif self.MENU_RANKINGS_RECT.collidepoint(pos):
            self.game.state = Game.STATE_LEADERBOARD
            if self.game.leaderboard_client:
                self.game.leaderboard_client.fetch_leaderboard_async()
        elif self.MENU_QUIT_RECT.collidepoint(pos):
            pygame.event.post(pygame.event.Event(pygame.QUIT))

    def _menu_start_game(self):
        if self.game.player_profile is None:
            self.game.state = Game.STATE_PROFILE
        else:
            self.game.start_game()

    # ── how to play ───────────────────────────────────────

    def _handle_how_to_play_key(self, key):
        self.game.state = Game.STATE_MENU

    def _handle_how_to_play_click(self, pos):
        if self.HOW_TO_PLAY_BACK_RECT.collidepoint(pos):
            self.game.state = Game.STATE_MENU

    # ── playing ──────────────────────────────────────────

    def _handle_playing_key_down(self, key):
        if key == pygame.K_LEFT:
            self.game.newton.moving_left = True
        elif key == pygame.K_RIGHT:
            self.game.newton.moving_right = True
        elif key == pygame.K_ESCAPE:
            self.game.state = Game.STATE_PAUSED
            try:
                pygame.mixer.music.pause()
            except Exception:
                pass

    def _handle_playing_key_up(self, key):
        if key == pygame.K_LEFT:
            self.game.newton.moving_left = False
        elif key == pygame.K_RIGHT:
            self.game.newton.moving_right = False

    # ── paused ───────────────────────────────────────────

    def _handle_paused_key(self, key):
        if key == pygame.K_ESCAPE:
            self.game.state = Game.STATE_PLAYING
            try:
                pygame.mixer.music.unpause()
            except Exception:
                pass
        elif key == pygame.K_m:
            self.game.state = Game.STATE_MENU
            try:
                pygame.mixer.music.stop()
            except Exception:
                pass
        elif key == pygame.K_q:
            pygame.event.post(pygame.event.Event(pygame.QUIT))

    # ── quiz ─────────────────────────────────────────────

    def _handle_quiz_key(self, key):
        if self.game.quiz_manager:
            self.game.quiz_manager.handle_key(key)

    # ── game over ────────────────────────────────────────

    def _handle_game_over_key(self, key):
        if key == pygame.K_r or key == pygame.K_RETURN:
            self.game.start_game()
        elif key == pygame.K_m:
            self.game.state = Game.STATE_MENU
        elif key == pygame.K_q:
            pygame.event.post(pygame.event.Event(pygame.QUIT))
        elif key == pygame.K_l:
            self.game.state = Game.STATE_LEADERBOARD
            if self.game.leaderboard_client:
                self.game.leaderboard_client.fetch_leaderboard_async()

    def _handle_game_over_click(self, pos):
        if self.GAME_OVER_RETRY_RECT.collidepoint(pos):
            self.game.start_game()
        elif self.GAME_OVER_MENU_RECT.collidepoint(pos):
            self.game.state = Game.STATE_MENU
        elif self.GAME_OVER_QUIT_RECT.collidepoint(pos):
            pygame.event.post(pygame.event.Event(pygame.QUIT))

    # ── leaderboard ──────────────────────────────────────

    def _handle_leaderboard_key(self, key):
        if key == pygame.K_ESCAPE or key == pygame.K_m:
            self.game.state = Game.STATE_MENU

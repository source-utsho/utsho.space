import pygame
from Apple import Apple
from Leibniz import Leibniz
from config import (
    SPAWN_RATE_INITIAL, LEIBNIZ_SPAWN_RATE_INITIAL,
    SPAWN_RATE_MIN, LEIBNIZ_SPAWN_RATE_MIN,
)


class Spawner:
    # Hardcoded — removed from config
    SPAWN_INCREASE_INTERVAL = 10

    def __init__(self):
        self.apple_rate = SPAWN_RATE_INITIAL
        self.leibniz_rate = LEIBNIZ_SPAWN_RATE_INITIAL
        self.apple_counter = 0
        self.leibniz_counter = 0
        self.frame_counter = 0
        self.apple_speed_multiplier = 1.0

    def set_rates(self, apple_rate, leibniz_rate, speed_mult):
        """Called by ActManager when acts change."""
        self.apple_rate = apple_rate
        self.leibniz_rate = leibniz_rate
        self.apple_speed_multiplier = speed_mult

    def update(self, apples, leibniz_list):
        """Call once per frame. Appends new entities to the lists."""
        self.frame_counter += 1

        # Gradually increase difficulty
        if self.frame_counter % self.SPAWN_INCREASE_INTERVAL == 0:
            self.apple_rate = max(SPAWN_RATE_MIN, self.apple_rate - 1)
            self.leibniz_rate = max(LEIBNIZ_SPAWN_RATE_MIN, self.leibniz_rate - 1)

        self.apple_counter += 1
        if self.apple_counter >= self.apple_rate // 10:
            self.apple_counter = 0
            apples.append(Apple(speed_multiplier=self.apple_speed_multiplier))

        self.leibniz_counter += 1
        if self.leibniz_counter >= self.leibniz_rate // 10:
            self.leibniz_counter = 0
            leibniz_list.append(Leibniz())

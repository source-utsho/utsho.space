class CollisionManager:
    def __init__(self):
        pass

    def check_apple_collisions(self, newton, apples):
        """Return list of apples that hit Newton."""
        hit = []
        newton_rect = newton.get_rect()
        for apple in apples:
            if newton_rect.colliderect(apple.get_rect()):
                hit.append(apple)
        return hit

    def check_leibniz_collisions(self, newton, leibniz_list):
        """Return list of Leibniz power-ups that Newton collected."""
        collected = []
        newton_rect = newton.get_rect()
        for lz in leibniz_list:
            if newton_rect.colliderect(lz.get_rect()):
                collected.append(lz)
        return collected

"""
QuizManager — Adaptive quiz engine with dark overlay panel style.
Per VISION_v3 Section 5: dark semi-transparent overlay, no parchment/background image.
Slide-in/out animation, styled dark buttons, difficulty badge, explanation panel.
"""
import pygame
import random
from config import (
    SCREEN_WIDTH, SCREEN_HEIGHT,
    SCORE_QUIZ_EASY, SCORE_QUIZ_MEDIUM, SCORE_QUIZ_HARD,
)
from question_bank import get_questions_for_profile


class QuizManager:
    # Panel states
    SLIDING_IN = "sliding_in"
    SHOWING_QUESTION = "showing_question"
    SHOWING_EXPLANATION = "showing_explanation"
    SLIDING_OUT = "sliding_out"

    SLIDE_DURATION = 0.3  # seconds
    EXPLANATION_DURATION = 2.0  # seconds

    PANEL_WIDTH = 800
    PANEL_HEIGHT = 480
    PANEL_X = 132  # fixed horizontal position

    # Colors
    OVERLAY_COLOR = (0, 0, 0, 175)
    PANEL_COLOR = (15, 30, 60)
    PANEL_BORDER = (40, 100, 180)
    GOLD = (255, 215, 0)
    WHITE = (255, 255, 255)
    LIGHT_GRAY = (200, 200, 210)
    BUTTON_BG = (25, 45, 80)
    BUTTON_HOVER = (35, 60, 110)
    BUTTON_BORDER = (60, 120, 200)
    SELECTED_BG = (80, 80, 20)
    SELECTED_BORDER = (255, 255, 50)
    CORRECT_COLOR = (30, 180, 60)
    WRONG_COLOR = (200, 40, 40)
    CORRECT_BG = (15, 60, 25)
    WRONG_BG = (70, 20, 20)

    # Difficulty badge colors
    DIFF_COLORS = {
        "easy": (80, 180, 80),
        "medium": (220, 180, 40),
        "hard": (220, 60, 60),
    }

    def __init__(self, screen, game, player_profile):
        self.screen = screen
        self.game = game
        self.profile = player_profile

        # Load questions for this profile
        if player_profile:
            self.question_pool = get_questions_for_profile(
                player_profile.age,
                player_profile.topics,
                player_profile.confidence,
            )
        else:
            # Fallback: basic arithmetic easy
            from question_bank import QUESTION_BANK
            self.question_pool = QUESTION_BANK["arithmetic"]["easy"]

        self.used_indices = set()
        self.current_question = None
        self.selected_answer = -1
        self.correct = False
        self.difficulty = self._get_difficulty()

        # Panel animation
        self.panel_state = None
        self.slide_timer = 0.0
        self.explanation_timer = 0.0
        self.panel_y = -self.PANEL_HEIGHT  # starts off-screen

        # Target Y = centered vertically
        self.target_y = (SCREEN_HEIGHT - self.PANEL_HEIGHT) // 2

        # Quiz statistics
        self.correct_count = 0
        self.total_count = 0

        # Fonts — all standard system fonts, no decorative fonts
        self.font_header = pygame.font.SysFont("Arial", 42, bold=True)
        self.font_question = pygame.font.SysFont("Arial", 26, bold=True)
        self.font_choice = pygame.font.SysFont("Arial", 22)
        self.font_letter = pygame.font.SysFont("Arial", 22, bold=True)
        self.font_label = pygame.font.SysFont("Arial", 18)
        self.font_explanation = pygame.font.SysFont("Arial", 20)
        self.font_badge = pygame.font.SysFont("Arial", 16, bold=True)
        self.font_result = pygame.font.SysFont("Arial", 30, bold=True)

    def _get_difficulty(self):
        if self.profile:
            conf = self.profile.confidence.lower()
            mapping = {
                "struggling": "easy",
                "getting_by": "easy",
                "comfortable": "medium",
                "strong": "hard",
            }
            return mapping.get(conf, "medium")
        return "medium"

    def _get_next_question(self):
        available = [i for i in range(len(self.question_pool)) if i not in self.used_indices]
        if not available:
            self.used_indices.clear()
            available = list(range(len(self.question_pool)))
        idx = random.choice(available)
        self.used_indices.add(idx)
        return self.question_pool[idx]

    def start_quiz(self):
        """Called when an apple hits Newton."""
        self.current_question = self._get_next_question()
        self.selected_answer = -1
        self.correct = False
        self.total_count += 1
        self.panel_state = self.SLIDING_IN
        self.slide_timer = 0.0
        self.panel_y = -self.PANEL_HEIGHT

    def handle_key(self, key):
        if self.panel_state != self.SHOWING_QUESTION:
            return
        if not self.current_question:
            return

        # Number keys 1-4 or A-D to select answer
        answer = -1
        if key in (pygame.K_1, pygame.K_KP1):
            answer = 0
        elif key in (pygame.K_2, pygame.K_KP2):
            answer = 1
        elif key in (pygame.K_3, pygame.K_KP3):
            answer = 2
        elif key in (pygame.K_4, pygame.K_KP4):
            answer = 3
        elif key == pygame.K_a:
            answer = 0
        elif key == pygame.K_b:
            answer = 1
        elif key == pygame.K_c:
            answer = 2
        elif key == pygame.K_d:
            answer = 3

        if 0 <= answer < len(self.current_question["choices"]):
            self.selected_answer = answer
            self.correct = (answer == self.current_question["correct_index"])
            if self.correct:
                self.correct_count += 1
            self.panel_state = self.SHOWING_EXPLANATION
            self.explanation_timer = 0.0

    def update(self, dt):
        if self.panel_state == self.SLIDING_IN:
            self.slide_timer += dt
            t = min(self.slide_timer / self.SLIDE_DURATION, 1.0)
            t_ease = 1 - (1 - t) ** 2  # ease-out
            self.panel_y = int(-self.PANEL_HEIGHT + (self.target_y + self.PANEL_HEIGHT) * t_ease)
            if t >= 1.0:
                self.panel_state = self.SHOWING_QUESTION

        elif self.panel_state == self.SHOWING_EXPLANATION:
            self.explanation_timer += dt
            if self.explanation_timer >= self.EXPLANATION_DURATION:
                self.panel_state = self.SLIDING_OUT
                self.slide_timer = 0.0

        elif self.panel_state == self.SLIDING_OUT:
            self.slide_timer += dt
            t = min(self.slide_timer / self.SLIDE_DURATION, 1.0)
            t_ease = t * t  # ease-in
            self.panel_y = int(self.target_y - (self.target_y + self.PANEL_HEIGHT) * t_ease)
            if t >= 1.0:
                self.panel_state = None
                self.game.on_quiz_answered(self.correct, self.difficulty)

    def draw(self, screen):
        if self.panel_state is None:
            return

        # Dark semi-transparent overlay (full screen)
        overlay = pygame.Surface((SCREEN_WIDTH, SCREEN_HEIGHT), pygame.SRCALPHA)
        overlay.fill(self.OVERLAY_COLOR)
        screen.blit(overlay, (0, 0))

        px = self.PANEL_X
        py = self.panel_y

        # Panel background -- dark blue rounded rect
        panel_surf = pygame.Surface((self.PANEL_WIDTH, self.PANEL_HEIGHT), pygame.SRCALPHA)
        pygame.draw.rect(panel_surf, self.PANEL_COLOR,
                         (0, 0, self.PANEL_WIDTH, self.PANEL_HEIGHT), border_radius=16)
        pygame.draw.rect(panel_surf, self.PANEL_BORDER,
                         (0, 0, self.PANEL_WIDTH, self.PANEL_HEIGHT), 3, border_radius=16)
        screen.blit(panel_surf, (px, py))

        # Only draw content if panel is reasonably visible
        if py > -self.PANEL_HEIGHT // 2 and self.current_question:
            self._draw_content(screen, px, py)

    def _draw_content(self, screen, px, py):
        q = self.current_question
        margin = 40

        # "QUIZ TIME!" header — bright yellow, bold, centered
        header = self.font_header.render("QUIZ TIME!", True, (255, 220, 0))
        screen.blit(header, (px + self.PANEL_WIDTH // 2 - header.get_width() // 2, py + 18))

        # Difficulty badge -- top-right corner of panel, white text on solid color
        diff_label = self.difficulty.upper()
        diff_color = self.DIFF_COLORS.get(self.difficulty, (180, 180, 180))
        badge_text = self.font_badge.render(diff_label, True, (255, 255, 255))
        badge_w = badge_text.get_width() + 20
        badge_h = badge_text.get_height() + 10
        badge_x = px + self.PANEL_WIDTH - badge_w - 20
        badge_y = py + 20
        badge_surf = pygame.Surface((badge_w, badge_h), pygame.SRCALPHA)
        pygame.draw.rect(badge_surf, diff_color, (0, 0, badge_w, badge_h), border_radius=6)
        badge_surf.blit(badge_text, (10, 5))
        screen.blit(badge_surf, (badge_x, badge_y))

        # Question text — white, bold, word-wrapped at max 700px
        self._draw_wrapped_text(screen, q["question"], self.font_question, (255, 255, 255),
                                px + margin, py + 70, 700)

        # 4 answer option buttons
        choice_y = py + 170
        labels = ["A", "B", "C", "D"]
        button_w = self.PANEL_WIDTH - margin * 2
        button_h = 48
        button_gap = 8

        for i, choice in enumerate(q["choices"]):
            bx = px + margin
            by = choice_y + i * (button_h + button_gap)

            # Determine button style
            bg_color = self.BUTTON_BG
            border_color = self.BUTTON_BORDER
            text_color = self.WHITE
            letter_color = self.GOLD

            if self.panel_state == self.SHOWING_EXPLANATION:
                if i == q["correct_index"]:
                    bg_color = self.CORRECT_BG
                    border_color = self.CORRECT_COLOR
                    text_color = self.CORRECT_COLOR
                    letter_color = self.CORRECT_COLOR
                elif i == self.selected_answer and not self.correct:
                    bg_color = self.WRONG_BG
                    border_color = self.WRONG_COLOR
                    text_color = self.WRONG_COLOR
                    letter_color = self.WRONG_COLOR
            elif self.panel_state == self.SHOWING_QUESTION and i == self.selected_answer:
                bg_color = (255, 220, 0)        # bright yellow background
                border_color = (255, 240, 100)
                text_color = (10, 10, 30)        # dark text on yellow
                letter_color = (10, 10, 30)

            # Draw button background
            btn_surf = pygame.Surface((button_w, button_h), pygame.SRCALPHA)
            pygame.draw.rect(btn_surf, bg_color, (0, 0, button_w, button_h), border_radius=8)
            pygame.draw.rect(btn_surf, border_color, (0, 0, button_w, button_h), 2, border_radius=8)
            screen.blit(btn_surf, (bx, by))

            # Letter label
            letter = self.font_letter.render(labels[i], True, letter_color)
            screen.blit(letter, (bx + 16, by + button_h // 2 - letter.get_height() // 2))

            # Choice text
            choice_surf = self.font_choice.render(choice, True, text_color)
            screen.blit(choice_surf, (bx + 50, by + button_h // 2 - choice_surf.get_height() // 2))

        # Explanation panel (after answer)
        if self.panel_state == self.SHOWING_EXPLANATION:
            exp_y = choice_y + len(q["choices"]) * (button_h + button_gap) + 10

            if self.correct:
                result_text = "Correct!"
                result_color = self.CORRECT_COLOR
                exp_bg = self.CORRECT_BG
            else:
                result_text = "Wrong! Game Over incoming..."
                result_color = self.WRONG_COLOR
                exp_bg = self.WRONG_BG

            # Explanation background bar
            exp_w = self.PANEL_WIDTH - margin * 2
            exp_h = 80
            exp_surf = pygame.Surface((exp_w, exp_h), pygame.SRCALPHA)
            pygame.draw.rect(exp_surf, (*exp_bg, 200) if len(exp_bg) == 3 else exp_bg,
                             (0, 0, exp_w, exp_h), border_radius=8)
            screen.blit(exp_surf, (px + margin, exp_y))

            result = self.font_result.render(result_text, True, result_color)
            screen.blit(result, (px + margin + 12, exp_y + 6))

            # Explanation text
            self._draw_wrapped_text(screen, q["explanation"], self.font_explanation,
                                    self.LIGHT_GRAY, px + margin + 12, exp_y + 40,
                                    exp_w - 24)

    def _draw_wrapped_text(self, screen, text, font, color, x, y, max_width):
        words = text.split()
        lines = []
        current_line = ""
        for word in words:
            test = current_line + " " + word if current_line else word
            if font.size(test)[0] <= max_width:
                current_line = test
            else:
                if current_line:
                    lines.append(current_line)
                current_line = word
        if current_line:
            lines.append(current_line)

        for i, line in enumerate(lines):
            surf = font.render(line, True, color)
            screen.blit(surf, (x, y + i * (font.get_height() + 4)))

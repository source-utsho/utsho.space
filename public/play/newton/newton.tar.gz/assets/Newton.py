import pygame
import math
from config import (
    NEWTON_SPEED, NEWTON_BASE_WIDTH, NEWTON_BASE_HEIGHT,
    NEWTON_GROW_FACTOR, NEWTON_GROW_DURATION, NEWTON_MAX_HEIGHT,
    SCREEN_WIDTH, SCREEN_HEIGHT, media_path,
)


class Newton:
    def __init__(self, screen):
        self.screen = screen
        self.width = NEWTON_BASE_WIDTH
        self.height = NEWTON_BASE_HEIGHT

        # Load sprites — fall back to a placeholder rectangle if files missing
        self.sprites = {}
        for name in ("newton_idle", "newton_walk_1", "newton_walk_2", "newton_hit"):
            try:
                img = pygame.image.load(media_path(f"{name}.png")).convert_alpha()
                self.sprites[name] = img
            except (pygame.error, FileNotFoundError):
                # Transparent fallback — never draw a visible debug rectangle
                surf = pygame.Surface((NEWTON_BASE_WIDTH, NEWTON_BASE_HEIGHT), pygame.SRCALPHA)
                self.sprites[name] = surf

        self.original_image = self.sprites["newton_idle"]
        self.image = pygame.transform.scale(self.original_image, (self.width, self.height))

        self.x = SCREEN_WIDTH // 2 - self.width // 2
        self.y = SCREEN_HEIGHT - self.height - 10

        # Movement
        self.moving_left = False
        self.moving_right = False

        # Smooth growth
        self.growing = False
        self.grow_timer = 0.0
        self.start_width = self.width
        self.start_height = self.height
        self.target_width = self.width
        self.target_height = self.height

        # Animation
        self.anim_frame = 0
        self.anim_counter = 0
        self.hit_timer = 0.0  # seconds remaining for hit flash

        # Mood system
        self._critical_flash_timer = 0.0

    # ── actions ──────────────────────────────────────────

    def start_grow(self):
        """Begin a smooth growth animation after being hit."""
        if self.height >= NEWTON_MAX_HEIGHT:
            return
        self.growing = True
        self.grow_timer = 0.0
        self.start_width = self.width
        self.start_height = self.height
        self.target_width = min(int(self.width * NEWTON_GROW_FACTOR), SCREEN_WIDTH)
        self.target_height = min(int(self.height * NEWTON_GROW_FACTOR), NEWTON_MAX_HEIGHT)

    def shrink(self):
        """Shrink Newton slightly (Leibniz bonus)."""
        self.width = max(int(self.width * 0.9), NEWTON_BASE_WIDTH // 2)
        self.height = max(int(self.height * 0.9), NEWTON_BASE_HEIGHT // 2)
        self._rescale()

    def flash_hit(self):
        self.hit_timer = 0.5

    def get_growth_percent(self):
        """Return growth percentage 0.0-1.0 based on current height."""
        if NEWTON_MAX_HEIGHT <= NEWTON_BASE_HEIGHT:
            return 0.0
        pct = (self.height - NEWTON_BASE_HEIGHT) / (NEWTON_MAX_HEIGHT - NEWTON_BASE_HEIGHT)
        return max(0.0, min(1.0, pct))

    # ── update ───────────────────────────────────────────

    def update(self, dt):
        # Movement
        if self.moving_left:
            self.x -= NEWTON_SPEED
        if self.moving_right:
            self.x += NEWTON_SPEED
        self.x = max(0, min(self.x, SCREEN_WIDTH - self.width))

        # Smooth growth interpolation
        if self.growing:
            self.grow_timer += dt
            t = min(self.grow_timer / NEWTON_GROW_DURATION, 1.0)
            t = 1 - (1 - t) ** 2  # ease-out
            self.width = int(self.start_width + (self.target_width - self.start_width) * t)
            self.height = int(self.start_height + (self.target_height - self.start_height) * t)
            self._rescale()
            if t >= 1.0:
                self.growing = False

        # Keep feet on ground
        self.y = SCREEN_HEIGHT - self.height - 10

        # Hit flash timer
        if self.hit_timer > 0:
            self.hit_timer -= dt

        # Critical flash timer for mood system
        self._critical_flash_timer += dt

        # Walk animation
        self._update_animation()

    def _update_animation(self):
        if self.hit_timer > 0:
            self.original_image = self.sprites["newton_hit"]
        elif self.moving_left or self.moving_right:
            self.anim_counter += 1
            if self.anim_counter >= 8:
                self.anim_counter = 0
                self.anim_frame = 1 - self.anim_frame
            name = "newton_walk_1" if self.anim_frame == 0 else "newton_walk_2"
            self.original_image = self.sprites[name]
        else:
            self.original_image = self.sprites["newton_idle"]
            self.anim_counter = 0
            self.anim_frame = 0
        self._rescale()

    def _rescale(self):
        self.image = pygame.transform.scale(self.original_image, (self.width, self.height))

    # ── collision rect ───────────────────────────────────

    def get_rect(self):
        return pygame.Rect(self.x, self.y, self.width, self.height)

    def draw(self, surface, offset=(0, 0)):
        draw_x = self.x + offset[0]
        draw_y = self.y + offset[1]

        surface.blit(self.image, (draw_x, draw_y))

        # Mood system overlays based on growth percentage
        growth = self.get_growth_percent()

        if growth >= 0.9:
            # Critical: red tint overlay flash
            if math.sin(self._critical_flash_timer * 8) > 0:
                tint = pygame.Surface((self.width, self.height), pygame.SRCALPHA)
                tint.fill((255, 0, 0, 60))
                surface.blit(tint, (draw_x, draw_y))

        if growth >= 0.7:
            # Panicking: draw sweat drops near top
            drop_size = max(4, self.width // 30)
            # Left sweat drop
            sx1 = draw_x + self.width // 4
            sy1 = draw_y + self.height // 10
            pygame.draw.circle(surface, (100, 180, 255), (sx1, sy1), drop_size)
            pygame.draw.circle(surface, (150, 210, 255), (sx1, sy1), drop_size - 1)
            # Right sweat drop
            sx2 = draw_x + self.width * 3 // 4
            sy2 = draw_y + self.height // 8
            pygame.draw.circle(surface, (100, 180, 255), (sx2, sy2), drop_size)
            pygame.draw.circle(surface, (150, 210, 255), (sx2, sy2), drop_size - 1)

        elif growth >= 0.4:
            # Worried: draw angled lines as worried eyebrows
            brow_y = draw_y + self.height // 8
            brow_len = max(8, self.width // 8)
            # Left eyebrow (angled down-left)
            lx = draw_x + self.width // 3
            pygame.draw.line(surface, (60, 40, 20),
                             (lx - brow_len // 2, brow_y - 3),
                             (lx + brow_len // 2, brow_y + 5), 3)
            # Right eyebrow (angled down-right)
            rx = draw_x + self.width * 2 // 3
            pygame.draw.line(surface, (60, 40, 20),
                             (rx - brow_len // 2, brow_y + 5),
                             (rx + brow_len // 2, brow_y - 3), 3)
